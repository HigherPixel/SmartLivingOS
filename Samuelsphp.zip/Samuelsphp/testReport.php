<?php
// Get a connection for the database
require_once('../mysqli_connect.php');

// create a query fro the databse
$query = 'select UserName, Password, FirstName, LastName from User';

$response = @mysqli_query($dbc, $query);

if(! $response){
	die('Could not get data: ' . mysql_error());
}

while($row = mysqli_fetch_array($response)) {
	echo "User Name: {$row['UserName']} <br> ".
	"Password: {$row['Password']} <br>".
	"First Name: {$row['FirstName']} <br>".
	"Last Name: {$row['LastName']} <br>".
	"--------------------------<br>";
}

echo "Fetched data successfully\n";

mysqli_close($dbc);
?>
