<?php
function average($array)
{
	$ii = 0;
	$sum = 0.0;
	$n = count($array);
	while($ii < $n)
	{
		$sum = $array[$ii] + $sum;
		$ii = $ii + 1;
	}
	return $sum/$n;
}

function dataDiv($data, $n)
{
	$arrayLen = count($data);
	$subArLen = $arrayLen/$n;
	$retAr = array();
	$subAr = array();
	if($n > $arrayLen)
	{
		$lastDat = 0;
		$extra = $n - $arrayLen;
		foreach($data as $dat)
		{
			$retAr[] = $dat;
			$lastDat = $dat;
		}
		while($extra > 0)
		{
			$retAr[] = $lastDat;
			$extra--;
		}
	}
	else
	{
		$counter = 0;
		for($ii = 0; $ii < $n; $ii++) //This loop repleats n times
		{
			if($arrayLen - $counter >= $subArLen)//If there are more than subArLen empty spots in the return array
			{
				for($temp = $subArLen; $temp > 0; $temp--)//This repeats subArLen times
				{
					$subAr[] = $data[$counter];
					$counter++; 
				}
				$retAr[] = average($subAr);
				$subAr = array();
			}
			else //If there are fewer than subArLen spots left to be filled in the retAr
			{
				if($arrayLen-$counter > 0)
				{
					while($arrayLen-$counter > 0) //
					{
						$subAr[] = $data[$counter];
						$counter++;
					}
					$retAr[] = average($subAr);
				}
				else
				{
					$retAr[] = $data[$arrayLen - 1];
				}
				
			}
		}
	}
	return $retAr;
}

$ar = [1,2,3,4,5,6,7,8,9,10,11];
echo implode(',',dataDiv($ar, 5));
?>

