<?php
require_once('../mysqli_connect.php');

$moodyq = 
'

';

$moodwq =
'

';
?>
