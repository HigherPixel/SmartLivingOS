<?php
// Get a connection for the database
ob_start();
session_start();
require_once('FitbitClient.class.php'); 
?>

<html>

<head>
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>User Page</title>
    <script type="text/javascript">
                function myOtherFunction() {

location.href = "index.php";

}

function accountSettingsFunction() {

location.href = "accountsettings.php";


}

function myPageFunction() {

location.href = "Profilepage.php";
}


        function changeText(id) {

            if ($('#' + id).is(':checked')) {
                $('#' + id + "+span").html('Edit Mode');
                document.getElementById("Info").readOnly = false;
            } else {
                $('#' + id + "+span").html('Click for Edit Mode');
                document.getElementById("Info").readOnly = true;
            }
        }


        
        function addDataFunction() {
            document.getElementById("addData").onclick = function () {
                //location.href = "AddData.html";
            };
            location.href = "AddData.html";
        }
    </script>

    <style>
        body {
            background-color: #808080;
        }

        /* Style the tab */

        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */

        .tab button {
            background-color: inherit;
            float: left;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */

        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */

        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */

        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }

        .header {
            padding: 10px 16px;
            background: #555;
            color: #f1f1f1;
            z-index: 3;
        }

        .content {
            padding: 16px;
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
        }

        .sticky+.content {
            padding-top: 102px;
        }

        #Base {
            top: 100px;
            left: 10px;
            z-index: 1;
        }

        #ProfilePic {
            position: absolute;
            top: 300px;
            left: 850px;
            z-index: 2;
        }

        
        .dropdown {
		    position: absolute;

		    /** Make it fit tightly around it's children */
		    display: inline-block;
		}

		.dropdown .dropdown-menu {
		    position: absolute;

		    /**
		     * Set the top of the dropdown menu to be positioned 100%
		     * from the top of the container, and aligned to the left.
		     */
		    top: 100%;
		    left: 0;

		    /** Allow no empty space between this and .dropdown */
			display: none;
		    margin: 0;

		    /****************
		     ** NEW STYLES **
		     ****************/

		    list-style: none; /** Remove list bullets */
		    width: 100%; /** Set the width to 100% of it's parent */
		    padding: 0;
			
		}
		.dropdown:hover .dropdown-menu {

		    /** Show dropdown menu */
		    display: block;
		}
    </style>
</head>

<body>

    <div class="main">
        <div class="header" id="myHeader">

            <h1><?php echo("{$_SESSION['UserName']}");?></h1>
        </div>
        <div class="tab">
            <button id="myPage" class="tablinks" onclick="myPageFunction()">My Page</button>
            <button id="accountSettings" onclick="accountSettingsFunction()">Account Settings</button>
            <div class="dropdown">

			    <!-- trigger button -->
			    <button style = "font-family:verdana; font-size:17">Add Data</button>

			    <!-- dropdown menu -->
			    <ul class="dropdown-menu">
			<li><a href="addalldata.php">Add All Data</a></li>
                	<li><a href="addsleepdata.php">Sleep Data</a></li>
                        <li><a href="Nutrition.php">Nutrition Data</a></li>
                        <li><a href="Exerisce.php">Exercise Data</a></li>
                        <li><a href="Emotional.php">Emotional Data</a></li>
                        <li><a href="Medical.php">Medical Data</a></li>


			    </ul>

			</div>
            <button class="tablinks" onclick="location.href='ReportExercise.php'" style ="padding-left:125px">Exercise</button>
	    <button id="MedicalReport" onclick="location.href='ReportMedical.php'">Medical</button>
	    <button id="MoodReport" onclick="location.href='ReportMood.php'">Mood</button>
	    <button id="NutritionReport" onclick="location.href='ReportNutrition.php'">Nutrition</button>
	    <button id="SleepReport" onclick="location.href='ReportSleep.php'">Sleep</button>
            <button id="logoutButton" onclick="myOtherFunction()">Log Out</button>
        </div>
        <div style="    text-align: center;">
            
        </div>

        
    </div>

<?php

require_once('config.php');
$AccountID = $_SESSION['AccountNum'];
//******************Encounter History************************
// create a query fro the databse
$query = 'select EncounterDate, Facility, Specialty, Clinitian, Reason, VisitType from EncounterHistory where AccountNum='. $AccountID .';';

$response = @mysqli_query($db, $query);

if(! $response){
	die('Could not get data:0 ' . mysql_error());
}



echo '<div style="background-color:white;margin-top:100px;margin-bottom:80px;margin-left:10%;margin-right:10%;"><br><br>';
echo '<h2 align="center">Encounter History</h2>';

echo '<table align="center"
cellspacing="5" cellpadding="8">

<tr><td align="center"><b>Date</b></td>
<td align="center"><b>Facility</b></td>
<td align="center"><b>Specialty</b></td>
<td align="center"><b>Clinitian</b></td>
<td align="center"><b>Reason</b></td>
<td align="center"><b>VisitType</b></td>';

while($row = mysqli_fetch_array($response)) {
	echo '<tr><td align="center">'.
	$row['EncounterDate'] . '</td><td align="center">'.
	$row['Facility'] . '</td><td align="center">'.
	$row['Specialty'] . '</td><td align="center">'.
	$row['Clinitian'] . '</td><td align="center">'.
	$row['Reason'] . '</td><td align="center">'.
	$row['VisitType'] . '</td><td align="center">';

echo '</tr>';
}
echo '</table>';

//****************Diagnosis********************************
// create a query fro the databse
$query = 'select DiagnosisDate, DiagnosisType, DiagnosisStatus from Diagnosis where AccountNum='. $AccountID .';';

$response = @mysqli_query($db, $query);

if(! $response){
	die('Could not get data: 1' . mysql_error());
}

echo '<h2 align="center">Encounter History</h2>';

echo '<table align="center"
cellspacing="5" cellpadding="8">

<tr><td align="center"><b>Date</b></td>
<td align="center"><b>Diagnosis</b></td>
<td align="center"><b>Status</b></td>';

while($row = mysqli_fetch_array($response)) {
	echo '<tr><td align="center">'.
	$row['DiagnosisDate'] . '</td><td align="center">'.
	$row['DiagnosisType'] . '</td><td align="center">'.
	$row['DiagnosisStatus'] . '</td><td align="center">';

echo '</tr>';
}
echo '</table>';

//**********************Medications****************************
// create a query fro the databse
$query = 'select DatePerscribed, MedicationName, LastFilled, Perscription from Medications where AccountNum='. $AccountID .';';

$response = @mysqli_query($db, $query);

if(! $response){
	die('Could not get data: 2' . mysql_error());
}

echo '<h2 align="center">Medications</h2>';

echo '<table align="center"
cellspacing="5" cellpadding="8">

<tr><td align="center"><b>Date</b></td>
<td align="center"><b>Medication</b></td>
<td align="center"><b>Last Filled</b></td>
<td align="center"><b>Perscription</b></td>';

while($row = mysqli_fetch_array($response)) {
	echo '<tr><td align="center">'.
	$row['DatePerscribed'] . '</td><td align="center">'.
	$row['MedicationName'] . '</td><td align="center">'.
	$row['LastFilled'] . '</td><td align="center">'.
	$row['Perscription'] . '</td><td align="center">';

echo '</tr>';
}
echo '</table>';

//*********************Immunizations**********************************
// create a query fro the databse
$query = 'select ImmunizationDate, ImmunizationType, NumberRecieved from Immunizations where AccountNum='. $AccountID .';';

$response = @mysqli_query($db, $query);

if(! $response){
	die('Could not get data: 3' . mysql_error());
}

echo '<h2 align="center">Immunizations</h2>';

echo '<table align="center"
cellspacing="5" cellpadding="8">

<tr><td align="center"><b>Date</b></td>
<td align="center"><b>Type</b></td>
<td align="center"><b>Number Recieved</b></td>';

while($row = mysqli_fetch_array($response)) {
	echo '<tr><td align="center">'.
	$row['ImmunizationDate'] . '</td><td align="center">'.
	$row['ImmunizationType'] . '</td><td align="center">'.
	$row['NumberRecieved'] . '</td><td align="center">';

echo '</tr>';
}
echo '</table>';
//******************Allergies****************************************
// create a query fro the databse
$query = 'select AllergyDate, AllergyType,AllergyStatus from Allergies where AccountNum='. $AccountID .';';

$response = @mysqli_query($db, $query);

if(! $response){
	die('Could not get data: 4' . mysql_error());
}

echo '<h2 align="center">Allergies</h2>';

echo '<table align="center"
cellspacing="5" cellpadding="8">

<tr><td align="center"><b>Date</b></td>
<td align="center"><b>Allergy</b></td>
<td align="center"><b>Status</b></td>';

while($row = mysqli_fetch_array($response)) {
	echo '<tr><td align="center">'.
	$row['AllergyDate'] . '</td><td align="center">'.
	$row['AllergyType'] . '</td><td align="center">'.
	$row['AllergyStatus'] . '</td><td align="center">';

echo '</tr>';
}
echo '</table>';

//*********************Blood Sugar*****************
$query = 
'
select BSMeasurementDate, BloodSugarMeasure
from BloodSugar
where BSMeasurementDate=(select Max(BSMeasurementDate) from BloodSugar) and AccountNum='. $AccountID .';
';

$response = @mysqli_query($db, $query);

if(! $response)
{
	die('Could not get data: 5' . mysqli_error());
}



echo '<h2 align="center">Blood Sugar</h2>';

echo '<table align="center"
cellspacing="5" cellpadding="8">

<tr><td align="center"><b>Date</b></td>
<td align="center"><b>Measure</b></td>';

$row = mysqli_fetch_array($response);
$date = strtotime($row['BSMeasurementDate']);
$date = getDate($date)['year'] . '-' . getDate($date)['mon'] . '-' . getDate($date)['mday'];
echo '<tr><td align="center">' . 
$date . '</td><td align="center">'.
$row['BloodSugarMeasure'] . '</td><td align="center">';
echo '</tr>';
echo '</table>';
//*********************Blood Pressure**************
$query =
'
select BPMeasurementDate, Systolic, Diastolic
from BloodPressure
where BPMeasurementDate=(select Max(BPMeasurementDate) from BloodPressure) and AccountNum='. $AccountID .';
';

$response = @mysqli_query($db, $query);

if(! $response)
{
	die('Could not get data: 6' . mysqli_error());
}

echo '<h2 align="center">Blood Pressure</h2>';

echo '<table align="center"
cellspacing="5" cellpadding="8">

<tr><td align="center"><b>Date</b></td>
<td align="center"><b>Systolic</b></td>
<td align="center"><b>Diastolic</b></td>';

$row = mysqli_fetch_array($response);
$date = strtotime($row['BPMeasurementDate']);
$date = getDate($date)['year'] . '-' . getDate($date)['mon'] . '-' . getDate($date)['mday'];
echo '<tr><td align="center">' . 
$date . '</td><td align="center">' .
$row['Systolic'] . '</td><td align="center">' .
$row['Diastolic'] . '</td><td align="center">';
echo '</tr>';
echo '</table>';
//*********************Choleterol******************
$query =
'
select CholMeasurementDate, CholMeasure 
from Cholesterol 
where CholMeasurementDate=(select Max(cholMeasurementDate) from Cholesterol) and AccountNum='. $AccountID .';
';

$response = @mysqli_query($db, $query);

if(! $response)
{
	die('Could not get data: 7' . mysqli_error());
}

echo '<h2 align="center">Cholesterol</h2>';

echo '<table align="center"
cellspacing="5" cellpadding="8">

<tr><td align="center"><b>Date</b></td>
<td align="center"><b>Measure</b></td>';

$row = mysqli_fetch_array($response);
$date = strtotime($row['CholMeasurementDate']);
$date = getDate($date)['year'] . '-' . getDate($date)['mon'] . '-' . getDate($date)['mday'];
echo '<tr><td align="center">' . 
$date . '</td><td align="center">'.
$row['CholMeasure'] . '</td><td align="center">';
echo '</tr>';
echo '</table>';
echo '<br><br></div>';
mysqli_close($db);

?> 
<br><br><br>
</body>


</html>
