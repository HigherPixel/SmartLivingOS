<?php
include "Emotional.php";
require_once('config.php');
session_start();

$AccountNum = $_SESSION['AccountNum'];
$dayID = $_SESSION['DayID'];
$day = date("Y-m-d");
$dayID = $_SESSION['DayID'];
$Anxiety = $_POST['Anxiety'];
$Anger = $_POST['Anger'];
$Sadness = $_POST['Sadness'];
$Numbness = $_POST['Numbness'];
$Rumination = $_POST['Rumination'];
$ChangeInAppitite = $_POST['LossOfAppitite'];
$TroubleSleeping = $_POST['TroubleSleeping'];
$LowSelfEsteem = $_POST['LowSelfEsteem'];
$Mania = $_POST['Mania'];
$Tiredness = $_POST['Tiredness'];
$Unmotivated = $_POST['Unmotivated'];
$MoodSwings = $_POST['MoodSwings'];

$OverallMood = 13 -($Anxiety + $Anger + $Sadness + $Numbness + $Rumination + $ChangeInAppitite + $TroubleSleeping + $LowSelfEsteem + $Mania + $Tiredness + $Unmotivated +$MoodSwings);

$testStr = "select * from Mood where DayID='$dayID'";
$test = mysqli_query($db, $testStr);
if(!$test)
{
	die("connection to mysql failed");
}
if(0 !== mysqli_num_rows($test))
{
	$result = mysqli_query($db, "UPDATE Mood SET Anxiety = '$Anxiety', Anger = '$Anger', Sadness = '$Sadness', Numbness = '$Numbness', Rumination = '$Rumination', LossOfAppitite = '$ChangeInAppitite', TroubleSleeping = '$TroubleSleeping', LowSelfEsteem = '$LowSelfEsteem', Mania = '$Mania', Tiredness = '$Tiredness', Unmotivated = '$Unmotivated', MoodSwings = '$MoodSwings', OverallMood='$OverallMood' WHERE Mood.DayID = '$dayID';");
}
else
{
	$result = mysqli_query($db,"INSERT INTO Mood (DayID,Anger,Anxiety,Sadness,Numbness,Rumination,LossOfAppitite,TroubleSleeping,LowSelfEsteem,Mania,Tiredness,Unmotivated,MoodSwings,OverallMood) values ('$dayID','$Anger','$Anxiety','$Sadness','$Numbness','$Rumination','$ChangeInAppitite','$TroubleSleeping','$LowSelfEsteem','$Mania','$Tiredness','$Unmotivated','$MoodSwings','$OverallMood')");
}
if($result)
{
    header( "Location: Profilepage.php");
}
else
{
    echo("Error description:1 " . mysqli_error($db));
    echo($dayID);
}
mysqli_close($db);
?>
