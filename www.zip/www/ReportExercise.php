<?php
ob_start();
session_start();
require_once('config.php');
require_once('FitbitClient.class.php');
$AccountID = $_SESSION['AccountNum'];

function dbtophptime($dbtime)
{
	$newTime = substr_replace($dbtime,':',2,0);
	$date = '2000-00-00';
	$sec = ':00';
	$TimeString = $date . $newTime . $sec;
	return strtotime($TimeString);
}

function eliminateNullData($xData, $yData)
{
	$retArX = array();
	$retArY = array();
	$n = count($xData);
	$check = count($yData);
	if($n == 0 or $check == 0)
	{
		$retArX[] = 0;
		$retArY[] = 0;
	}
	if($n != $check)
	{
		return -1;
	}
	$ii = 0;
	while($ii < $n)
	{
		$currX = $xData[$ii];
		$currY = $yData[$ii];
		if($currX != null)
		{
			$retArX[] = $currX;
			$retArY[] = $currY;  
		}
		$ii = $ii + 1;
	}
	$retAr = array($retArX, $retArY);
	return $retAr;
}

function average($array)
{
	$ii = 0;
	$sum = array_sum($array);
	$n = count($array);
	if($n == 0)
	{
		return 0;
	}
	else
	{
		return $sum/$n;
	}
}

function dataDiv($data, $n)
{
	$arrayLen = count($data);
	$subArLen = $arrayLen/$n;
	$retAr = array();
	$subAr = array();
	if($n > $arrayLen)
	{
		$lastDat = 0;
		$extra = $n - $arrayLen;
		foreach($data as $dat)
		{
			$retAr[] = $dat;
			$lastDat = $dat;
		}
		while($extra > 0)
		{
			$retAr[] = $lastDat;
			$extra--;
		}
	}
	else
	{
		$counter = 0;
		for($ii = 0; $ii < $n; $ii++) //This loop repleats n times
		{
			if($arrayLen - $counter >= $subArLen)//If there are more than subArLen empty spots in the return array
			{
				for($temp = $subArLen; $temp > 0; $temp--)//This repeats subArLen times
				{
					$subAr[] = $data[$counter];
					$counter++; 
				}
				$retAr[] = average($subAr);
				$subAr = array();
			}
			else //If there are fewer than subArLen spots left to be filled in the retAr
			{
				if($arrayLen-$counter > 0)
				{
					while($arrayLen-$counter > 0) //
					{
						$subAr[] = $data[$counter];
						$counter++;
					}
					$retAr[] = average($subAr);
				}
				else
				{
					$retAr[] = $data[$arrayLen - 1];
				}
				
			}
		}
	}
	return $retAr;
}

$todayStr = Date("Y-m-d");
$dateAr = getDate(strtotime("-1 week"));
$lastWeek = $dateAr['year'] . "-" . $dateAr['mon'] . "-" . $dateAr['mday'];
$dateAr = getDate(strtotime("-1 year"));
$lastYear = $dateAr['year'] . "-" . $dateAr['mon'] . "-" . $dateAr['mday'];

$weekq1 = 
"
select Duration, DayDate
from Day
inner join Exercise
on Day.DayID = Exercise.DayID
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = ". $AccountID .");
";


$weekq2=
"
select Steps, DayDate
from Day
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = ". $AccountID .");
";

$yearq = 
"
select Duration, DayDate
from Day
inner join Exercise
on Day.DayID = Exercise.DayID
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastYear . "') and (AccountNum = ". $AccountID .");
";

$week1Resp = @mysqli_query($db, $weekq1);
$week2Resp = @mysqli_query($db, $weekq2);
$yearResp = @mysqli_query($db, $yearq);

if(! $week1Resp)
{
	die('Could not get data: ' . mysql_error());
}
if(! $week2Resp)
{
	die('Could not get data: ' . mysql_error());
}
if (! $yearResp)
{
	die('Could not get data: ' . mysql_erro());
}

$exw = array();
$exwdate = array();

$exy = array();
$exydate = array();

$steps = array();
$stepsdate = array();

while(($wrow = mysqli_fetch_array($week1Resp)) and ($wrow2 = mysqli_fetch_array($week2Resp)))
{
	$tempdur = dbtophptime($wrow['Duration']);
	$exw[] = getDate($tempdur)['minutes']/60.0 + getDate($tempdur)['hours'];
	$exwdate[] = strtotime($wrow['DayDate']);

	$steps[] = $wrow2['Steps'];
	$stepsdate[] = strtotime($wrow2['DayDate']);
}

while($yrow = mysqli_fetch_array($yearResp))
{
	$tempdur = dbtophptime($yrow['Duration']);
	$exy[] = getDate($tempdur)['minutes']/60.0 + getDate($tempdur)['hours'];
	$exydate[] = strtotime($yrow['DayDate']);
}

$n1 = eliminateNullData($exw, $exwdate);
$n2 = eliminateNullData($steps, $stepsdate);
$n3 = eliminateNullData($exy, $exydate);

$exw = $n1[0];
$exwdate = $n1[1];

$exy = $n3[0];
$exydate = $n3[1];

$steps = $n2[0];
$stepsdate = $n2[1];

array_multisort($exwdate,SORT_ASC, SORT_NUMERIC, $exw);
array_multisort($stepsdate,SORT_ASC, SORT_NUMERIC, $steps);
array_multisort($exydate,SORT_ASC, SORT_NUMERIC, $exy);

$exery = array();
$exerydate = array();
$lastday = $exydate[0];
$tempcal = $exy[0];
for($ii = 1; $ii<count($exydate); $ii++)
{
	if($exydate[$ii] == $lastday)
	{
		$tempcal = $tempcal + $exy[$ii];
	}
	else
	{
		$exery[] = $tempcal;
		$exerydate[] = $lastday;
		$tempcal = $exy[$ii];
		$lastday = $exydate[$ii];
	}
	$exery[] = $tempcal;
	$exerydate[] = $lastday;
}


$exerw = array();
$exerwdate = array();
$lastday = $exwdate[0];
$tempcal = $exw[0];
for($ii = 1; $ii<count($exwdate); $ii++)
{
	if($exwdate[$ii] == $lastday)
	{
		$tempcal = $tempcal + $exw[$ii];
	}
	else
	{
		$exerw[] = $tempcal;
		$exerwdate[] = $lastday;
		$tempcal = $exw[$ii];
		$lastday = $exwdate[$ii];
	}
	$exerw[] = $tempcal;
	$exerwdate[] = $lastday;
}


$exerw = dataDiv($exerw, 7);
$exerwdate = dataDiv($exerwdate, 7);

$steps = dataDiv($steps, 7);
$stepsdate = dataDiv($stepsdate, 7);

$exery = dataDiv($exery, 12);
$exerydate = dataDiv($exerydate, 12);


$aveSteps = round(average($steps),0);
$aveExerTime = round(average($exerw),2);

$exydate = array();
$exwdate = array();
$stepdate = array();
for($ii = 0; $ii < 12; $ii++)
{
	$exydate[] = getDate($exerydate[$ii]);
}
for($ii = 0; $ii < 7; $ii++)
{
	$stepdate[] = getDate($stepsdate[$ii]);
	$exwdate[] = getDate($exerwdate[$ii]);
}
mysqli_close($db);
?>

<!DOCTYPE HTML>
<html>
<head>  
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>User Page</title>
    <script type="text/javascript">
                function myOtherFunction() {

location.href = "index.php";

}

function accountSettingsFunction() {

location.href = "accountsettings.php";


}

function myPageFunction() {

location.href = "Profilepage.php";
}


        function changeText(id) {

            if ($('#' + id).is(':checked')) {
                $('#' + id + "+span").html('Edit Mode');
                document.getElementById("Info").readOnly = false;
            } else {
                $('#' + id + "+span").html('Click for Edit Mode');
                document.getElementById("Info").readOnly = true;
            }
        }


        
        function addDataFunction() {
            document.getElementById("addData").onclick = function () {
                //location.href = "AddData.html";
            };
            location.href = "AddData.html";
        }
    </script>


<style>
.center
{
	margin: auto;
	width: 20%;
	padding: 20px;
}
        body {
            background-color: #808080;
        }

        /* Style the tab */

        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */

        .tab button {
            background-color: inherit;
            float: left;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */

        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */

        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */

        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }

        .header {
            padding: 10px 16px;
            background: #555;
            color: #f1f1f1;
            z-index: 3;
        }

        .content {
            padding: 16px;
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
        }

        .sticky+.content {
            padding-top: 102px;
        }

        #Base {
            top: 100px;
            left: 10px;
            z-index: 1;
        }

        #ProfilePic {
            position: absolute;
            top: 300px;
            left: 850px;
            z-index: 2;
        }
        .dropdown {
		    position: absolute;

		    /** Make it fit tightly around it's children */
		    display: inline-block;
		}

		.dropdown .dropdown-menu {
		    position: absolute;

		    /**
		     * Set the top of the dropdown menu to be positioned 100%
		     * from the top of the container, and aligned to the left.
		     */
		    top: 100%;
		    left: 0;

		    /** Allow no empty space between this and .dropdown */
			display: none;
		    margin: 0;

		    /****************
		     ** NEW STYLES **
		     ****************/

		    list-style: none; /** Remove list bullets */
		    width: 100%; /** Set the width to 100% of it's parent */
		    padding: 0;
			
		}
		.dropdown:hover .dropdown-menu {

		    /** Show dropdown menu */
		    display: block;
		}
</style>
<script>
window.onload = function () {
CanvasJS.addColorSet("uglyColors",[
	"#2E7D32"
	]);

var weekEx= new CanvasJS.Chart("weekEx", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Exercise Time This Week"
	},
	axisX: [{
		valueFormatString: "DD MMM"
	},
	{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Exercise Time (hours)"
	}],
	data: [{
		type: "stepLine",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $exwdate[0]["year"] .  ',' . $exwdate[0]["mon"] . ',' . $exwdate[0]["mday"] . '), y: ' . $exerw[0] . '},
			{x: new Date(' . $exwdate[1]["year"] .  ',' . $exwdate[1]["mon"] . ',' . $exwdate[1]["mday"] . '), y: ' . $exerw[1] . '},
			{x: new Date(' . $exwdate[2]["year"] .  ',' . $exwdate[2]["mon"] . ',' . $exwdate[2]["mday"] . '), y: ' . $exerw[2] . '},
			{x: new Date(' . $exwdate[3]["year"] .  ',' . $exwdate[3]["mon"] . ',' . $exwdate[3]["mday"] . '), y: ' . $exerw[3] . '},
			{x: new Date(' . $exwdate[4]["year"] .  ',' . $exwdate[4]["mon"] . ',' . $exwdate[4]["mday"] . '), y: ' . $exerw[4] . '},
			{x: new Date(' . $exwdate[5]["year"] .  ',' . $exwdate[5]["mon"] . ',' . $exwdate[5]["mday"] . '), y: ' . $exerw[5] . '},
			{x: new Date(' . $exwdate[6]["year"] .  ',' . $exwdate[6]["mon"] . ',' . $exwdate[6]["mday"] . '), y: ' . $exerw[6] . '}
			'
			?>
		]
	}]
});
var weekSteps= new CanvasJS.Chart("weekSteps", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Steps This Week"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Steps"
	}],
	data: [{
		type: "stepLine",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $stepdate[0]["year"] .  ',' . $stepdate[0]["mon"] . ',' . $stepdate[0]["mday"] . '), y: ' . $steps[0] . '},
			{x: new Date(' . $stepdate[1]["year"] .  ',' . $stepdate[1]["mon"] . ',' . $stepdate[1]["mday"] . '), y: ' . $steps[1] . '},
			{x: new Date(' . $stepdate[2]["year"] .  ',' . $stepdate[2]["mon"] . ',' . $stepdate[2]["mday"] . '), y: ' . $steps[2] . '},
			{x: new Date(' . $stepdate[3]["year"] .  ',' . $stepdate[3]["mon"] . ',' . $stepdate[3]["mday"] . '), y: ' . $steps[3] . '},
			{x: new Date(' . $stepdate[4]["year"] .  ',' . $stepdate[4]["mon"] . ',' . $stepdate[4]["mday"] . '), y: ' . $steps[4] . '},
			{x: new Date(' . $stepdate[5]["year"] .  ',' . $stepdate[5]["mon"] . ',' . $stepdate[5]["mday"] . '), y: ' . $steps[5] . '},
			{x: new Date(' . $stepdate[6]["year"] .  ',' . $stepdate[6]["mon"] . ',' . $stepdate[6]["mday"] . '), y: ' . $steps[6] . '}
			'
			?>
		]
	}]
});

var yearEx= new CanvasJS.Chart("yearEx", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Yearly Exercise Time"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Exercise Time (hours)"
	}],
	data: [{
		type: "spline",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $exydate[0]["year"] .  ',' . $exydate[0]["mon"] . ',' . $exydate[0]["mday"] . '), y: ' . $exery[0] . '},
			{x: new Date(' . $exydate[1]["year"] .  ',' . $exydate[1]["mon"] . ',' . $exydate[1]["mday"] . '), y: ' . $exery[1] . '},
			{x: new Date(' . $exydate[2]["year"] .  ',' . $exydate[2]["mon"] . ',' . $exydate[2]["mday"] . '), y: ' . $exery[2] . '},
			{x: new Date(' . $exydate[3]["year"] .  ',' . $exydate[3]["mon"] . ',' . $exydate[3]["mday"] . '), y: ' . $exery[3] . '},
			{x: new Date(' . $exydate[4]["year"] .  ',' . $exydate[4]["mon"] . ',' . $exydate[4]["mday"] . '), y: ' . $exery[4] . '},
			{x: new Date(' . $exydate[5]["year"] .  ',' . $exydate[5]["mon"] . ',' . $exydate[5]["mday"] . '), y: ' . $exery[5] . '},
			{x: new Date(' . $exydate[6]["year"] .  ',' . $exydate[6]["mon"] . ',' . $exydate[6]["mday"] . '), y: ' . $exery[6] . '},
			{x: new Date(' . $exydate[7]["year"] .  ',' . $exydate[7]["mon"] . ',' . $exydate[7]["mday"] . '), y: ' . $exery[7] . '},
			{x: new Date(' . $exydate[8]["year"] .  ',' . $exydate[8]["mon"] . ',' . $exydate[8]["mday"] . '), y: ' . $exery[8] . '},
			{x: new Date(' . $exydate[9]["year"] .  ',' . $exydate[9]["mon"] . ',' . $exydate[9]["mday"] . '), y: ' . $exery[9] . '},
			{x: new Date(' . $exydate[10]["year"] .  ',' . $exydate[10]["mon"] . ',' . $exydate[10]["mday"] . '), y: ' . $exery[10] . '},
			{x: new Date(' . $exydate[11]["year"] .  ',' . $exydate[11]["mon"] . ',' . $exydate[11]["mday"] . '), y: ' . $exery[11] . '}
			'
			?>
		]
	}]
});

weekEx.render();
weekSteps.render();
yearEx.render(); 
}
</script>
</head>
<body>

    <div class="main">
        <div class="header" id="myHeader">

            <h1><?php echo("{$_SESSION['UserName']}");?></h1>
        </div>
        <div class="tab">
            <button id="myPage" class="tablinks" onclick="myPageFunction()">My Page</button>
            <button id="accountSettings" onclick="accountSettingsFunction()">Account Settings</button>
            <div class="dropdown">

			    <!-- trigger button -->
			    <button style = "font-family:verdana; font-size:17">Add Data</button>

			    <!-- dropdown menu -->
			    <ul class="dropdown-menu">
			<li><a href="addalldata.php">Add All Data</a></li>
                	<li><a href="addsleepdata.php">Sleep Data</a></li>
                        <li><a href="Nutrition.php">Nutrition Data</a></li>
                        <li><a href="Exerisce.php">Exercise Data</a></li>
                        <li><a href="Emotional.php">Emotional Data</a></li>
                        <li><a href="Medical.php">Medical Data</a></li>


			    </ul>

			</div>
            <button class="tablinks" onclick="location.href='ReportExercise.php'" style ="padding-left:125px">Exercise</button>
	    <button id="MedicalReport" onclick="location.href='ReportMedical.php'">Medical</button>
	    <button id="MoodReport" onclick="location.href='ReportMood.php'">Mood</button>
	    <button id="NutritionReport" onclick="location.href='ReportNutrition.php'">Nutrition</button>
	    <button id="SleepReport" onclick="location.href='ReportSleep.php'">Sleep</button>
            <button id="logoutButton" onclick="myOtherFunction()">Log Out</button>
        </div>
        <div style="    text-align: center;">
            
        </div>

        
    </div>

<div style="background-color:white;margin-top:100px;margin-bottom:80px;margin-left:10%;margin-right:10%;"><br><br>
<h2 class="center">Your Exercise This Week</h2>
<div style="text-align: center;font-size:20px">To see number results please put your cursor on the dots on the chart.</div>
<div style="text-align: center;font-size:20px">To determine how long you have been exercising per day according to the exercise time graph:<br> 3-4+ hours is excellent, 2-2.9 hours is good, 1-1.9 hours is average, and .5-.9 hours is decent.<br> Anything below a .5 we recommend increasing the time you work out for.</div>
<div class="center" id="weekEx" style="height: 300px; width: 60%;"></div><br><br>
<div class="center" id="weekSteps" style="height: 300px; width: 60%;"></div><br>
<br><br></div>
<div style="background-color:white;margin-top:100px;margin-bottom:80px;margin-left:10%;margin-right:10%;"><br><br>
<h2 class="center">Your Exercise This Year</h2><br>
<div class="center" id="yearEx" style="height: 300px; width: 60%;"><br><br></div><br><br><br></div><br><br><br>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>

