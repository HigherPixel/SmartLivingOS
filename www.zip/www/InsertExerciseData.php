<?php
include "Exerisce.php";
require_once('config.php');
require_once('Fitbit.class.php');
ob_start();
session_start();

function strtodbtime($timeString)
{
	$timeString = trim($timeString);
	if(strpos($timeString, ':') !== false)
	{
		$ar1 = explode(":",$timeString);
	}
	else
	{
		return "error";
	}
	$hours = $ar1[0];
	$back = $ar1[1];
	$ar2 = explode(" ",$back);
	$minutes = $ar2[0];
	if(strpos($back,' ') !== false)
	{
		$MM = $ar2[1];
	}
	else
	{	
		$MM = "am";
	}
	$minutes = (int)$minutes;
	$hours = (int)$hours;
	$MM = strtoupper($MM);
	if(($hours > 12) or ($hours < 0))
	{
		return "error";
	}
	if(($minutes >= 60) or ($minutes < 0))
	{
		return "error";
	}
	if(!((0==strcmp("PM",$MM))or(0==strcmp("AM",$MM))))
	{
		return "error";
	}
	if((preg_match("/[a-z]/i", $minutes))or(preg_match("/[a-z]/i", $hours)))
	{
		return "error";
	}
	if((0==strcmp("PM",$MM)))
	{
		if($hours == 12)
		{
			$hours = 0;
		}
		else
		{		
			$hours = $hours + 12;
		}
	}
	$hours = (string)$hours;
	$minutes = (string)$minutes;
	if(strlen($hours)<2)
	{
		$hours = "0" . $hours;
	}
	elseif(strlen($hours)>2)
	{
		$hours =substr($hours,-2);
	}
	if(strlen($minutes)<2)
	{
		$minutes = "0" . $minutes;
	}
	elseif(strlen($minutes)>2)
	{
		$minutes = substr($minutes,-2);
	}
	return $hours . $minutes;
}

$exerisce = $_POST['ExerciseName'];
$reps = (int)$_POST['Reps'];
$sets = (int)$_POST['Sets'];
$duration = $_POST['other'];
$AccountNum = $_SESSION['AccountNum'];
$Weight = (int)$_POST['Weight'];
$dayID = $_SESSION['DayID']; 
$steps = getHeartrateIntraday();


$reps = !empty($reps) ? $reps : 0;
$sets = !empty($sets) ? $sets : 0;
$duration = !empty($duration ) ? "$duration " : "00:00";

$duration = strtodbtime($duration);
if(0==strcmp("error",$duration))
{
	echo "<script type='text/javascript'>alert('Please, use the suggested time format for the times you submit.');</script>";
}
else
{
	
	$result = mysqli_query($db,"INSERT INTO Exercise (ExerciseID,DayID,ActivityName,Duration,Repititions,Sets,Weight) values (NULL,'$dayID','$exerisce','$duration','$reps','$sets','$Weight')"); 
	$result2 = mysqli_query($db,"INSERT INTO Day (AverageHeartRate) values ('$steps')");
	if($result and $result2)
	{
		header( "Location: Profilepage.php");
	}
	else
	{
		echo("Error description:1 " . mysqli_error($db));
		echo($reps );
		echo('$reps' );
		echo($sets );
	}
}
mysqli_close($db);
?>
