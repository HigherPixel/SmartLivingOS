
<!DOCTYPE html>

<html>


<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
<style>
        #myButton {

            width: 100px;

        }

        #loginButton {

            width: 100px;

        }

        body {
            background-color: #808080;
        }
    </style>
</style>
<body>
<h1 style="text-align: center; font-size: 70px;">Smart Living OS</h1>

<div style="    text-align: center;">
    <img id="Base" style="vertical-align: middle;" src="Untitled.png" />

<form class="form-signin" action="" method="">      
<div style="text-align: center; padding-bottom: 50px; padding-top: 50px; width: 50%; margin: auto;">
            <h2 style="text-align: center; font-size: 45px;"  class="form-signin-heading">Login or Create an Account Today!</h2>
            <div class="form-group">
            <input type="text" class="form-control" name="userName" placeholder="username" required="" autofocus="" name="userName" />
            </div>
            <br>
            <div class="form-group">
            <input type="password" class="form-control" name="password" placeholder="Password" required="" name="password"/>      
            </div>
            <div style="text-align: center;">
                <input type="button" value="Login Account" name="login" onclick="alexa();"/>
                <input type="button" value="Create Account" onclick="redir();" />
            </div>

           
    </div>
</form>
<script type="text/javascript">
  function alexa()
{
    
	window.location = "https://alexa.amazon.co.jp/spa/skill/account-linking-status.html#vendorId=MHHRJ6C0ANR7X&access_token=2YotnFZFEjr1zCsicMWpAA";

}
  function redir() {
    window.location = "CA.php";
  }
</script>
