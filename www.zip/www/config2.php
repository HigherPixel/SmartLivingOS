<?php
define('CLIENT_ID', '22CRMX');
define('CLIENT_SECRET', '07a91afa304b3706969971d2baeb0a5a');
define('REDIRECT_URI', 'https://www.traxsmart.com/');
define('HOST', 'https://api.fitbit.com/');
define('ACCESS_TOKEN_URL', 'https://api.fitbit.com/oauth2/token');
define('AUTHENTICATE_URL', 'https://www.fitbit.com/oauth2/authorize');

?>