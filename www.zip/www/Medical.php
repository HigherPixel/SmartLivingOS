<?php
ob_start();
session_start();
$output = NULL;

if(isset($_POST['submit']))
{
 require_once('config.php');

 $AllergyType = $_POST["AllergyType"];  
 $AllergyStatus = $_POST["AllergyStatus"];
 $AllergyDate = $_POST["AllergyDate"];
 $AccountNum = $_SESSION['AccountNum'];

 $VisitType = $_POST["VisitType"];  
 $Reason = $_POST["Reason"];
 $clinitian = $_POST["clinitian"];
 $Specialty = $_POST["Specialty"];  
 $Facility = $_POST["Facility"];
 $EncounterDate = $_POST["EncounterDate"];

 $DiagnosisDate = $_POST["DiagnosisDate"];  
 $DiagnosisType = $_POST["DiagnosisType"];
 $DiagnosisStatus = $_POST["DiagnosisStatus"];

 $LastFilled = $_POST["LastFilled"];  
 $DatePerscribed = $_POST["DatePerscribed"];
 $Perscription = $_POST["Perscription"];
 $MedicationName = $_POST["MedicationName"];  

 $ImmunizationDate = $_POST["ImmunizationDate"];  
 $ImmunizationType = $_POST["ImmunizationType"];
 $NumberRecieved = $_POST["NumberRecieved"];
 
 $BPMeasurementDate = $_POST["BPMeasurementDate"];  
 $Systolic = $_POST["Systolic"];
 $Diastolic = $_POST["Diastolic"];

 $BSMeasurementDate = $_POST["BSMeasurementDate"];  
 $BloodSugarMeasure = $_POST["BloodSugarMeasure"];

 $CholMeasurementDate = $_POST["CholMeasurementDate"];  
 $CholMeasure = $_POST["CholMeasure"];

 
 foreach($AllergyType  AS $key => $value)
{
if(!empty($value))
{
    $result = mysqli_query($db,"INSERT INTO Allergies (AccountNum,AllergyID,AllergyType,AllergyStatus,AllergyDate) values ('$AccountNum',NULL,'".$db->real_escape_string( $AllergyType[$key])."','".$db->real_escape_string( $AllergyStatus[$key])."','".$db->real_escape_string( $AllergyDate[$key])."')");
    if(!$result )
	{
		echo("Error description: " . mysqli_error($db));

	}
 }   
}
foreach($VisitType  AS $key => $value)
{
if(!empty($value))
{
    $result = mysqli_query($db,"INSERT INTO EncounterHistory (AccountNum,EncounterID,VisitType,Reason,clinitian,Specialty,Facility,EncounterDate) values ('$AccountNum',NULL,'".$db->real_escape_string( $VisitType[$key])."','".$db->real_escape_string( $Reason[$key])."','".$db->real_escape_string( $clinitian[$key])."','".$db->real_escape_string( $Specialty[$key])."','".$db->real_escape_string( $Facility[$key])."','".$db->real_escape_string( $EncounterDate[$key])."')");
    if(!$result )
	{
		echo("Error description: " . mysqli_error($db));

	}
 }   
}
foreach($DiagnosisType  AS $key => $value)
{
if(!empty($value))
{
    $result = mysqli_query($db,"INSERT INTO Diagnosis (AccountNum,DiagnosisID,DiagnosisType,DiagnosisStatus,DiagnosisDate) values ('$AccountNum',NULL,'".$db->real_escape_string( $DiagnosisType[$key])."','".$db->real_escape_string( $DiagnosisStatus[$key])."','".$db->real_escape_string( $DiagnosisDate[$key])."')");
    if(!$result )
    {
		echo("Error description: " . mysqli_error($db));

	}
    }
}

foreach($MedicationName	  AS $key => $value)
{
if(!empty($value))
{
    $result = mysqli_query($db,"INSERT INTO Medications (AccountNum,MedicationID,MedicationName,Perscription,LastFilled,DatePerscribed) values ('$AccountNum',NULL,'".$db->real_escape_string( $MedicationName[$key])."','".$db->real_escape_string( $Perscription[$key])."','".$db->real_escape_string( $LastFilled[$key])."','".$db->real_escape_string( $DatePerscribed[$key])."')");
    if($result )
    {
		echo("Error description: " . mysqli_error($db));

	}
}   
}
foreach($ImmunizationType	  AS $key => $value)
{
if(!empty($value))
{
    $result = mysqli_query($db,"INSERT INTO Immunizations (AccountNum,ImmunizationID,ImmunizationType,ImmunizationDate,NumberRecieved) values ('$AccountNum',NULL,'".$db->real_escape_string( $ImmunizationType[$key])."','".$db->real_escape_string( $ImmunizationDate[$key])."','".$db->real_escape_string( $NumberRecieved[$key])."')");
    if($result )
    {
		echo("Error description: " . mysqli_error($db));

	}
}
    
}
foreach($Systolic  AS $key => $value)
{
if(!empty($value))
{
    $result = mysqli_query($db,"INSERT INTO BloodPressure (AccountNum,BloodPressureID,BPMeasurementDate,Systolic,Diastolic) values ('$AccountNum',NULL,'".$db->real_escape_string( $BPMeasurementDate[$key])."','".$db->real_escape_string( $Systolic[$key])."','".$db->real_escape_string( $Diastolic[$key])."')");
    if($result )
    {
		echo("Error description: " . mysqli_error($db));

	}
    
}
}
foreach($BloodSugarMeasure AS $key => $value)
{
if(!empty($value))
{
    $result = mysqli_query($db,"INSERT INTO BloodSugar (AccountNum,BloodSugarID,BSMeasurementDate,BloodSugarMeasure) values ('$AccountNum',NULL,'".$db->real_escape_string( $BSMeasurementDate[$key])."','".$db->real_escape_string( $BloodSugarMeasure[$key])."')");
    if($result )
    {
		echo("Error description: " . mysqli_error($db));

	}
    
}
}
foreach($CholMeasure  AS $key => $value)
{
if(!empty($value))
{
    $result = mysqli_query($db,"INSERT INTO Cholesterol (AccountNum,CholesterolID,CholMeasurementDate,CholMeasure) values ('$AccountNum',NULL,'".$db->real_escape_string( $CholMeasurementDate[$key])."','".$db->real_escape_string( $CholMeasure[$key])."')");
    if($result )
    {
		echo("Error description: " . mysqli_error($db));

	}
    
}
}
mysqli_close($db);
}


?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
    <title>User Page</title>
    <script type="text/javascript">
                function myOtherFunction() {
            location.href = "index.php";
        }
        function accountSettingsFunction() {
            location.href = "accountsettings.php";
        }
        function myPageFunction() {
            location.href = "Profilepage.php";
        }
        
        function addDataFunction() {
            document.getElementById("addData").onclick = function () {
                //location.href = "AddData.html";
            };
            location.href = "AddData.html";
        }
    </script>

    <style>
        #MedicalForm {
        background-color: #ffffff;
        margin: 100px auto;
        font-family: Raleway;
        padding: 40px;
        width: 90%;
        min-width: 300px;
    }
        body {background-color: #808080;        }
        /* Style the tab */
        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }
        /* Style the buttons inside the tab */
        .tab button {
            background-color: inherit;
            float: left;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }
		.dropdown {
		    position: absolute;
		    /** Make it fit tightly around it's children */
		    display: inline-block;
		}
		.dropdown .dropdown-menu {
		    position: absolute;
		    /**
		     * Set the top of the dropdown menu to be positioned 100%
		     * from the top of the container, and aligned to the left.
		     */
		    top: 100%;
		    left: 0;
		    /** Allow no empty space between this and .dropdown */
			display: none;
		    margin: 0;
		    /****************
		     ** NEW STYLES **
		     ****************/
		    list-style: none; /** Remove list bullets */
		    width: 100%; /** Set the width to 100% of it's parent */
		    padding: 0;
			
		}
		.dropdown:hover .dropdown-menu {
		    /** Show dropdown menu */
		    display: block;
		}
		
        /* Change background color of buttons on hover */
        .tab button:hover {
            background-color: #ddd;
        }
        /* Create an active/current tablink class */
        .tab button.active {
            background-color: #ccc;
        }
        /* Style the tab content */
        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }
        .header {
            padding: 10px 16px;
            background: #555;
            color: #f1f1f1;
            z-index: 3;
        }
        .content {
            padding: 16px;
        }
        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
        }
        .sticky+.content {
            padding-top: 102px;
        }
        #Base {
            top: 100px;
            left: 10px;
            z-index: 1;
        }
        #ProfilePic {
            position: absolute;
            top: 300px;
            left: 850px;
            z-index: 2;
        }
        .sidenav {
            height: 100%;
            width: 200px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #555;
            overflow-x: hidden;
            padding-top: 20px;
            border: 3px solid white;
        }
        .sidenav a {
            padding: 6px 8px 6px 16px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
        }
        .sidenav a:hover {
            color: #f1f1f1;
        }
        .main {
            margin-left: 200px;
            /* Same as the width of the sidenav */
            font-size: 28px;
            /* Increased text to enable scrolling */
            padding: 0px 0px;
        }
    </style>


<body>

    <div class="sidenav">
        <p style="color: white; font-size: 18px; text-align: center; display: block ! important;"><?php echo("Name: "."{$_SESSION['UserName']}");?></p>
        <img style="width: 100%; display: block;" src="Untitledz.png" />
        </div>

    <div class="main">
        <div class="header" id="myHeader">
            <h1><?php echo("{$_SESSION['UserName']}");?></h1>
        </div>

        <div class="tab">
            <button id="myPage" class="tablinks" onclick="myPageFunction()">My Page</button>
            <button id="accountSettings" onclick="accountSettingsFunction()">Account Settings</button>
			<div class="dropdown">

			    <!-- trigger button -->
			    <button style = "font-family:verdana; font-size:17">Add Data</button>

			    <!-- dropdown menu -->
			    <ul class="dropdown-menu">
                        <li><a href="addalldata.php">Add All Data</a></li>
                	<li><a href="addsleepdata.php">Sleep Data</a></li>
                        <li><a href="Nutrition.php">Nutrition Data</a></li>
                        <li><a href="Exerisce.php">Exercise Data</a></li>
                        <li><a href="Emotional.php">Emotional Data</a></li>
                        <li><a href="Medical.php">Medical Data</a></li>
			    </ul>

			</div>
	    <button class="tablinks" onclick="location.href='ReportExercise.php'" style ="padding-left:125px">Exercise</button>
	    <button id="MedicalReport" onclick="location.href='ReportMedical.php'">Medical</button>
	    <button id="MoodReport" onclick="location.href='ReportMood.php'">Mood</button>
	    <button id="NutritionReport" onclick="location.href='ReportNutrition.php'">Nutirtion</button>
	    <button id="SleepReport" onclick="location.href='ReportSleep.php'">Sleep</button>
            <button id="logoutButton" onclick="myOtherFunction()">Log Out</button>
        </div>
		<div>

            <form id="MedicalForm"  method="post">
                <h1>Add Medical Information</h1>

                
			        <h1>Alleries</h1>

                               <div id="dynamic_field1">  
                                     
                                         <input type="text" id="AllergyType" name="AllergyType[]" placeholder="What is your allergy?" class="form-control name_list" />
                                         <input type="text" id="AllergyStatus" name="AllergyStatus[]" placeholder="Allergy Status? (Resolved, Ongoing)" class="form-control name_list" />
                                         <input type="date" id="AllergyDate" name="AllergyDate[]" placeholder="When was your diagnosis" class="form-control name_list" /> 
                                         <button type="button" name="addAllergies" id="addAllergies" class="btn btn-success">Add More</button>  
                                    
                                    
                               </div>  
                                   
                  
                        <h1>Recent Hospital Visit</h1>

                            <div id="dynamic_field2">  
                                
                                    <input type="text" id="VisitType" name="VisitType[]" placeholder="Visit type?" class="form-control name_list" />
                                    <input type="text" id="Reason" name="Reason[]" placeholder="Reason?" class="form-control name_list" />
                                    <input type="text" id="clinitian" name="clinitian[]" placeholder="Clinician?" class="form-control name_list" />
                                    <input type="text" id="Specialty" name="Specialty[]" placeholder="Specialty?" class="form-control name_list" />
                                    <input type="text" id="Facility" name="Facility[]" placeholder="Facility?" class="form-control name_list" />
                                    <input type="date" id="EncounterDate" name="EncounterDate[]" placeholder="Encounter date?" class="form-control name_list" /> 
                                    <button type="button" name="addHospitalVisit" id="addHospitalVisit" class="btn btn-success">Add More</button>  
                                
                                
                            </div>  

                        <h1>Diagnosis History</h1>

<div id="dynamic_field3">  
    
        <input type="text" id="DiagnosisType" name="DiagnosisType[]" placeholder="Diagnosis Type?" class="form-control name_list" />
        <input type="text" id="DiagnosisStatus" name="DiagnosisStatus[]" placeholder="Diagnosis Status? (Resolved, Ongoing)" class="form-control name_list" />
        <input type="date" id="DiagnosisDate" name="DiagnosisDate[]" placeholder="Diagnosis Date?" class="form-control name_list" /> 
        <button type="button" name="addDiagnosis" id="addDiagnosis" class="btn btn-success">Add More</button>  
    
    
</div>  

<h1>Medication History</h1>

<div id="dynamic_field4">  
        <input type="text" id="MedicationName" name="MedicationName[]" placeholder="Medication Name?" class="form-control name_list" />
        <input type="text" id="Perscription" name="Perscription[]" placeholder="Perscription?" class="form-control name_list" />
        <input type="date" id="DatePerscribed" name="DatePerscribed[]" placeholder="Date Perscribed?" class="form-control name_list" />
        <input type="date" id="LastFilled" name="LastFilled[]" placeholder="Last Filled?" class="form-control name_list" /> 
        <button type="button" name="addMedications" id="addMedications" class="btn btn-success">Add More</button>  
    
    
</div>  

<h1>Immunization History</h1>

<div id="dynamic_field5">  
    
        <input type="text" id="NumberRecieved" name="NumberRecieved[]" placeholder="Number Recieved?" class="form-control name_list" />
        <input type="text" id="ImmunizationType" name="ImmunizationType[]" placeholder="Immunization Type?" class="form-control name_list" />
        <input type="date" id="ImmunizationDate" name="ImmunizationDate[]" placeholder="Immunization Date?" class="form-control name_list" /> 
        <button type="button" name="addImmunizations" id="addImmunizations" class="btn btn-success">Add More</button>  
    
    
</div>  

<h1>Blood Pressure History</h1>

<div id="dynamic_field6">  
    
        <input type="number" id="Diastolic" name="Diastolic[]" placeholder="Diastolic Measurement?" class="form-control name_list" />
        <input type="number" id="Systolic" name="Systolic[]" placeholder="Systolic Measurement?" class="form-control name_list" />
        <input type="date" id="BPMeasurementDate" name="BPMeasurementDate[]" placeholder="Diagnosis Date?" class="form-control name_list" /> 
        <button type="button" name="addBloodPressure" id="addBloodPressure" class="btn btn-success">Add More</button>  
    
    
</div>  

<h1>Blood Sugar History</h1>

<div id="dynamic_field7">  
        <input type="datetime-local" id="BSMeasurementDate" name="BSMeasurementDate[]" placeholder="Blood Sugar Measurement Date?" class="form-control name_list" />
        <input type="number" id="BloodSugarMeasure" name="BloodSugarMeasure[]" placeholder="Blood Sugar Measure?" class="form-control name_list" />
        <button type="button" name="addBloodSugar" id="addBloodSugar" class="btn btn-success">Add More</button>  
    
    
</div>  

<h1>Cholesterol History</h1>

<div id="dynamic_field8">  
    
<input type="datetime-local" id="CholMeasurementDate" name="CholMeasurementDate[]" placeholder="Cholesterol Measurement Date?" class="form-control name_list" />
        <input type="number" id="CholMeasure" name="CholMeasure[]" placeholder="Cholesterol Measure?" class="form-control name_list" />
        <button type="button" name="addCholesterol" id="addCholesterol" class="btn btn-success">Add More</button>  
    
    
</div>  


<button type="submit" name="submit" id="s" class="btn btn-success">Confirm</button>    

                
            </form>
        </div>
	</div>


</body>

</html>
<script>  
 $(document).ready(function(e){  $("#addAllergies").click(function(e)
 { 


var html = '<div><input type="text" id="ChildAllergyType" name="AllergyType[]" placeholder="What is your allergy?" class="form-control name_list" /><input type="text" id="ChildAllergyStatus" name="AllergyStatus[]" placeholder="How does it affect you?" class="form-control name_list" /><input type="date" id="ChildAllergyDate" name="AllergyDate[]" placeholder="When did you first notice?" class="form-control name_list" /><button type="button" name="addAllergies" id="Remove" class="btn btn-fail">X</button></div>';
     $("#addAllergies").click(function(e)
     {
                     $("#dynamic_field1").append(html);
         

     });
 });

$("#dynamic_field1").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});
$(document).ready(function(e){
    var hospital = '<div><input type="text" id="VisitType" name="VisitType[]" placeholder="VisitType?" class="form-control name_list" /><input type="text" id="Reason" name="Reason[]" placeholder="Reason?" class="form-control name_list" /><input type="text" id="clinitian" name="clinitian[]" placeholder="clinitian?" class="form-control name_list" /><input type="text" id="Specialty" name="Specialty[]" placeholder="Specialty?" class="form-control name_list" /><input type="text" id="Facility" name="Facility[]" placeholder="Facility?" class="form-control name_list" /><input type="date" id="EncounterDate" name="EncounterDate[]" placeholder="EncounterDate?" class="form-control name_list" /><button type="button" name="addAllergies" id="Remove" class="btn btn-fail">X</button><div> ';
$("#addHospitalVisit").click(function(e)
     {
                     $("#dynamic_field2").append(hospital);
         

     });
 

$("#dynamic_field2").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});
$(document).ready(function(e){
    var diagnosis = '<div><input type="text" id="DiagnosisType" name="DiagnosisType[]" placeholder="DiagnosisType?" class="form-control name_list" /><input type="text" id="DiagnosisStatus" name="DiagnosisStatus[]" placeholder="DiagnosisStatus?" class="form-control name_list" /><input type="date" id="DiagnosisDate" name="DiagnosisDate[]" placeholder="DiagnosisDate?" class="form-control name_list" /> <button type="button" name="addDiagnosis" id="Remove" class="btn btn-fail">X</button></div>';
$("#addDiagnosis").click(function(e)
     {
                     $("#dynamic_field3").append(diagnosis);
         

     
 });

$("#dynamic_field3").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});

$(document).ready(function(e){
    var medications = '<div><input type="text" id="MedicationName" name="MedicationName[]" placeholder="MedicationName?" class="form-control name_list" /><input type="text" id="Perscription" name="Perscription[]" placeholder="Perscription?" class="form-control name_list" /><input type="date" id="DatePerscribed" name="DatePerscribed[]" placeholder="DatePerscribed?" class="form-control name_list" /><input type="date" id="LastFilled" name="LastFilled[]" placeholder="LastFilled?" class="form-control name_list" /> <button type="button" name="addDiagnosis" id="Remove" class="btn btn-fail">X</button></div> ';
$("#addMedications").click(function(e)
     {
                     $("#dynamic_field4").append(medications);
         

     
 });

$("#dynamic_field4").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});

$(document).ready(function(e){
    var immunizations = '<div><input type="text" id="NumberRecieved" name="NumberRecieved[]" placeholder="NumberRecieved?" class="form-control name_list" /><input type="text" id="ImmunizationType" name="ImmunizationType[]" placeholder="ImmunizationType?" class="form-control name_list" /><input type="date" id="ImmunizationDate" name="ImmunizationDate[]" placeholder="ImmunizationDate?" class="form-control name_list" /> <button type="button" name="addImmunizations" id="Remove" class="btn btn-fail">X</button></div>';
$("#addImmunizations").click(function(e)
     {
                     $("#dynamic_field5").append(immunizations);
         

     
 });

$("#dynamic_field5").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});
$(document).ready(function(e){
    var BloodPressure = '<div><input type="number" id="Diastolic" name="Diastolic[]" placeholder="DiagnosisType?" class="form-control name_list" /><input type="number" id="Systolic" name="Systolic[]" placeholder="DiagnosisStatus?" class="form-control name_list" /><input type="date" id="BPMeasurementDate" name="BPMeasurementDate[]" placeholder="DiagnosisDate?" class="form-control name_list" />  <button type="button" name="addDiagnosis" id="Remove" class="btn btn-fail">X</button></div>';
$("#addBloodPressure").click(function(e)
     {
                     $("#dynamic_field6").append(BloodPressure);
         

     
 });

$("#dynamic_field6").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});

$(document).ready(function(e){
    var BloodSugar = '<div><input type="datetime-local" id="BSMeasurementDate" name="BSMeasurementDate[]" placeholder="BSMeasurementDate?" class="form-control name_list" /><input type="number" id="BloodSugarMeasure" name="BloodSugarMeasure[]" placeholder="BloodSugarMeasure?" class="form-control name_list" /><button type="button" name="addDiagnosis" id="Remove" class="btn btn-fail">X</button></div> ';
$("#addBloodSugar").click(function(e)
     {
                     $("#dynamic_field7").append(BloodSugar);
         

     
 });

$("#dynamic_field7").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});

$(document).ready(function(e){
    var Cholesterol = '<div><input type="datetime-local" id="CholMeasurementDate" name="CholMeasurementDate[]" placeholder="CholMeasurementDate?" class="form-control name_list" /><input type="number" id="CholMeasure" name="CholMeasure[]" placeholder="CholMeasure?" class="form-control name_list" /> <button type="button" name="addImmunizations" id="Remove" class="btn btn-fail">X</button></div>';
$("#addCholesterol").click(function(e)
     {
                     $("#dynamic_field8").append(Cholesterol);
         

     
 });

$("#dynamic_field8").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});






 
 </script>
   
                                    
                                 
                </div>  
            </form>
        </div>
	</div>


</body>

</html>


