<?php
session_start();
require_once('config.php');
$AccountID = $_SESSION["AccountNum"];
$q = "DELETE FROM User WHERE User.AccountNum = '$AccountID';";
$r = mysqli_query($db,$q);
if(!$r)
{
	die("Could not delete info.");
}
mysqli_close($db);
header( "Location: index.php");
?>
