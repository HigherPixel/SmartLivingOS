<?php
ob_start();
session_start();
require_once('config.php');
$AccountID = $_SESSION['AccountNum'];


?>
<!DOCTYPE HTML>

<html>

<head>
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>User Page</title>
    <script type="text/javascript">
                function myOtherFunction() {

location.href = "index.php";

}
function deleteFunction()
{
	location.href = "youAskedForIt.php";
}
function accountSettingsFunction() {

location.href = "accountsettings.php";


}

function myPageFunction() {

location.href = "Profilepage.php";
}


        function changeText(id) {

            if ($('#' + id).is(':checked')) {
                $('#' + id + "+span").html('Edit Mode');
                document.getElementById("Info").readOnly = false;
            } else {
                $('#' + id + "+span").html('Click for Edit Mode');
                document.getElementById("Info").readOnly = true;
            }
        }


        
        function addDataFunction() {
            document.getElementById("addData").onclick = function () {
                //location.href = "AddData.html";
            };
            location.href = "AddData.html";
        }
    </script>

    <style>
        body {
            background-color: #808080;
        }

        /* Style the tab */

        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */

        .tab button {
            background-color: inherit;
            float: left;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */

        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */

        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */

        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }

        .header {
            padding: 10px 16px;
            background: #555;
            color: #f1f1f1;
            z-index: 3;
        }

        .content {
            padding: 16px;
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
        }

        .sticky+.content {
            padding-top: 102px;
        }

        #Base {
            top: 100px;
            left: 10px;
            z-index: 1;
        }

        #ProfilePic {
            position: absolute;
            top: 300px;
            left: 850px;
            z-index: 2;
        }

        .sidenav {
            height: 100%;
            width: 200px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #555;
            overflow-x: hidden;
            padding-top: 20px;
            border: 3px solid white;
        }

        .sidenav a {
            padding: 6px 8px 6px 16px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
        }

        .sidenav a:hover {
            color: #f1f1f1;
        }

        .main {
            margin-left: 200px;
            /* Same as the width of the sidenav */
            font-size: 28px;
            /* Increased text to enable scrolling */
            padding: 0px 0px;
        }
        .dropdown {
		    position: absolute;

		    /** Make it fit tightly around it's children */
		    display: inline-block;
		}

		.dropdown .dropdown-menu {
		    position: absolute;

		    /**
		     * Set the top of the dropdown menu to be positioned 100%
		     * from the top of the container, and aligned to the left.
		     */
		    top: 100%;
		    left: 0;

		    /** Allow no empty space between this and .dropdown */
			display: none;
		    margin: 0;

		    /****************
		     ** NEW STYLES **
		     ****************/

		    list-style: none; /** Remove list bullets */
		    width: 100%; /** Set the width to 100% of it's parent */
		    padding: 0;
			
		}
		.dropdown:hover .dropdown-menu {

		    /** Show dropdown menu */
		    display: block;
		}
    </style>
</head>

<body>

    <div class="sidenav">
        <p style="color: white; font-size: 18px; text-align: center;"><?php echo("Name: "."{$_SESSION['UserName']}");?></p>
        <img style="width: 100%;" src="download.png" />
        
        <p style="color: white;">Stat 1</p>
        <p style="color: white;">Stat 2</p>
        <p style="color: white;">Stat 3</p>
    </div>

    <div class="main">
        <div class="header" id="myHeader">

            <h1><?php echo("Hello "."{$_SESSION['UserName']}"." , Welcome Back!");?></h1>
        </div>
        <div class="tab">
            <button id="myPage" class="tablinks" onclick="myPageFunction()">My Page</button>
            <button id="accountSettings" onclick="accountSettingsFunction()">Account Settings</button>
            <div class="dropdown">

			    <!-- trigger button -->
			    <button style = "font-family:verdana; font-size:17">Add Data</button>

			    <!-- dropdown menu -->
			    <ul class="dropdown-menu">
			<li><a href="addalldata.php">Add All Data</a></li>
                	<li><a href="addsleepdata.php">Sleep Data</a></li>
                        <li><a href="Nutrition.php">Nutrition Data</a></li>
                        <li><a href="Exerisce.php">Exercise Data</a></li>
                        <li><a href="Emotional.php">Emotional Data</a></li>
                        <li><a href="Medical.php">Medical Data</a></li>


			    </ul>

			</div>
            <button class="tablinks" onclick="location.href='ReportExercise.php'" style ="padding-left:125px">Exercise</button>
	    <button id="MedicalReport" onclick="location.href='ReportMedical.php'">Medical</button>
	    <button id="MoodReport" onclick="location.href='ReportMood.php'">Mood</button>
	    <button id="NutritionReport" onclick="location.href='ReportNutrition.php'">Nutirtion</button>
	    <button id="SleepReport" onclick="location.href='ReportSleep.php'">Sleep</button>
            <button id="logoutButton" onclick="myOtherFunction()">Log Out</button>
        </div>
        <div style="    text-align: center;">
            
        </div>
	<h1 id="PageTitle" align="center">Are you sure you want to delete your account?</h1>
	<div class="col-md-6 text-center"style="padding-top: 15px;">
            <input type="button" class="btn btn-danger" value="Yes. Delete Account." onclick="deleteFunction()">
	</div>
	<div class="col-md-6 text-center"style="padding-top: 15px;">
            <input type="button" class="btn btn-success" value="Cancel" onclick="myPageFunction()">
	</div>
    </div>

</body>


</html>

<?php
mysqli_close($db);
?>