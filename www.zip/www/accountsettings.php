<?php
ob_start();
session_start();
require_once('FitbitClient.class.php');
?>

<!DOCTYPE html>
<html>

<head>
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>Account Settings</title>
    <script>
        function myOtherFunction() {
        
			location.href = "index.php";
        }
        function accountSettingsFunction() {
            
			location.href = "accountsettings.php";
        }
        function myPageFunction() {
            
			location.href = "Profilepage.php";
        }
        function addDataFunction() {
            
			location.href = "addalldata.php";
        }
	function deleteAccountFunction()
	{
			location.href = "deleteAccount.php";
	} 
	function FBConnect() 
	{ 
		location.href = "index2.php";
	} 
	
    </script>
    <style>
        #ExerciseForm {
        background-color: #ffffff;
        margin: 100px auto;
        font-family: Raleway;
        padding: 40px;
        width: 90%;
        min-width: 300px;
        height: 600px;
    }

        body {
            background-color: #808080;
        }

        /* Style the tab */

        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */

        .tab button {
            background-color: inherit;
            float: left;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }
		.dropdown {
		    position: absolute;

		    /** Make it fit tightly around it's children */
		    display: inline-block;
		}

		.dropdown .dropdown-menu {
		    position: absolute;

		    /**
		     * Set the top of the dropdown menu to be positioned 100%
		     * from the top of the container, and aligned to the left.
		     */
		    top: 100%;
		    left: 0;

		    /** Allow no empty space between this and .dropdown */
			display: none;
		    margin: 0;

		    /****************
		     ** NEW STYLES **
		     ****************/

		    list-style: none; /** Remove list bullets */
		    width: 100%; /** Set the width to 100% of it's parent */
		    padding: 0;
			
		}
		.dropdown:hover .dropdown-menu {

		    /** Show dropdown menu */
		    display: block;
		}
		

        /* Change background color of buttons on hover */

        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */

        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */

        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }

        .header {
            padding: 10px 16px;
            background: #555;
            color: #f1f1f1;
            z-index: 3;
        }

        .content {
            padding: 16px;
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
        }

        .sticky+.content {
            padding-top: 102px;
        }

        #Base {
            top: 100px;
            left: 10px;
            z-index: 1;
        }

        #ProfilePic {
            position: absolute;
            top: 300px;
            left: 850px;
            z-index: 2;
        }

        .sidenav {
            height: 100%;
            width: 200px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #555;
            overflow-x: hidden;
            padding-top: 20px;
            border: 3px solid white;
        }

        .sidenav a {
            padding: 6px 8px 6px 16px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
        }

        .sidenav a:hover {
            color: #f1f1f1;
        }

        .main {
            margin-left: 200px;
            /* Same as the width of the sidenav */
            font-size: 28px;
            /* Increased text to enable scrolling */
            padding: 0px 0px;
        }
    </style>
</head>

<body>

    <div class="sidenav">
        <p style="color: white; font-size: 18px; text-align: center;"><?php echo("Name: "."{$_SESSION['UserName']}");?></p>
        <img style="width: 100%;" src="Untitledz.png" />

    </div>

    <div class="main">
        <div class="header" id="myHeader">
            <h1><?php echo("{$_SESSION['UserName']}");?></h1>
        </div>

        <div class="tab">
            <button id="myPage" class="tablinks" onclick="myPageFunction()">My Page</button>
            <button id="accountSettings" onclick="accountSettingsFunction()">Account Settings</button>
			<div class="dropdown">

			    <!-- trigger button -->
			    <button style = "font-family:verdana; font-size:17">Add Data</button>

			    <!-- dropdown menu -->
			    <ul class="dropdown-menu">
                <li><a href="addalldata.php">Add All Data</a></li>
                	<li><a href="addsleepdata.php">Sleep Data</a></li>
                        <li><a href="Nutrition.php">Nutrition Data</a></li>
                        <li><a href="Exerisce.php">Exercise Data</a></li>
                        <li><a href="Emotional.php">Emotional Data</a></li>
                        <li><a href="Medical.php">Medical Data</a></li>
			    </ul>

			</div>
            <button class="tablinks" onclick="location.href='ReportExercise.php'" style ="padding-left:125px">Exercise</button>
	    <button id="MedicalReport" onclick="location.href='ReportMedical.php'">Medical</button>
	    <button id="MoodReport" onclick="location.href='ReportMood.php'">Mood</button>
	    <button id="NutritionReport" onclick="location.href='ReportNutrition.php'">Nutrition</button>
	    <button id="SleepReport" onclick="location.href='ReportSleep.php'">Sleep</button>
            <button id="logoutButton" onclick="myOtherFunction()">Log Out</button>
        </div>
    <div>
        <h1 id="PageTitle"style="text-align: center;padding-bottom: 30px;">Account Settings</h1>
    
    <form id="ExerciseForm " action="UpdateUserInfo.php" method="post" style="width: 750px;margin: 0 auto;">
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="fName">First Name</label>
                <input type="text" class="form-control" name="firstname" placeholder="First Name">
            </div>
            <div class="form-group col-md-6">
                <label for="lName">Last Name</label>
                <input type="text" class="form-control" name="lastname" placeholder="Last Name">
            </div>
            <div class="form-group col-md-6">
                <label for="inputEmail4">Email</label>
                <input type="text" class="form-control" name="email" placeholder="Email">
            </div>
            <div class="form-group col-md-6">
                <label for="inputEmail5">Confirm Email</label>
                <input type="text" class="form-control" id="inputEmail5" placeholder="Confirm Email">
            </div>
            <div class="form-group col-md-6">
                <label for="inputPassword1">Current Password</label>
                <input type="password" class="form-control" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,20}" name="password" placeholder="Confirm Current Password">
            </div>
            <div class="form-group col-md-6">
                <label for="inputPassword">New Password</label>
                <input type="password" class="form-control" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,20}" name="newPassword" placeholder="Password">
            </div>
            <div class="form-group col-md-6">
                <label for="inputPassword4">Confirm Password</label>
                <input type="password" class="form-control" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,20}" name="confirmNewPassword" placeholder="Confirm Password">
            </div>
        </div>
        <div class="form-group col-md-6">
            <label for="Date">Date of Birth</label>
            <input type="date" class="form-control" name="DOB" placeholder="MM/DD/YYYY">
        </div>
        <div class="col-md-6 text-center"style="padding-top: 15px;">
            <input type="button" class="btn btn-danger" value="Delete Account" onclick="deleteAccountFunction()">
        </div>

        <div class="col-md-6 text-center"style="padding-top: 15px;">
            <button type="submit" name="button" class="btn btn-success">Confirm Changes</button>
        </div>
		
        <div class="col-md-12 text-center"style="padding-top: 15px;">
            <input type="button" class="btn btn-success" value = "Connect to Fitbit" onclick = "FBConnect()">
		</div>
		
    </form>
</div>
</body>

</html>
