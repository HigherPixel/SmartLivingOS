<?php
ob_start();
session_start();
require_once("config.php");
include "Nutrition.php";
$foodName =$_POST['FoodName'];
$dayID = $_SESSION['DayID'];
$url = 'https://api.nutritionix.com/v1_1/search/'.$foodName.'?results=0:1&fields=item_name,brand_name,item_id,nf_calories,nf_protein,nf_sugars,nf_total_fat,nf_saturated_fat,nf_cholesterol,nf_dietary_fiber,nf_sodium&appId=f213fbb8&appKey=ca5ef3fde86d5f0e53f1737ee0d36746';
$ch = curl_init(); 

        // set url 
        curl_setopt($ch, CURLOPT_URL, $url); 

        //return the transfer as a string 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
			
        // $output contains the output string 
        $output = curl_exec($ch); 
	
	$str = substr($output, strpos($output, 'item_name'));
	
	list($user, $pass, $uid, $gid, $gecos, $home, $shell, $right, $wrong, $left, $up, $down, $sleep) = explode(",", $str);
	list($a, $b) = explode(":", $user);
	list($c, $d) = explode(":", $uid);
	list($e, $f) = explode(":", $gid);
	list($g, $h) = explode(":", $gecos);
	list($i, $j) = explode(":", $home);
	list($k, $l) = explode(":", $shell);
	list($m, $n) = explode(":", $right);
	list($o, $p) = explode(":", $wrong);
	list($q, $r) = explode(":", $left);
		
        // close curl resource to free up system resources 
        curl_close($ch);      
            


$result = mysqli_query($db,"INSERT INTO FoodOrDrink (FoodID,FoodName,Calories,SaturatedFat,TransFat,Cholesterol,Sodium,DiataryFiber,Sugars,Protien) values (NULL,'$foodName','$d','$h','$f','$j','$l','$n','$p','$r')");
if($result)
{
header('Nutrition.php');
}
else
{
    echo($DayID . mysqli_error($db));
    
}
/*if(isset($_POST['createAccount']))
{
    
}*/
mysqli_close*(db);
?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 80%;
    margin-left: 200px;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style></head>
<body>

<table>
            <tr>
<th>name</th>

                <th>Calories</th>
                <th>Trans Fat</th>
		<th>Saturated Fat</th>
                <th>Cholesterol</th>
	        <th>Sodium</th>
                <th>Dietary Fiber</th>
		<th>Sugars</th>
                <th>Protein</th>

            </tr>
<?php
        echo "<tr>
<td>$foodName</td>

                    <td>$d</td>
                    <td>$h</td>
		    <td>$f</td>
                    <td>$j</td>
	            <td>$l</td>
                    <td>$n</td>
		    <td>$p</td>
                    <td>$r</td>


                </tr>";
?>
            </table>


</body>
</html>
