This is Team Fives senior capstone project. A smartOS living app. 

Team members: Marc Kliebert, Joseph Pearce, Samuel Draper, Kyndal Evans, Keith Horace, Charles Pickett, and Nadun Pullaperuma.

To work it will need a SSL certification (HTTPS)