<?php
ob_start();
session_start();
include "addalldata.php";
require_once('config.php');
require_once('FitbitClient.class.php');

//Basic Stats
$AccountNum = $_SESSION['AccountNum'];
$day = date("Y-m-d");
$dayID = $_SESSION['DayID'];

//Medical
$AllergyType = $_POST["AllergyType"];  
$AllergyStatus = $_POST["AllergyStatus"];
$AllergyDate = $_POST["AllergyDate"];
$AccountNum = $_SESSION['AccountNum'];

$VisitType = $_POST["VisitType"];  
$Reason = $_POST["Reason"];
$clinitian = $_POST["clinitian"];
$Specialty = $_POST["Specialty"];  
$Facility = $_POST["Facility"];
$EncounterDate = $_POST["EncounterDate"];

$DiagnosisDate = $_POST["DiagnosisDate"];  
$DiagnosisType = $_POST["DiagnosisType"];
$DiagnosisStatus = $_POST["DiagnosisStatus"];

$LastFilled = $_POST["LastFilled"];  
$DatePerscribed = $_POST["DatePerscribed"];
$Perscription = $_POST["Perscription"];
$MedicationName = $_POST["MedicationName"];  

$ImmunizationDate = $_POST["ImmunizationDate"];  
$ImmunizationType = $_POST["ImmunizationType"];
$NumberRecieved = $_POST["NumberRecieved"];

$BPMeasurementDate = $_POST["BPMeasurementDate"];  
$Systolic = $_POST["Systolic"];
$Diastolic = $_POST["Diastolic"];

$BSMeasurementDate = $_POST["BSMeasurementDate"];  
$BloodSugarMeasure = $_POST["BloodSugarMeasure"];

$CholMeasurementDate = $_POST["CholMeasurementDate"];  
$CholMeasure = $_POST["CholMeasure"];

//Exerisce 
$exerisce = $_POST['ExerciseName'];
$reps = $_POST['Reps'];
$sets = $_POST['Sets'];
$duration = $_POST['other'];
$Weight = $_POST['Weight'];
$Heartrate = getHeartrateIntraday();

$reps = !empty($reps) ? "$reps" : "0";
$sets = !empty($sets) ? "$sets" : "0";

//Food
$foodName =$_POST['FoodName'];

//Sleep
$duration =$_POST['Duration'];
$quality = $_POST['Quality'];
$TimeInBed =$_POST['TimeInBed'];
$TimeOutOfBed = $_POST['TimeOutOfBed'];

//Emotion
$day = date("Y-m-d");
$Anxiety = $_POST['Anxiety'];
$Anger = $_POST['Anger'];
$Sadness = $_POST['Sadness'];
$Numbness = $_POST['Numbness'];
$Rumination = $_POST['Rumination'];
$LossOfAppitite = $_POST['LossOfAppitite'];
$ExcessiveAppitite = $_POST['ExcessiveAppitite'];
$TroubleSleeping = $_POST['TroubleSleeping'];
$LowSelfEsteem = $_POST['LowSelfEsteem'];
$Mania = $_POST['Mania'];
$Tiredness = $_POST['Tiredness'];
$Unmotivated = $_POST['Unmotivated'];
$MoodSwings = $_POST['MoodSwings'];
$OverallMood = NULL;


$resulrt = mysqli_query($db,"INSERT INTO Day (DayID,AccountNum,DayDate,AverageHeartRate) values (NULL,'$AccountNum','$day','$Heartrate')");
$query = "SELECT max(DayID) FROM Day WHERE AccountNum='$AccountNum '";
$query_run = mysqli_query($db,$query);
if($query_run)
{
    if(mysqli_num_rows($query_run)>0)
    {
        $row = mysqli_fetch_array($query_run,MYSQLI_ASSOC);
                
        $_SESSION['DayID'] = $row["max(DayID)"];
        $dayID = $_SESSION['DayID'];
    }
}
$Exercise = mysqli_query($db,"INSERT INTO Exercise (ExerciseID,DayID,ActivityName,Duration,Repititions,Sets,Weight) values (NULL,'$dayID','$exerisce','$duration','$reps','$sets','$Weight')");
if($Exercise )
{
    //header( "Location: Exerisce.php");
}
else
{
    echo("Error dayquery" . mysqli_error($db));
    
}

$Mood = mysqli_query($db,"INSERT INTO Mood (DayID,Anger,Anxiety,Sadness,Numbness,Rumination,LossOfAppitite,ExcessiveAppitite,TroubleSleeping,LowSelfEsteem,Mania,Tiredness,Unmotivated,MoodSwings,OverallMood) values ('$dayID','$Anger','$Anxiety','$Sadness','$Numbness','$Rumination','$LossOfAppitite','$ExcessiveAppitite','$TroubleSleeping','$LowSelfEsteem','$Mania','$Tiredness','$Unmotivated','$MoodSwings',NULL)");
if($Mood )
{
//header("Location: Mood.php");
}
else
{
    echo("Error Mood  " . mysqli_error($db));
}
$Sleep = mysqli_query($db,"INSERT INTO sleep(DayID,Duration,Quality,TimeInBed,TimeOutOfBed) values ('$dayID','$duration','$quality','$TimeInBed','$TimeOutOfBed')");
if($Sleep )
{
    // header( "Location: DisplaySleepData.php");
}
else
{
    echo("Error Sleep : " . mysqli_error($db));
}
foreach($foodName AS $key => $value)
{

    $Food = mysqli_query($db,"INSERT INTO FoodOrDrink (FoodID,FoodName) values (NULL,'".$db->real_escape_string( $foodName[$key])."')");
	if($Food )
	{
	//header( "Location: Nutrionation.php");
	}
    
}




 foreach($AllergyType  AS $key => $value)
{

    $result = mysqli_query($db,"INSERT INTO Allergies (AccountNum,AllergyID,AllergyType,AllergyStatus,AllergyDate) values ('$AccountNum',NULL,'".$db->real_escape_string( $AllergyType[$key])."','".$db->real_escape_string( $AllergyStatus[$key])."','".$db->real_escape_string( $AllergyDate[$key])."')");
    if($result )
    {
        echo("It Worked ");

    }
	else
	{
		echo("Error AllergyType  : " . mysqli_error($db));

	}
    
}
foreach($VisitType AS $key => $value)
{

    $result = mysqli_query($db,"INSERT INTO EncounterHistory (AccountNum,EncounterID,VisitType,Reason,clinitian,Specialty,Facility,EncounterDate) values ('$AccountNum',NULL,'".$db->real_escape_string( $VisitType[$key])."','".$db->real_escape_string( $Reason[$key])."','".$db->real_escape_string( $clinitian[$key])."','".$db->real_escape_string( $Specialty[$key])."','".$db->real_escape_string( $Facility[$key])."','".$db->real_escape_string( $EncounterDate[$key])."')");
    if($result )
    {
        echo("It Worked ");

    }
	else
	{
		echo("Error VisitType: " . mysqli_error($db));

	}
    
}
foreach($DiagnosisType  AS $key => $value)
{

    $result = mysqli_query($db,"INSERT INTO Diagnosis (AccountNum,DiagnosisID,DiagnosisType,DiagnosisStatus,DiagnosisDate) values ('$AccountNum',NULL,'".$db->real_escape_string( $DiagnosisType[$key])."','".$db->real_escape_string( $DiagnosisStatus[$key])."','".$db->real_escape_string( $DiagnosisDate[$key])."')");
    if($result )
    {
        echo("It Worked ");

    }
	else
	{
		echo("Error DiagnosisType  : " . mysqli_error($db));

	}
    
}

foreach($MedicationName	  AS $key => $value)
{

    $result = mysqli_query($db,"INSERT INTO Medications (AccountNum,MedicationID,MedicationName,Perscription,LastFilled,DatePerscribed) values ('$AccountNum',NULL,'".$db->real_escape_string( $MedicationName[$key])."','".$db->real_escape_string( $Perscription[$key])."','".$db->real_escape_string( $LastFilled[$key])."','".$db->real_escape_string( $DatePerscribed[$key])."')");
    if($result )
    {
        echo("It Worked ");

    }
	else
	{
		echo("Error MedicationName: " . mysqli_error($db));

	}
    
}
foreach($ImmunizationType	  AS $key => $value)
{

    $result = mysqli_query($db,"INSERT INTO Immunizations (AccountNum,ImmunizationID,ImmunizationType,ImmunizationDate,NumberRecieved) values ('$AccountNum',NULL,'".$db->real_escape_string( $ImmunizationType[$key])."','".$db->real_escape_string( $ImmunizationDate[$key])."','".$db->real_escape_string( $NumberRecieved[$key])."')");
    if($result )
    {
        echo("It Worked ");

    }
	else
	{
		echo("Error ImmunizationType: " . mysqli_error($db));

	}
    
}
foreach($Systolic  AS $key => $value)
{

    $result = mysqli_query($db,"INSERT INTO BloodPressure (AccountNum,BloodPressureID,BPMeasurementDate,Systolic,Diastolic) values ('$AccountNum',NULL,'".$db->real_escape_string( $BPMeasurementDate[$key])."','".$db->real_escape_string( $Systolic[$key])."','".$db->real_escape_string( $Diastolic[$key])."')");
    if($result )
    {
        echo("It Worked ");

    }
	else
	{
		echo("Error Systolic  : " . mysqli_error($db));

	}
    
}

foreach($BloodSugarMeasure	  AS $key => $value)
{

    $result = mysqli_query($db,"INSERT INTO BloodSugar (AccountNum,BloodSugarID,BSMeasurementDate,BloodSugarMeasure) values ('$AccountNum',NULL,'".$db->real_escape_string( $BSMeasurementDate[$key])."','".$db->real_escape_string( $BloodSugarMeasure[$key])."')");
    if($result )
    {
        echo("It Worked ");

    }
	else
	{
		echo("Error BloodSugarMeasure: " . mysqli_error($db));

	}
    
}
foreach($CholMeasure  AS $key => $value)
{

    $result = mysqli_query($db,"INSERT INTO Cholesterol (AccountNum,CholesterolID,CholMeasurementDate,CholMeasure) values ('$AccountNum',NULL,'".$db->real_escape_string( $CholMeasurementDate[$key])."','".$db->real_escape_string( $CholMeasure[$key])."')");
    if($result )
    {
        echo("It Worked ");

    }
	else
	{
		echo("Error CholMeasure  : " . mysqli_error($db));

	}
    
}
header( "Location: Profilepage.php");


mysqli_close($db);
?>
