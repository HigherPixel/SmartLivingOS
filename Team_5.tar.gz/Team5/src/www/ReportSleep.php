<?php
ob_start();
session_start();
// Get a connection for the database
require_once('config.php');
$AccountID = $_SESSION['AccountNum'];

function dbtophptime($dbtime)
{
	$newTime = substr_replace($dbtime,':',2,0);
	$date = '2000-00-00';
	$sec = ':00';
	$TimeString = $date . $newTime . $sec;
	return strtotime($TimeString);
}

function eliminateNullData($xData, $yData)
{
	$retArX = array();
	$retArY = array();
	$n = count($xData);
	$check = count($yData);
	if($n == 0 or $check == 0)
	{
		$retArX[] = 0;
		$retArY[] = 0;
	}
	if($n != $check)
	{
		return -1;
	}
	$ii = 0;
	while($ii < $n)
	{
		$currX = $xData[$ii];
		$currY = $yData[$ii];
		if($currX != null)
		{
			$retArX[] = $currX;
			$retArY[] = $currY;  
		}
		$ii = $ii + 1;
	}
	$retAr = array($retArX, $retArY);
	return $retAr;
}

function average($array)
{
	$ii = 0;
	$sum = array_sum($array);
	$n = count($array);
	if($n == 0)
	{
		return 0;
	}
	else
	{
		return $sum/$n;
	}
}

function dataDiv($data, $n)
{
	$arrayLen = count($data);
	$subArLen = $arrayLen/$n;
	$retAr = array();
	$subAr = array();
	if($n > $arrayLen)
	{
		$lastDat = 0;
		$extra = $n - $arrayLen;
		foreach($data as $dat)
		{
			$retAr[] = $dat;
			$lastDat = $dat;
		}
		while($extra > 0)
		{
			$retAr[] = $lastDat;
			$extra--;
		}
	}
	else
	{
		$counter = 0;
		for($ii = 0; $ii < $n; $ii++) //This loop repleats n times
		{
			if($arrayLen - $counter >= $subArLen)//If there are more than subArLen empty spots in the return array
			{
				for($temp = $subArLen; $temp > 0; $temp--)//This repeats subArLen times
				{
					$subAr[] = $data[$counter];
					$counter++; 
				}
				$retAr[] = average($subAr);
				$subAr = array();
			}
			else //If there are fewer than subArLen spots left to be filled in the retAr
			{
				if($arrayLen-$counter > 0)
				{
					while($arrayLen-$counter > 0) //
					{
						$subAr[] = $data[$counter];
						$counter++;
					}
					$retAr[] = average($subAr);
				}
				else
				{
					$retAr[] = $data[$arrayLen - 1];
				}
				
			}
		}
	}
	return $retAr;
}


//Get today's date, last year's date, and last weeks date.
$todayStr = Date("Y-m-d");
$dateAr = getDate(strtotime("-1 week"));
$lastWeek = $dateAr['year'] . "-" . $dateAr['mon'] . "-" . $dateAr['mday'];
$dateAr = getDate(strtotime("-1 year"));
$lastYear = $dateAr['year'] . "-" . $dateAr['mon'] . "-" . $dateAr['mday'];

//Query the database for information.

$weekq = "select DayDate, Quality, Duration, TimeInBed, TimeOutOfBed
	from Day
	inner join sleep
	on sleep.DayID = Day.DayID
	where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = " . $AccountID . ");";

$yearq = "Select DayDate, Quality, Duration
	from Day
	inner join sleep
	on sleep.DayID = Day.DayID
	where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastYear . "') and (AccountNum = " . $AccountID . ");";

$weekResp = @mysqli_query($db, $weekq);
$yearResp = @mysqli_query($db, $yearq);

if(! $weekResp)
{
	die('Could not get data: ' . mysql_error());
}
if (! $yearResp)
{
	die('Could not get data: ' . mysql_erro());
}

$yquality = array();
$yqualitydate = array();

$yduration = array();
$ydurationdate = array();

$wquality = array();
$wqualitydate = array();

$wduration = array();
$wdurationdate = array();

$timeinbed = array();
$timeoutofbed = array();

while($wrow = mysqli_fetch_array($weekResp))
{
	$wquality[] = $wrow['Quality'];
	$wqualitydate[] = strtotime($wrow['DayDate']);

	$tempdur = dbtophptime($wrow['Duration']);
	$wduration[] = getDate($tempdur)['minutes']/60.0 + getDate($tempdur)['hours']; 
	$wdurationdate[] = strtotime($wrow['DayDate']);

	$temptimeinbed = dbtophptime($wrow['TimeInBed']);
	$timeinbed[] = getDate($temptimeinbed)['minutes']/60.0 + getDate($temptimeinbed)['hours'];

	$temptimeoutofbed = dbtophptime($wrow['TimeOutOfBed']);
	$timeoutofbed[] = getDate($temptimeoutofbed)['minutes']/60.0 + getDate($temptimeoutofbed)['hours'];
}

while($yrow = mysqli_fetch_array($yearResp))
{
	$yquality[] = $yrow['Quality'];
	$yqualitydate[] = strtotime($yrow['DayDate']);

	$tempdur = dbtophptime($yrow['Duration']);
	$yduration[] = getDate($tempdur)['minutes']/60.0 + getDate($tempdur)['hours'];
	$ydurationdate[] = strtotime($yrow['DayDate']);
}

$y1 = eliminateNullData($yduration, $ydurationdate);
$y2 = eliminateNullData($yquality, $yqualitydate);
$w1 = eliminateNullData($wquality, $wqualitydate);
$w2 = eliminateNullData($wduration, $wdurationdate);
$d1 = eliminateNullData($timeinbed,$wdurationdate);
$d2 = eliminateNullData($timeoutofbed,$wdurationdate);


$yquality = $y2[0];
$yqualitydate = $y2[1];

$yduration = $y1[0];
$ydurationdate = $y1[1];

$wquality = $w1[0];
$wqualitydate = $w1[1];

$wduration = $w2[0];
$wdurationdate = $w2[1];

$timeinbed = $d1[0];
$timeoutofbed = $d2[0];

array_multisort($yqualitydate,SORT_ASC, SORT_NUMERIC, $yquality);
array_multisort($ydurationdate,SORT_ASC, SORT_NUMERIC, $yduration);
array_multisort($wqualitydate,SORT_ASC, SORT_NUMERIC, $wquality);
array_multisort($wdurationdate,SORT_ASC, SORT_NUMERIC, $wduration);


$yquality = dataDiv($yquality, 12);
$yqualitydate = dataDiv($yqualitydate, 12);

$yduration = dataDiv($yduration, 12);
$ydurationdate = dataDiv($ydurationdate, 12);

$wquality = dataDiv($wquality, 7);
$wqualitydate = dataDiv($wqualitydate, 7);

$wduration = dataDiv($wduration, 7);
$wdurationdate = dataDiv($wdurationdate, 7);

/*
$newTime = substr_replace($dbtime,':',2,0);
$date = '2000-00-00';
$sec = ':00';
$TimeString = $date . $newTime . $sec;
return strtotime($TimeString);
*/


$avetimeinbed = average($timeinbed);
$avetimeoutofbed = average($timeoutofbed);
$avetimeasleep = average($wduration);
if($avetimeinbed > $avetimeoutofbed)
{
	$twentyfourhours = strtotime('2000-00-01 00:00:00');
	$timetillmidnight = -$twentyfourhours + $avetimeinbed;
	$timeawakeinbed = ($timetillmidnight + $avetimeoutofbed) - $avetimeasleep;	
}
else
{
	$timeawakeinbed = ($avetimeoutofbed - $avetimeinbed) - $avetimeasleep;
}
$timeawakeinbed = round((float)getDate($timeawakeinbed)["hours"] + (float)getDate($timeawakeinbed)["minutes"]/60.0,2);

$yqualdate = array();
$ydurdate = array();
$wqualdate = array();
$wdurdate = array();
for($ii = 0; $ii < 12; $ii++)
{
	$yqualdate[] = getDate($yqualitydate[$ii]);
	$ydurdate[] = getDate($ydurationdate[$ii]);
}
for($ii = 0; $ii < 7; $ii++)
{
	$wqualdate[] = getDate($wqualitydate[$ii]);
	$wdurdate[] = getDate($wdurationdate[$ii]);
}


mysqli_close($db);
?>

<!DOCTYPE HTML>
<html>
<head> 
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>User Page</title>
    <script type="text/javascript">
                function myOtherFunction() {

location.href = "index.php";

}

function accountSettingsFunction() {

location.href = "accountsettings.php";


}

function myPageFunction() {

location.href = "Profilepage.php";
}


        function changeText(id) {

            if ($('#' + id).is(':checked')) {
                $('#' + id + "+span").html('Edit Mode');
                document.getElementById("Info").readOnly = false;
            } else {
                $('#' + id + "+span").html('Click for Edit Mode');
                document.getElementById("Info").readOnly = true;
            }
        }


        
        function addDataFunction() {
            document.getElementById("addData").onclick = function () {
                //location.href = "AddData.html";
            };
            location.href = "AddData.html";
        }
    </script>
 
<style>
.center
{
	margin: auto;
	width: 20%;
	padding: 20px;
}
        body {
            background-color: #808080;
        }

        /* Style the tab */

        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */

        .tab button {
            background-color: inherit;
            float: left;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */

        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */

        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */

        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }

        .header {
            padding: 10px 16px;
            background: #555;
            color: #f1f1f1;
            z-index: 3;
        }

        .content {
            padding: 16px;
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
        }

        .sticky+.content {
            padding-top: 102px;
        }

        #Base {
            top: 100px;
            left: 10px;
            z-index: 1;
        }

        #ProfilePic {
            position: absolute;
            top: 300px;
            left: 850px;
            z-index: 2;
        }

        .dropdown {
		    position: absolute;

		    /** Make it fit tightly around it's children */
		    display: inline-block;
		}

		.dropdown .dropdown-menu {
		    position: absolute;

		    /**
		     * Set the top of the dropdown menu to be positioned 100%
		     * from the top of the container, and aligned to the left.
		     */
		    top: 100%;
		    left: 0;

		    /** Allow no empty space between this and .dropdown */
			display: none;
		    margin: 0;

		    /****************
		     ** NEW STYLES **
		     ****************/

		    list-style: none; /** Remove list bullets */
		    width: 100%; /** Set the width to 100% of it's parent */
		    padding: 0;
			
		}
		.dropdown:hover .dropdown-menu {

		    /** Show dropdown menu */
		    display: block;
		}
</style>

<script>
window.onload = function () {
CanvasJS.addColorSet("uglyColors",[
	"#003399"
	]);

var wquality= new CanvasJS.Chart("chartContainer", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Sleep Quality"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Quality"
	}],
	data: [{
		type: "stepLine",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $wqualdate[0]["year"] .  ',' . $wqualdate[0]["mon"] . ',' . $wqualdate[0]["mday"] . '), y: ' . $wquality[0] . '},
			{x: new Date(' . $wqualdate[1]["year"] .  ',' . $wqualdate[1]["mon"] . ',' . $wqualdate[1]["mday"] . '), y: ' . $wquality[1] . '},
			{x: new Date(' . $wqualdate[2]["year"] .  ',' . $wqualdate[2]["mon"] . ',' . $wqualdate[2]["mday"] . '), y: ' . $wquality[2] . '},
			{x: new Date(' . $wqualdate[3]["year"] .  ',' . $wqualdate[3]["mon"] . ',' . $wqualdate[3]["mday"] . '), y: ' . $wquality[3] . '},
			{x: new Date(' . $wqualdate[4]["year"] .  ',' . $wqualdate[4]["mon"] . ',' . $wqualdate[4]["mday"] . '), y: ' . $wquality[4] . '},
			{x: new Date(' . $wqualdate[5]["year"] .  ',' . $wqualdate[5]["mon"] . ',' . $wqualdate[5]["mday"] . '), y: ' . $wquality[5] . '},
			{x: new Date(' . $wqualdate[6]["year"] .  ',' . $wqualdate[6]["mon"] . ',' . $wqualdate[6]["mday"] . '), y: ' . $wquality[6] . '}'
			?>
		]
	}]
});
var wduration= new CanvasJS.Chart("wduration", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Sleep Duration"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Duration (hours)"
	}],
	data: [{
		type: "stepLine",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $wdurdate[0]["year"] .  ',' . $wdurdate[0]["mon"] . ',' . $wdurdate[0]["mday"] . '), y: ' . $wduration[0] . '},
			{x: new Date(' . $wdurdate[1]["year"] .  ',' . $wdurdate[1]["mon"] . ',' . $wdurdate[1]["mday"] . '), y: ' . $wduration[1] . '},
			{x: new Date(' . $wdurdate[2]["year"] .  ',' . $wdurdate[2]["mon"] . ',' . $wdurdate[2]["mday"] . '), y: ' . $wduration[2] . '},
			{x: new Date(' . $wdurdate[3]["year"] .  ',' . $wdurdate[3]["mon"] . ',' . $wdurdate[3]["mday"] . '), y: ' . $wduration[3] . '},
			{x: new Date(' . $wdurdate[4]["year"] .  ',' . $wdurdate[4]["mon"] . ',' . $wdurdate[4]["mday"] . '), y: ' . $wduration[4] . '},
			{x: new Date(' . $wdurdate[5]["year"] .  ',' . $wdurdate[5]["mon"] . ',' . $wdurdate[5]["mday"] . '), y: ' . $wduration[5] . '},
			{x: new Date(' . $wdurdate[6]["year"] .  ',' . $wdurdate[6]["mon"] . ',' . $wdurdate[6]["mday"] . '), y: ' . $wduration[6] . '}'
			?>
		]
	}]
});

var yquality= new CanvasJS.Chart("yquality", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Sleep Quality"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Quality"
	}],
	data: [{
		type: "spline",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $yqualdate[0]["year"] .  ',' . $yqualdate[0]["mon"] . ',' . $yqualdate[0]["mday"] . '), y: ' . $yquality[0] . '},
			{x: new Date(' . $yqualdate[1]["year"] .  ',' . $yqualdate[1]["mon"] . ',' . $yqualdate[1]["mday"] . '), y: ' . $yquality[1] . '},
			{x: new Date(' . $yqualdate[2]["year"] .  ',' . $yqualdate[2]["mon"] . ',' . $yqualdate[2]["mday"] . '), y: ' . $yquality[2] . '},
			{x: new Date(' . $yqualdate[3]["year"] .  ',' . $yqualdate[3]["mon"] . ',' . $yqualdate[3]["mday"] . '), y: ' . $yquality[3] . '},
			{x: new Date(' . $yqualdate[4]["year"] .  ',' . $yqualdate[4]["mon"] . ',' . $yqualdate[4]["mday"] . '), y: ' . $yquality[4] . '},
			{x: new Date(' . $yqualdate[5]["year"] .  ',' . $yqualdate[5]["mon"] . ',' . $yqualdate[5]["mday"] . '), y: ' . $yquality[5] . '},
			{x: new Date(' . $yqualdate[6]["year"] .  ',' . $yqualdate[6]["mon"] . ',' . $yqualdate[6]["mday"] . '), y: ' . $yquality[6] . '},
			{x: new Date(' . $yqualdate[7]["year"] .  ',' . $yqualdate[7]["mon"] . ',' . $yqualdate[7]["mday"] . '), y: ' . $yquality[7] . '},
			{x: new Date(' . $yqualdate[8]["year"] .  ',' . $yqualdate[8]["mon"] . ',' . $yqualdate[8]["mday"] . '), y: ' . $yquality[8] . '},
			{x: new Date(' . $yqualdate[9]["year"] .  ',' . $yqualdate[9]["mon"] . ',' . $yqualdate[9]["mday"] . '), y: ' . $yquality[9] . '},
			{x: new Date(' . $yqualdate[10]["year"] .  ',' . $yqualdate[10]["mon"] . ',' . $yqualdate[10]["mday"] . '), y: ' . $yquality[10] . '},
			{x: new Date(' . $yqualdate[11]["year"] .  ',' . $yqualdate[11]["mon"] . ',' . $yqualdate[11]["mday"] . '), y: ' . $yquality[11] . '}'
			?>
		]
	}]
});

var yduration= new CanvasJS.Chart("yduration", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Sleep Duration"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Duration (hours)"
	}],
	data: [{
		type: "spline",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $ydurdate[0]["year"] .  ',' . $ydurdate[0]["mon"] . ',' . $ydurdate[0]["mday"] . '), y: ' . $yduration[0] . '},
			{x: new Date(' . $ydurdate[1]["year"] .  ',' . $ydurdate[1]["mon"] . ',' . $ydurdate[1]["mday"] . '), y: ' . $yduration[1] . '},
			{x: new Date(' . $ydurdate[2]["year"] .  ',' . $ydurdate[2]["mon"] . ',' . $ydurdate[2]["mday"] . '), y: ' . $yduration[2] . '},
			{x: new Date(' . $ydurdate[3]["year"] .  ',' . $ydurdate[3]["mon"] . ',' . $ydurdate[3]["mday"] . '), y: ' . $yduration[3] . '},
			{x: new Date(' . $ydurdate[4]["year"] .  ',' . $ydurdate[4]["mon"] . ',' . $ydurdate[4]["mday"] . '), y: ' . $yduration[4] . '},
			{x: new Date(' . $ydurdate[5]["year"] .  ',' . $ydurdate[5]["mon"] . ',' . $ydurdate[5]["mday"] . '), y: ' . $yduration[5] . '},
			{x: new Date(' . $ydurdate[6]["year"] .  ',' . $ydurdate[6]["mon"] . ',' . $ydurdate[6]["mday"] . '), y: ' . $yduration[6] . '},
			{x: new Date(' . $ydurdate[7]["year"] .  ',' . $ydurdate[7]["mon"] . ',' . $ydurdate[7]["mday"] . '), y: ' . $yduration[7] . '},
			{x: new Date(' . $ydurdate[8]["year"] .  ',' . $ydurdate[8]["mon"] . ',' . $ydurdate[8]["mday"] . '), y: ' . $yduration[8] . '},
			{x: new Date(' . $ydurdate[9]["year"] .  ',' . $ydurdate[9]["mon"] . ',' . $ydurdate[9]["mday"] . '), y: ' . $yduration[9] . '},
			{x: new Date(' . $ydurdate[10]["year"] .  ',' . $ydurdate[10]["mon"] . ',' . $ydurdate[10]["mday"] . '), y: ' . $yduration[10] . '},
			{x: new Date(' . $ydurdate[11]["year"] .  ',' . $ydurdate[11]["mon"] . ',' . $ydurdate[11]["mday"] . '), y: ' . $yduration[11] . '}'
			?>
		]
	}]
});

wquality.render();
wduration.render();
yquality.render();
yduration.render();

}
</script>
</head>
<body>

    <div class="main">
        <div class="header" id="myHeader">

            <h1><?php echo("{$_SESSION['UserName']}");?></h1>
        </div>
        <div class="tab">
            <button id="myPage" class="tablinks" onclick="myPageFunction()">My Page</button>
            <button id="accountSettings" onclick="accountSettingsFunction()">Account Settings</button>
            <div class="dropdown">

			    <!-- trigger button -->
			    <button style = "font-family:verdana; font-size:17">Add Data</button>

			    <!-- dropdown menu -->
			    <ul class="dropdown-menu">
			<li><a href="addalldata.php">Add All Data</a></li>
                	<li><a href="addsleepdata.php">Sleep Data</a></li>
                        <li><a href="Nutrition.php">Nutrition Data</a></li>
                        <li><a href="Exerisce.php">Exercise Data</a></li>
                        <li><a href="Emotional.php">Emotional Data</a></li>
                        <li><a href="Medical.php">Medical Data</a></li>


			    </ul>

			</div>
            <button class="tablinks" onclick="location.href='ReportExercise.php'" style ="padding-left:125px">Exercise</button>
	    <button id="MedicalReport" onclick="location.href='ReportMedical.php'">Medical</button>
	    <button id="MoodReport" onclick="location.href='ReportMood.php'">Mood</button>
	    <button id="NutritionReport" onclick="location.href='ReportNutrition.php'">Nutrition</button>
	    <button id="SleepReport" onclick="location.href='ReportSleep.php'">Sleep</button>
            <button id="logoutButton" onclick="myOtherFunction()">Log Out</button>
        </div>
        <div style="    text-align: center;">
            
        </div>

        
    </div>

<div style="background-color:white;margin-top:100px;margin-bottom:80px;margin-left:10%;margin-right:10%;"><br><br>
	<h2 class="center">Your Sleep This Week</h2>
	<div style="text-align: center;font-size:20px">To see number results please put your cursor on the dots on the chart.</div>
	<div style="text-align: center;font-size:20px">To determine how well your sleep quality is according to the sleep quality graph:<br> 8-10 is excellent, 6-7 is good, 5 is average, 3-4 is poor, and 0-2 is very poor. <br>Anything below a 5 we recommend changes in your lifestyle to improve this.</div>
	<div style="text-align: center;font-size:20px">To determine how long you are sleeping according to the sleep duration graph:<br> 7-9 hours is excellent, 7 hours is good, 6 hours is average, and 0-4 hours is poor. <br>Anything below a 6 we recommend changes in your lifestyle to improve this.</div>
	<p class="center"> On average this week you spent <?php echo $timeawakeinbed?> hours awake in bed per day. </p><br>
	<div class="center" id="chartContainer" style="height: 300px; width: 60%;"></div><br><br>
	<div class="center" id="wduration" style="height: 300px; width: 60%;"></div><br><br><br>
</div>
<div style="background-color:white;margin-top:100px;margin-bottom:80px;margin-left:10%;margin-right:10%;"><br><br>
	<h2 class="center">Your Sleep This Year</h2><br>
	<div class="center" id="yquality" style="height: 300px; width: 60%;"></div><br><br>
	<div class="center" id="yduration" style="height: 300px; width: 60%;"></div><br><br><br>
</div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<br><br><br>
</body>
</html>



