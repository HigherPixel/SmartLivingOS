<?php namespace djchen\OAuth2\Client\Provider;

require __DIR__.'/vendor/autoload.php';
require __DIR__.'/vendor/oauth2-fitbit-master/src/Provider/Fitbit.php';
require __DIR__.'/vendor/oauth2-fitbit-master/src/Provider/FitbitUser.php';
use djchen\Oauth2\Client\Provider\Fitbit;
use djchen\Oauth2\Client\Provider\FitbitUser;

$provider = new Fitbit([
    'clientId'          => '{22CRMX}',
    'clientSecret'      => '{07a91afa304b3706969971d2baeb0a5a}',
    'redirectUri'       => 'https://www.traxsmart.com'
]);

    ob_start();
    ini_set('session.save_path',realpath(dirname($_SERVER['DOCUMENT_ROOT']) . '/var/php_sessions'));
    session_start();

// If we don't have an authorization code then get one
if (!isset($_GET['code'])) {
    echo "going down this path \n";
    // Fetch the authorization URL from the provider; this returns the
    // urlAuthorize option and generates and applies any necessary parameters
    // (e.g. state).
    $authorizationUrl = 'https://www.fitbit.com/oauth2/authorize?response_type=code&client_id=22CRMX&redirect_uri=https%3A%2F%2Fwww.traxsmart.com&scope=activity%20heartrate%20location%20nutrition%20profile%20settings%20sleep%20social%20weight&expires_in=604800';

    // Get the state generated for you and store it to the session.
    $_SESSION['oauth2state'] = $provider->getState();

    // Redirect the user to the authorization URL.
    header('Location: ' . $authorizationUrl);
    exit;

// Check given state against previously stored one to mitigate CSRF attack
} elseif (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {
    echo $_SESSION['oauth2state'] . " is the oauth2state saved \n";
    echo $_GET['state'] . " is the get_state \n";
    unset($_SESSION['oauth2state']);
    exit('Invalid state');


} else {
    try {

        // Try to get an access token using the authorization code grant.
        $accessToken = $provider->getAccessToken('authorization_code', ['code' => $_GET['code']]);
        echo "still going...";


        // The provider provides a way to get an authenticated API request for
        // the service, using the access token; it returns an object conforming
        // to Psr\Http\Message\RequestInterface.
        $request1 = $provider->getAuthenticatedRequest(
            Fitbit::METHOD_GET,
            Fitbit::BASE_FITBIT_API_URL . '/1/user/-/profile.json',
            $accessToken,
            ['headers' => [Fitbit::HEADER_ACCEPT_LANG => 'en_US'], [Fitbit::HEADER_ACCEPT_LOCALE => 'en_US']]
            // Fitbit uses the Accept-Language for setting the unit system used
            // and setting Accept-Locale will return a translated response if available.
            // https://dev.fitbit.com/docs/basics/#localization
        );
        // Make the authenticated API request and get the parsed response.
        $response1 = $provider->getParsedResponse($request1);



        //eventually will set variables here...

        $deviceSpecificID=$response1['user']['encodedId'];
        $firstName=$response1['user']['firstName'];
        $lastName=$response1['user']['lastName'];

        //making repeat request to get more data
        $request2 = $provider->getAuthenticatedRequest(
            Fitbit::METHOD_GET,
            Fitbit::BASE_FITBIT_API_URL . '/1/user/-/activities/date/2017-09-23.json',
            $accessToken,
            ['headers' => [Fitbit::HEADER_ACCEPT_LANG => 'en_US'], [Fitbit::HEADER_ACCEPT_LOCALE => 'en_US']]);
        $response2=$provider->getParsedResponse($request2);

        $stepsToday=$response2['summary']['steps'];
        $stepGoal=$response2['goals']['steps'];

        $todaysDate=date("Y-m-d");
        //add variables to the session
        $_SESSION['loggedin']=True;
        $_SESSION['device']="fitbit";
        $_SESSION['deviceSpecificID']=$deviceSpecificID;
        $_SESSION['firstName'] = $firstName;
        $_SESSION['lastName']=$lastName;
        $_SESSION['activityArray']=$activityArray;
        $_SESSION['steps']=$stepsToday;
        $_SESSION['dailyGoal']=$stepGoal;
        $_SESSION['todaysDate']=$todaysDate;

    } catch (\League\OAuth2\Client\Provider\Exception\IdentityProviderException $e) {
        // Failed to get the access token or user details.
        exit($e->getMessage());
    }
}
?>