<?php
include "accountsettings.php";
require_once('config.php');

$accountNum = $_SESSION['AccountNum'];
$password = $_SESSION['Password'];
$currentpassword = $_POST['password'];
$newpassword = $_POST['newPassword'];
$confpassword = $_POST['confirmNewPassword'];
if(($confpassword == $currentpassword) and ($currentpassword == $password))
{
	if(! empty($_POST['firstname']))
	{
		$var = $_POST['firstname'];
		$sql = "UPDATE User SET FirstName='$var' WHERE AccountNum='$accountNum';";
		$result = mysqli_query($db,$sql);
		if(!$result)
		{
			echo("There was a problem updating your data: " . mysqli_error($db));
		}
	}	
	if(! empty($_POST['lastname']))
	{
		$var = $_POST['lastname'];
		$sql = "UPDATE User SET LastName='$var' WHERE AccountNum='$accountNum';";
		$result = mysqli_query($db,$sql);
		if(!$result)
		{
			echo("There was a problem updating your data: " . mysqli_error($db));
		}
	}
	if(! empty($_POST['userName']))
	{
		$var = $_POST['userName'];
		$sql = "UPDATE User SET UserName='$var' WHERE AccountNum='$accountNum';";
		$result = mysqli_query($db,$sql);
		if(!$result)
		{
			echo("There was a problem updating your data: " . mysqli_error($db));
		}
	}
	if(! empty($_POST['newPassword']))
	{
		$var = $_POST['newPassword'];
		$sql = "UPDATE User SET Password='$var' WHERE AccountNum='$accountNum';";
		$result = mysqli_query($db,$sql);
		if(!$result)
		{
			echo("There was a problem updating your data: " . mysqli_error($db));
		}
	}
	if(! empty($_POST['DOB']))
	{	
		$var = $_POST['DOB'];
		$sql = "UPDATE User SET DOB='$var' WHERE AccountNum='$accountNum';";
		$result = mysqli_query($db,$sql);
		if(!$result)
		{
			echo("There was a problem updating your data: " . mysqli_error($db));
		}
	}
	if(! empty($_POST['email']))
	{	
		if($_POST['email'] == $_POST['inputEmail5'])
		{
			$var = $_POST['email'];
			$sql = "UPDATE User SET Email='$var' WHERE AccountNum='$accountNum';";
			$result = mysqli_query($db,$sql);
			if(!$result)
			{
				echo("There was a problem updating your data: " . mysqli_error($db));
			}
		}
	}
	header( "Location: accountsettings.php");
}
mysqli_close($db);

?>
