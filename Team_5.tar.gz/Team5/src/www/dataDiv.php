<?php
function average($array)
{
	$ii = 0;
	$sum = 0.0;
	$n = count($array);
	while($ii < $n)
	{
		$sum = $array[$ii] + $sum;
		$ii = $ii + 1;
	}
	return $sum/$n;
}


function dataDiv($data, $n)
{
	$points = count($data);
	$retAr = array();
	if(($points%$n)!=0)
	{
		//$n = $n-1;
	}
	$nsize = $points/$n;
	if($nsize <= 1)
	{
		//Then there are fewer than n data points.
		$saveLast = 0;
		foreach($data as $dat)
		{
			$n = $n - 1;
			$retAr[] = $dat;
			$saveLast = $dat;
		}
		while($n != 0)
		{
			$n = $n - 1;
			$retAr[] = $saveLast;
		}
	} 
	else
	{
		$tempAr = array();
		$tempn = $nsize;
		foreach($data as $dat)
		{
			$tempn = $tempn - 1;
			$tempAr[] = $dat;
			if($tempn <= 0)
			{
				$retAr[] = average($tempAr);
				$tempAr = array();
				$tempn = $nsize;
			}
		}
		if(count($tempAr) != 0)
		{
			$retAr[] = average($tempAr);
		}
	}
	return $retAr;
}

$ar = [1,2,3,4,5,6];
echo implode(',',dataDiv($ar, 4));

?>
