<?php
include "addsleepdata.php";
require_once('config.php');
ob_start();
session_start();
function strtodbtime($timeString)
{
	$timeString = trim($timeString);
	if(strpos($timeString, ':') !== false)
	{
		$ar1 = explode(":",$timeString);
	}
	else
	{
		return "error";
	}
	$hours = $ar1[0];
	$back = $ar1[1];
	$ar2 = explode(" ",$back);
	$minutes = $ar2[0];
	if(strpos($back,' ') != false)
	{
		$MM = $ar2[1];
	}
	else
	{	
		$MM = "am";
	}
	$minutes = (int)$minutes;
	$hours = (int)$hours;
	$MM = strtoupper($MM);
	if(($hours > 12) or ($hours < 0))
	{
		return "error";
	}
	if(($minutes >= 60) or ($minutes < 0))
	{
		return "error";
	}
	if(!((0==strcmp("PM",$MM))or(0==strcmp("AM",$MM))))
	{
		return "error";
	}
	if((preg_match("/[a-z]/i", $minutes))or(preg_match("/[a-z]/i", $hours)))
	{
		return "error";
	}
	if((0==strcmp("PM",$MM)))
	{
		if($hours == 12)
		{
			$hours = 0;
		}
		else
		{		
			$hours = $hours + 12;
		}
	}
	$hours = (string)$hours;
	$minutes = (string)$minutes;
	if(strlen($hours)<2)
	{
		$hours = "0" . $hours;
	}
	elseif(strlen($hours)>2)
	{
		$hours =substr($hours,-2);
	}
	if(strlen($minutes)<2)
	{
		$minutes = "0" . $minutes;
	}
	elseif(strlen($minutes)>2)
	{
		$minutes = substr($minutes,-2);
	}
	return $hours . $minutes;
}

$duration =$_POST['Duration'];
$quality = $_POST['Quality'];
$TimeInBed =$_POST['TimeInBed'];
$TimeOutOfBed = $_POST['TimeOutOfBed'];
$AccountID = $_SESSION['AccountNum'];
$DayID = $_SESSION['DayID'];
$TimeInBed = strtodbtime($TimeInBed);
$TimeOutOfBed = strtodbtime($TimeOutOfBed);
$duration = strtodbtime($duration);

if((0==strcmp("error",$TimeOutOfBed))or(0==strcmp("error",$TimeInBed))or(0==strcmp("error",$Duration)))
{
	echo "<script type='text/javascript'>alert('Please, use the suggested time format for the times you submit.');</script>";
}
else
{
	$testStr = "select * from sleep where DayID='$DayID';";
	$test = mysqli_query($db, $testStr);
	if(!$test)
	{
		die("connection to mysql failed");
	}
	if(0 !== mysqli_num_rows($test))
	{
		$result = mysqli_query($db,"UPDATE sleep SET Duration='$duration', Quality='$quality',TimeInBed='$TimeInBed',TimeOutOfBed='$TimeOutOfBed' WHERE sleep.DayID='$DayID';");
	}
	else
	{
		$result = mysqli_query($db,"INSERT INTO sleep(DayID,Duration,Quality,TimeInBed,TimeOutOfBed) values ('$DayID','$duration','$quality','$TimeInBed','$TimeOutOfBed')");
	}
	if($result)
	{
    	 	header( "Location: Profilepage.php");
	}
	else
	{
     		echo("Error description: " . mysqli_error($db));
	}
}
mysqli_close($db);
?>
