<?php
$time = '0050';
$newTime = substr_replace($time,':',2,0);
$date = '2000-00-00 ';
$sec = ':00';
$TimeString = $date . $newTime . $sec;
//echo $TimeString;
$time1 = strtotime($TimeString);


$time = '0123';
$newTime = substr_replace($time,':',2,0);
$date = '2000-00-00 ';
$sec = ':00';
$TimeString = $date . $newTime . $sec;
$time2 = strtoTime($TimeString);

$FinalTime = $time1 + $time2;

$timeArray = getDate($FinalTime);
echo($timeArray['hours'] . ":" . $timeArray['minutes']);
?>
