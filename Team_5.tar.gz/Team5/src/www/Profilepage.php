<?php
ob_start();
session_start();
$output = NULL;

require_once('config.php');
$AccountID = $_SESSION['AccountNum'];

function dbtophptime($dbtime)
{
	$newTime = substr_replace($dbtime,':',2,0);
	$date = '2000-00-00';
	$sec = ':00';
	$TimeString = $date . $newTime . $sec;
	return strtotime($TimeString);
}

function eliminateNullData($xData, $yData)
{
	$retArX = array();
	$retArY = array();
	$n = count($xData);
	$check = count($yData);
	if($n != $check)
	{
		return -1;
	}
	$ii = 0;
	while($ii < $n)
	{
		$currX = $xData[$ii];
		$currY = $yData[$ii];
		if($currX != null)
		{
			$retArX[] = $currX;
			$retArY[] = $currY;  
		}
		$ii = $ii + 1;
	}
	$retAr = array($retArX, $retArY);
	return $retAr;
}

function average($array)
{
	$ii = 0;
	$sum = array_sum($array);
	$n = count($array);
	if($n == 0)
	{
		return 0;
	}
	else
	{
		return $sum/$n;
	}
}

function dataDiv($data, $n)
{
	$arrayLen = count($data);
	$subArLen = $arrayLen/$n;
	$retAr = array();
	$subAr = array();
	if($n > $arrayLen)
	{
		$lastDat = 0;
		$extra = $n - $arrayLen;
		foreach($data as $dat)
		{
			$retAr[] = $dat;
			$lastDat = $dat;
		}
		while($extra > 0)
		{
			$retAr[] = $lastDat;
			$extra--;
		}
	}
	else
	{
		$counter = 0;
		for($ii = 0; $ii < $n; $ii++) //This loop repleats n times
		{
			if($arrayLen - $counter >= $subArLen)//If there are more than subArLen empty spots in the return array
			{
				for($temp = $subArLen; $temp > 0; $temp--)//This repeats subArLen times
				{
					$subAr[] = $data[$counter];
					$counter++; 
				}
				$retAr[] = average($subAr);
				$subAr = array();
			}
			else //If there are fewer than subArLen spots left to be filled in the retAr
			{
				if($arrayLen-$counter > 0)
				{
					while($arrayLen-$counter > 0) //
					{
						$subAr[] = $data[$counter];
						$counter++;
					}
					$retAr[] = average($subAr);
				}
				else
				{
					$retAr[] = $data[$arrayLen - 1];
				}
				
			}
		}
	}
	return $retAr;
}

$todayStr = Date("Y-m-d");
$dateAr = getDate(strtotime("-1 week"));
$lastWeek = $dateAr['year'] . "-" . $dateAr['mon'] . "-" . $dateAr['mday'];
$dateAr = getDate(strtotime("-1 year"));
$lastYear = $dateAr['year'] . "-" . $dateAr['mon'] . "-" . $dateAr['mday'];


$calq =
"
select Calories, DayDate
from Day
inner join Nutrition
on Day.DayID = Nutrition.DayID
inner join FoodOrDrink
on Nutrition.FoodID = FoodOrDrink.FoodID
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = ". $AccountID .");
"; 

$sleepq = 
"
select Quality, Duration, DayDate
from Day
inner join sleep
on Day.DayID = sleep.DayID
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = ". $AccountID .");
";

$exerciseq = 
"
select Duration, DayDate
from Day
inner join Exercise
on Day.DayID = Exercise.DayID
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = ". $AccountID .");
";
$stepsq = 
"
select Steps, DayDate
from Day
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = ". $AccountID .");
";
$moodq = 
"
select OverallMood, DayDate
from Day
inner join Mood
on Day.DayID = Mood.DayID
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = ". $AccountID .");
";

$calr = @mysqli_query($db, $calq);
$sleepr = @mysqli_query($db, $sleepq);
$exerciser = @mysqli_query($db, $exerciseq);
$stepr = @mysqli_query($db, $stepsq);
$moodr = @mysqli_query($db, $moodq);


if((!$calr))
{
	die('Could not get calr data: ' . mysqli_error());
}
if(!$exerciser)
{
	die('Could not get exercise data: ' . mysqli_error());
}
if(!$stepr)
{
	die('Could not get step data:' . mysqli_error());
}
if(!$moodr)
{
	die('Could not get mood data:' . mysqli_error());
}

if(!$sleepr)
{
	die('Could not get sleep data: ' . mysqli_error());
}


$cal = array();
$calday = array();
$sleepq = array();
$sleepd = array();
$ex = array();
$exdate = array();
$steps = array();
$mood = array();

while($row = mysqli_fetch_array($calr))
{
	$cal[] = $row["Calories"];
	$calday[] = strtotime($row['DayDate']);
}
if(count($cal) == 0)
{
	$cal[] = 0;
	$calday[] = 0;
}

while($row = mysqli_fetch_array($sleepr))
{
	$temp = dbtophptime($row['Duration']);
	$sleepd[] = getDate($temp)['minutes']/60.0 + getDate($temp)['hours'];

	$temp = dbtophptime($row['Quality']);
	$sleepq[] = getDate($temp)['minutes']/60.0 + getDate($temp)['hours'];
}

while($row = mysqli_fetch_array($exerciser))
{
	$temp = dbtophptime($row['Duration']);
	$ex[] = getDate($temp)['minutes']/60.0 + getDate($temp)['hours'];
	$exdate[] = strtotime($row['DayDate']);
}

while($row = mysqli_fetch_array($stepr))
{
	$steps[] = $row['Steps'];
}

while($row = mysqli_fetch_array($moodr))
{
	$mood[] = $row['OverallMood'];	
}

$Cal = array();
$Calday = array();
if(count($calday)==0)
{
	$calday[] = 0;
}
if(count($cal)==0)
{
	$cal[] = 0;
}
$lastday = $calday[0];
$tempcal = $cal[0];
for($ii = 1; $ii<count($calday); $ii++)
{
	if($calday[$ii] == $lastday)
	{
		$tempcal = $tempcal + $cal[$ii];
	}
	else
	{
		$Cal[] = $tempcal;
		$Calday[] = $lastday;
		$tempcal = $cal[$ii];
		$lastday = $calday[$ii];
	}
$Cal[] = $tempcal;
$Calday[] = $lastday;
}


$exer = array();
$exerdate = array();
if(count($exdate)==0)
{
	$exdate[] = 0;
}
if(count($ex)==0)
{
	$ex[] = 0;
}
$lastday = $exdate[0];
$tempcal = $ex[0];
for($ii = 1; $ii<count($exdate); $ii++)
{
	if($exdate[$ii] == $lastday)
	{
		$tempcal = $tempcal + $ex[$ii];
	}
	else
	{
		$exer[] = $tempcal;
		$exerdate[] = $lastday;
		$tempcal = $ex[$ii];
		$lastday = $exdate[$ii];
	}
$exer[] = $tempcal;
$exerdate[] = $lastday;
}

if(!$Cal)
{
	$Cal = array(0);
}
if(!$exer)
{
	$exer = array(0);
}

if(!$sleepq)
{
	$sleepq = array(0);
}
if(!$sleepd)
{
	$sleepd = array(0);
}

if(!$steps)
{
	$steps = array(0);
}
if(!$mood)
{
	$mood = array(0);
}

$avecal = round(average($Cal),2);
$aveexercise = round(average($exer),2);
$avesleepq = round(average($sleepq),2);
$avesleepd = round(average($sleepd),2);
$avesteps = round(average($steps),2);
$avemood = round(average($mood),2);


//********************************Sleep***********************************
$weekq = "select DayDate, Quality, Duration
	from Day
	inner join sleep
	on sleep.DayID = Day.DayID
	where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = " . $AccountID . ");";

$weekResp = @mysqli_query($db, $weekq);

if(! $weekResp)
{
	die('Could not get data: ' . mysql_error());
}

$wquality = array();
$wqualitydate = array();

$wduration = array();
$wdurationdate = array();

while($wrow = mysqli_fetch_array($weekResp))
{
	$wquality[] = $wrow['Quality'];
	$wqualitydate[] = strtotime($wrow['DayDate']);

	$tempdur = dbtophptime($wrow['Duration']);
	$wduration[] = getDate($tempdur)['minutes']/60.0 + getDate($tempdur)['hours']; 
	$wdurationdate[] = strtotime($wrow['DayDate']);
}

$w1 = eliminateNullData($wquality, $wqualitydate);
$w2 = eliminateNullData($wduration, $wdurationdate);

$wquality = $w1[0];
$wqualitydate = $w1[1];

$wduration = $w2[0];
$wdurationdate = $w2[1];

array_multisort($wqualitydate,SORT_ASC, SORT_NUMERIC, $wquality);
array_multisort($wdurationdate,SORT_ASC, SORT_NUMERIC, $wduration);

$wquality = dataDiv($wquality, 7);
$wqualitydate = dataDiv($wqualitydate, 7);

$wduration = dataDiv($wduration, 7);
$wdurationdate = dataDiv($wdurationdate, 7);

$wqualdate = array();
$wdurdate = array();

for($ii = 0; $ii < 7; $ii++)
{
	$wqualdate[] = getDate($wqualitydate[$ii]);
	$wdurdate[] = getDate($wdurationdate[$ii]);
}
//**************************Mood**************************************
$weekq =
"
Select OverallMood, DayDate
from Day
inner join Mood
on Day.DayID = Mood.DayID
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = ". $AccountID .");
";

$weekResp = @mysqli_query($db, $weekq);

if(! $weekResp)
{
	die('Could not get data: ' . mysqli_error());
}

$mweek = array();
$mweekdate = array();

while($row = mysqli_fetch_array($weekResp))
{
	$mweek[] = $row['OverallMood'];
	$mweekdate[] = strtotime($row['DayDate']);
}

$w = eliminateNullData($mweek, $mweekdate);

$mweek = $w[0];
$mweekdate = $w[1];

array_multisort($mweekdate, SORT_ASC, SORT_NUMERIC, $mweek);

$moodw = array();
$mdatew = array();
$tempcal = $mweek[0];
$lastday = $mweekdate[0];
for($ii = 1; $ii<count($mweekdate); $ii++)
{
	if($mweekdate[$ii] == $lastday)
	{
		$tempcal = $tempcal + $mweek[$ii];
	}
	else
	{
		$moodw[] = $tempcal;
		$mdatew[] = $lastday;
		$tempcal = $mweek[$ii];
		$lastday = $mweekdate[$ii];
	}
}
$moodw[] = $tempcal;
$mdatew[] = $lastday;

$moodw = dataDiv($moodw, 7);
$mdatew = dataDiv($mdatew, 7);

$mweekdate = array();

for($ii = 0; $ii < 7; $ii++)
{
	$mweekdate[] = getDate($mdatew[$ii]);
}




//**************************Exercise******************************************
$weekq1 = 
"
select Duration, DayDate
from Day
inner join Exercise
on Day.DayID = Exercise.DayID
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = ". $AccountID .");
";

$week1Resp = @mysqli_query($db, $weekq1);

if(! $week1Resp)
{
	die('Could not get data: ' . mysql_error());
}

$exw = array();
$exwdate = array();

while($wrow = mysqli_fetch_array($week1Resp))
{
	$tempdur = dbtophptime($wrow['Duration']);
	$exw[] = getDate($tempdur)['minutes']/60.0 + getDate($tempdur)['hours'];
	$exwdate[] = strtotime($wrow['DayDate']);
}

$n1 = eliminateNullData($exw, $exwdate);

$exw = $n1[0];
$exwdate = $n1[1];

array_multisort($exwdate,SORT_ASC, SORT_NUMERIC, $exw);

$exerw = array();
$exerwdate = array();
$lastday = $exwdate[0];
$tempcal = $exw[0];
for($ii = 1; $ii<count($exwdate); $ii++)
{
	if($exwdate[$ii] == $lastday)
	{
		$tempcal = $tempcal + $exw[$ii];
	}
	else
	{
		$exerw[] = $tempcal;
		$exerwdate[] = $lastday;
		$tempcal = $exw[$ii];
		$lastday = $exwdate[$ii];
	}
	$exerw[] = $tempcal;
	$exerwdate[] = $lastday;
}

$exerw = dataDiv($exerw, 7);
$exerwdate = dataDiv($exerwdate, 7);

$exwdate = array();

for($ii = 0; $ii < 7; $ii++)
{
	$exwdate[] = getDate($exerwdate[$ii]);
}
//************************************************************************
?>

<html>

<head>
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>User Page</title>
    <script type="text/javascript">
                function myOtherFunction() {

location.href = "index.php";

}

function accountSettingsFunction() {

location.href = "accountsettings.php";


}

function myPageFunction() {

location.href = "Profilepage.php";
}


        function changeText(id) {

            if ($('#' + id).is(':checked')) {
                $('#' + id + "+span").html('Edit Mode');
                document.getElementById("Info").readOnly = false;
            } else {
                $('#' + id + "+span").html('Click for Edit Mode');
                document.getElementById("Info").readOnly = true;
            }
        }


        
        function addDataFunction() {
            document.getElementById("addData").onclick = function () {
                //location.href = "AddData.html";
            };
            location.href = "AddData.html";
        }


    </script>

    <style>
        body {
            background-color: #808080;
        }

        /* Style the tab */

        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */

        .tab button {
            background-color: inherit;
            float: left;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */

        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */

        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */

        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }

        .header {
            padding: 10px 16px;
            background: #555;
            color: #f1f1f1;
            z-index: 3;
        }

        .content {
            padding: 16px;
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
        }

        .sticky+.content {
            padding-top: 102px;
        }

        #Base {
            top: 100px;
            left: 10px;
            z-index: 1;
        }

        #ProfilePic {
            position: absolute;
            top: 300px;
            left: 850px;
            z-index: 2;
        }

        .sidenav {
            height: 100%;
            width: 200px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #555;
            overflow-x: hidden;
            padding-top: 20px;
            border: 3px solid white;
        }

        .sidenav a {
            padding: 6px 8px 6px 16px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
        }

        .sidenav a:hover {
            color: #f1f1f1;
        }

        .main {
            margin-left: 200px;
            /* Same as the width of the sidenav */
            font-size: 28px;
            /* Increased text to enable scrolling */
            padding: 0px 0px;
        }
        .dropdown {
		    position: absolute;

		    /** Make it fit tightly around it's children */
		    display: inline-block;
		}

		.dropdown .dropdown-menu {
		    position: absolute;

		    /**
		     * Set the top of the dropdown menu to be positioned 100%
		     * from the top of the container, and aligned to the left.
		     */
		    top: 100%;
		    left: 0;

		    /** Allow no empty space between this and .dropdown */
			display: none;
		    margin: 0;

		    /****************
		     ** NEW STYLES **
		     ****************/

		    list-style: none; /** Remove list bullets */
		    width: 100%; /** Set the width to 100% of it's parent */
		    padding: 0;
			
		}
		.dropdown:hover .dropdown-menu {

		    /** Show dropdown menu */
		    display: block;
		}
	td {
		padding: 0.5em;
		padding-right: 1em;
	}
    </style>

    <script>
//*****************************sleep********************************************
window.onload = function () {
CanvasJS.addColorSet("uglyColors",[
	"#003399"
	]);

var wquality= new CanvasJS.Chart("chartContainer", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Sleep Quality"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Sleep Quality"
	}],
	data: [{
		type: "stepLine",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $wqualdate[0]["year"] .  ',' . $wqualdate[0]["mon"] . ',' . $wqualdate[0]["mday"] . '), y: ' . $wquality[0] . '},
			{x: new Date(' . $wqualdate[1]["year"] .  ',' . $wqualdate[1]["mon"] . ',' . $wqualdate[1]["mday"] . '), y: ' . $wquality[1] . '},
			{x: new Date(' . $wqualdate[2]["year"] .  ',' . $wqualdate[2]["mon"] . ',' . $wqualdate[2]["mday"] . '), y: ' . $wquality[2] . '},
			{x: new Date(' . $wqualdate[3]["year"] .  ',' . $wqualdate[3]["mon"] . ',' . $wqualdate[3]["mday"] . '), y: ' . $wquality[3] . '},
			{x: new Date(' . $wqualdate[4]["year"] .  ',' . $wqualdate[4]["mon"] . ',' . $wqualdate[4]["mday"] . '), y: ' . $wquality[4] . '},
			{x: new Date(' . $wqualdate[5]["year"] .  ',' . $wqualdate[5]["mon"] . ',' . $wqualdate[5]["mday"] . '), y: ' . $wquality[5] . '},
			{x: new Date(' . $wqualdate[6]["year"] .  ',' . $wqualdate[6]["mon"] . ',' . $wqualdate[6]["mday"] . '), y: ' . $wquality[6] . '}'
			?>
		]
	}]
});
var wduration= new CanvasJS.Chart("wduration", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Sleep Duration"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Duration (hours)"
	}],
	data: [{
		type: "stepLine",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $wdurdate[0]["year"] .  ',' . $wdurdate[0]["mon"] . ',' . $wdurdate[0]["mday"] . '), y: ' . $wduration[0] . '},
			{x: new Date(' . $wdurdate[1]["year"] .  ',' . $wdurdate[1]["mon"] . ',' . $wdurdate[1]["mday"] . '), y: ' . $wduration[1] . '},
			{x: new Date(' . $wdurdate[2]["year"] .  ',' . $wdurdate[2]["mon"] . ',' . $wdurdate[2]["mday"] . '), y: ' . $wduration[2] . '},
			{x: new Date(' . $wdurdate[3]["year"] .  ',' . $wdurdate[3]["mon"] . ',' . $wdurdate[3]["mday"] . '), y: ' . $wduration[3] . '},
			{x: new Date(' . $wdurdate[4]["year"] .  ',' . $wdurdate[4]["mon"] . ',' . $wdurdate[4]["mday"] . '), y: ' . $wduration[4] . '},
			{x: new Date(' . $wdurdate[5]["year"] .  ',' . $wdurdate[5]["mon"] . ',' . $wdurdate[5]["mday"] . '), y: ' . $wduration[5] . '},
			{x: new Date(' . $wdurdate[6]["year"] .  ',' . $wdurdate[6]["mon"] . ',' . $wdurdate[6]["mday"] . '), y: ' . $wduration[6] . '}'
			?>
		]
	}]
});

var mweek= new CanvasJS.Chart("mweek", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Your Mood This Week"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Mood"
	}],
	data: [{
		type: "stepLine",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $mweekdate[0]["year"] .  ',' . $mweekdate[0]["mon"] . ',' . $mweekdate[0]["mday"] . '), y: ' . $moodw[0] . '},
			{x: new Date(' . $mweekdate[1]["year"] .  ',' . $mweekdate[1]["mon"] . ',' . $mweekdate[1]["mday"] . '), y: ' . $moodw[1] . '},
			{x: new Date(' . $mweekdate[2]["year"] .  ',' . $mweekdate[2]["mon"] . ',' . $mweekdate[2]["mday"] . '), y: ' . $moodw[2] . '},
			{x: new Date(' . $mweekdate[3]["year"] .  ',' . $mweekdate[3]["mon"] . ',' . $mweekdate[3]["mday"] . '), y: ' . $moodw[3] . '},
			{x: new Date(' . $mweekdate[4]["year"] .  ',' . $mweekdate[4]["mon"] . ',' . $mweekdate[4]["mday"] . '), y: ' . $moodw[4] . '},
			{x: new Date(' . $mweekdate[5]["year"] .  ',' . $mweekdate[5]["mon"] . ',' . $mweekdate[5]["mday"] . '), y: ' . $moodw[5] . '},
			{x: new Date(' . $mweekdate[6]["year"] .  ',' . $mweekdate[6]["mon"] . ',' . $mweekdate[6]["mday"] . '), y: ' . $moodw[6] . '}			
			'
			?>
		]
	}]
});

var weekEx= new CanvasJS.Chart("weekEx", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Exercise Time This Week"
	},
	axisX: [{
		valueFormatString: "DD MMM"
	},
	{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Exercise Time (hours)"
	}],
	data: [{
		type: "stepLine",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $exwdate[0]["year"] .  ',' . $exwdate[0]["mon"] . ',' . $exwdate[0]["mday"] . '), y: ' . $exerw[0] . '},
			{x: new Date(' . $exwdate[1]["year"] .  ',' . $exwdate[1]["mon"] . ',' . $exwdate[1]["mday"] . '), y: ' . $exerw[1] . '},
			{x: new Date(' . $exwdate[2]["year"] .  ',' . $exwdate[2]["mon"] . ',' . $exwdate[2]["mday"] . '), y: ' . $exerw[2] . '},
			{x: new Date(' . $exwdate[3]["year"] .  ',' . $exwdate[3]["mon"] . ',' . $exwdate[3]["mday"] . '), y: ' . $exerw[3] . '},
			{x: new Date(' . $exwdate[4]["year"] .  ',' . $exwdate[4]["mon"] . ',' . $exwdate[4]["mday"] . '), y: ' . $exerw[4] . '},
			{x: new Date(' . $exwdate[5]["year"] .  ',' . $exwdate[5]["mon"] . ',' . $exwdate[5]["mday"] . '), y: ' . $exerw[5] . '},
			{x: new Date(' . $exwdate[6]["year"] .  ',' . $exwdate[6]["mon"] . ',' . $exwdate[6]["mday"] . '), y: ' . $exerw[6] . '}
			'
			?>
		]
	}]
});


weekEx.render();
mweek.render();
wquality.render();
wduration.render();
}
    </script>
</head>

<body>
    <div class="sidenav">
        <p style="color: white; font-size: 18px; text-align: center;"><?php echo("Name: "."{$_SESSION['UserName']}");?></p>
        <img style="width: 100%;" src="Untitledz.png" />
    </div>
    <div class="main">
        <div class="header" id="myHeader">

            <h1><?php echo("Hello "."{$_SESSION['UserName']}".", Welcome Back!");?></h1>
        </div>
        <div class="tab">
            <button id="myPage" class="tablinks" onclick="myPageFunction()">My Page</button>
            <button id="accountSettings" onclick="accountSettingsFunction()">Account Settings</button>
            <div class="dropdown">

			    <!-- trigger button -->
			    <button style = "font-family:verdana; font-size:17">Add Data</button>

			    <!-- dropdown menu -->
			    <ul class="dropdown-menu">
			<li><a href="addalldata.php">Add All Data</a></li>
                	<li><a href="addsleepdata.php">Sleep Data</a></li>
                        <li><a href="Nutrition.php">Nutrition Data</a></li>
                        <li><a href="Exerisce.php">Exercise Data</a></li>
                        <li><a href="Emotional.php">Emotional Data</a></li>
                        <li><a href="Medical.php">Medical Data</a></li>


			    </ul>

			</div>
            <button class="tablinks" onclick="location.href='ReportExercise.php'" style ="padding-left:125px">Exercise</button>
	    <button id="MedicalReport" onclick="location.href='ReportMedical.php'">Medical</button>
	    <button id="MoodReport" onclick="location.href='ReportMood.php'">Mood</button>
	    <button id="NutritionReport" onclick="location.href='ReportNutrition.php'">Nutrition</button>
	    <button id="SleepReport" onclick="location.href='ReportSleep.php'">Sleep</button>
            <button id="logoutButton" onclick="myOtherFunction()">Log Out</button>
        </div>
        <div style="    text-align: center;">
            
        </div>

        
    </div>
<div style="background-color:white;margin-top:100px;margin-bottom:80px;margin-left:25%;margin-right:10%;"><br><br>
<?php
echo '<h2 align="center">Your Week at a Glance</h2><br>';
echo '<table align="center" cellspacing="20" cellpadding="20">

<tr><td align="left"><b>Avg. Calories</b></td><td align="center"><b>'.$avecal.'</b></td>
<tr><td align="left"><b>Avg. Hours Exercised</b></td><td align="center"><b>'. $aveexercise .'</b></td>
<tr><td align="left"><b>Avg. Sleep Quality</b></td><td align="center"><b>'. $avesleepq .'</b></td>
<tr><td align="left"><b>Avg. Sleep Duration</b></td><td align="center"><b>'. $avesleepd .'</b></td>
<tr><td align="left"><b>Avg. Steps</b></td><td align="center"><b>'. $avesteps .'</b></td>
<tr><td align="left"><b>Avg. Mood</b></td><td align="center"><b>'. $avemood .'</b></td></table>';
mysqli_close($db);


?>
<br>
	<div style="text-align: center;"></p>If you are unsure of how to read these graphs please refer to the individual reports titled<br> "Exercise","Medical", "Mood", "Nutrition", and "Sleep" for a detailed explanation.</div><br><br>
<div class="center" id="chartContainer" style="height: 200px; width: 95%;"></div>
<div class="center" id="weekEx" style="height: 200px; width: 95%;"></div>
<div class="center" id="mweek" style="height: 200px; width: 95%;"></div>
<div class="center" id="wduration" style="height: 200px; width: 95%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<br><br></div>
</body>


</html>
