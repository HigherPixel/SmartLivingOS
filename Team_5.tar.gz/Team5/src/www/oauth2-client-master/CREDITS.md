# OAuth 2.0 Client

## Authors

Also see <https://github.com/thephpleague/oauth2-client/contributors>.

### Current Maintainer

- [Ben Ramsey](https://github.com/ramsey)

### Contributors

- [Alex Bilbie](https://github.com/alexbilbie)
- [Ben Corlett](https://github.com/bencorlett)
- [Ben Ramsey](https://github.com/ramsey)
- [James Mills](https://github.com/jamesmills)
- [Phil Sturgeon](https://github.com/philsturgeon)
- [Rudi Theunissen](https://github.com/rtheunissen)
- [Tom Anderson](https://github.com/TomHAnderson)
- [Woody Gilk](https://github.com/shadowhand)
