<?php
ob_start();
session_start();
require_once('config.php');
$AccountID = $_SESSION['AccountNum'];

function eliminateNullData($xData, $yData)
{
	$retArX = array();
	$retArY = array();
	$n = count($xData);
	$check = count($yData);
	if($n == 0 or $check == 0)
	{
		$retArX[] = 0;
		$retArY[] = 0;
	}
	if($n != $check)
	{
		return -1;
	}
	$ii = 0;
	while($ii < $n)
	{
		$currX = $xData[$ii];
		$currY = $yData[$ii];
		if($currX != null)
		{
			$retArX[] = $currX;
			$retArY[] = $currY;  
		}
		$ii = $ii + 1;
	}
	$retAr = array($retArX, $retArY);
	return $retAr;
}

function average($array)
{
	$ii = 0;
	$sum = array_sum($array);
	$n = count($array);
	if($n == 0)
	{
		return 0;
	}
	else
	{
		return $sum/$n;
	}
}

function dataDiv($data, $n)
{
	$arrayLen = count($data);
	$subArLen = $arrayLen/$n;
	$retAr = array();
	$subAr = array();
	if($n > $arrayLen)
	{
		$lastDat = 0;
		$extra = $n - $arrayLen;
		foreach($data as $dat)
		{
			$retAr[] = $dat;
			$lastDat = $dat;
		}
		while($extra > 0)
		{
			$retAr[] = $lastDat;
			$extra--;
		}
	}
	else
	{
		$counter = 0;
		for($ii = 0; $ii < $n; $ii++) //This loop repleats n times
		{
			if($arrayLen - $counter >= $subArLen)//If there are more than subArLen empty spots in the return array
			{
				for($temp = $subArLen; $temp > 0; $temp--)//This repeats subArLen times
				{
					$subAr[] = $data[$counter];
					$counter++; 
				}
				$retAr[] = average($subAr);
				$subAr = array();
			}
			else //If there are fewer than subArLen spots left to be filled in the retAr
			{
				if($arrayLen-$counter > 0)
				{
					while($arrayLen-$counter > 0) //
					{
						$subAr[] = $data[$counter];
						$counter++;
					}
					$retAr[] = average($subAr);
				}
				else
				{
					$retAr[] = $data[$arrayLen - 1];
				}
				
			}
		}
	}
	return $retAr;
}

$todayStr = Date("Y-m-d");
$dateAr = getDate(strtotime("-1 week"));
$lastWeek = $dateAr['year'] . "-" . $dateAr['mon'] . "-" . $dateAr['mday'];
$dateAr = getDate(strtotime("-1 year"));
$lastYear = $dateAr['year'] . "-" . $dateAr['mon'] . "-" . $dateAr['mday'];

$weekq =
"
Select OverallMood, DayDate
from Day
inner join Mood
on Day.DayID = Mood.DayID
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastWeek . "') and (AccountNum = ". $AccountID .");
";

$yearq = 
"
select OverallMood, DayDate
from Day
inner join Mood
on Day.DayID = Mood.DayID
where (DayDate <='" . $todayStr . "') and (DayDate >='" . $lastYear . "') and (AccountNum = ". $AccountID .");
";

$weekResp = @mysqli_query($db, $weekq);

$yearResp = @mysqli_query($db, $yearq);

if(! $weekResp)
{
	die('Could not get data: ' . mysqli_error());
}
if(! $yearResp)
{
	die('Could not get data: ' . mysqli_error());
}

$mweek = array();
$mweekdate = array();
$myear = array();
$myeardate = array();

while($row = mysqli_fetch_array($weekResp))
{
	$mweek[] = $row['OverallMood'];
	$mweekdate[] = strtotime($row['DayDate']);
}

while($row = mysqli_fetch_array($yearResp))
{
	$myear[] = $row['OverallMood'];
	$myeardate[] = strtotime($row['DayDate']);
}

$w = eliminateNullData($mweek, $mweekdate);
$y = eliminateNullData($myear, $myeardate);

$mweek = $w[0];
$mweekdate = $w[1];
$myear = $y[0];
$myeardate = $y[1];

array_multisort($mweekdate, SORT_ASC, SORT_NUMERIC, $mweek);
array_multisort($myeardate, SORT_ASC, SORT_NUMERIC, $myear);

$moodw = array();
$mdatew = array();
$tempcal = $mweek[0];
$lastday = $mweekdate[0];
for($ii = 1; $ii<count($mweekdate); $ii++)
{
	if($mweekdate[$ii] == $lastday)
	{
		$tempcal = $tempcal + $mweek[$ii];
	}
	else
	{
		$moodw[] = $tempcal;
		$mdatew[] = $lastday;
		$tempcal = $mweek[$ii];
		$lastday = $mweekdate[$ii];
	}
}
$moodw[] = $tempcal;
$mdatew[] = $lastday;


$moody = array();
$mdatey = array();
$tempcal = $myear[0];
$lastday = $myeardate[0];
for($ii = 1; $ii<count($myeardate); $ii++)
{
	if($myeardate[$ii] == $lastday)
	{
		$tempcal = $tempcal + $myear[$ii];
	}
	else
	{
		$moody[] = $tempcal;
		$mdatey[] = $lastday;
		$tempcal = $myear[$ii];
		$lastday = $myeardate[$ii];
	}
}
$moody[] = $tempcal;
$mdatey[] = $lastday;

$moodw = dataDiv($moodw, 7);
$mdatew = dataDiv($mdatew, 7);
$moody = dataDiv($moody, 12);
$mdatey = dataDiv($mdatey, 12);

$mweekdate = array();
$myeardate = array();
for($ii = 0; $ii < 7; $ii++)
{
	$mweekdate[] = getDate($mdatew[$ii]);
}

for($ii = 0; $ii < 12; $ii++)
{
	$myeardate[] = getDate($mdatey[$ii]);
}

mysqli_close($db);
?>
<!DOCTYPE HTML>
<html>
<head>
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>User Page</title>
    <script type="text/javascript">
                function myOtherFunction() {

location.href = "index.php";

}

function accountSettingsFunction() {

location.href = "accountsettings.php";


}

function myPageFunction() {

location.href = "Profilepage.php";
}


        function changeText(id) {

            if ($('#' + id).is(':checked')) {
                $('#' + id + "+span").html('Edit Mode');
                document.getElementById("Info").readOnly = false;
            } else {
                $('#' + id + "+span").html('Click for Edit Mode');
                document.getElementById("Info").readOnly = true;
            }
        }


        
        function addDataFunction() {
            document.getElementById("addData").onclick = function () {
                //location.href = "AddData.html";
            };
            location.href = "AddData.html";
        }
    </script>

<style>
.center
{
	margin: auto;
	width: 20%;
	padding: 20px;
}
        body {
            background-color: #808080;
        }

        /* Style the tab */

        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */

        .tab button {
            background-color: inherit;
            float: left;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */

        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */

        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */

        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }

        .header {
            padding: 10px 16px;
            background: #555;
            color: #f1f1f1;
            z-index: 3;
        }

        .content {
            padding: 16px;
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
        }

        .sticky+.content {
            padding-top: 102px;
        }

        #Base {
            top: 100px;
            left: 10px;
            z-index: 1;
        }

        #ProfilePic {
            position: absolute;
            top: 300px;
            left: 850px;
            z-index: 2;
        }

        .dropdown {
		    position: absolute;

		    /** Make it fit tightly around it's children */
		    display: inline-block;
		}

		.dropdown .dropdown-menu {
		    position: absolute;

		    /**
		     * Set the top of the dropdown menu to be positioned 100%
		     * from the top of the container, and aligned to the left.
		     */
		    top: 100%;
		    left: 0;

		    /** Allow no empty space between this and .dropdown */
			display: none;
		    margin: 0;

		    /****************
		     ** NEW STYLES **
		     ****************/

		    list-style: none; /** Remove list bullets */
		    width: 100%; /** Set the width to 100% of it's parent */
		    padding: 0;
			
		}
		.dropdown:hover .dropdown-menu {

		    /** Show dropdown menu */
		    display: block;
		}

</style>
<script>
window.onload = function () {
CanvasJS.addColorSet("uglyColors",[
	"#C0392B"
	]);

var mweek= new CanvasJS.Chart("mweek", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Your Mood This Week"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Mood"
	}],
	data: [{
		type: "stepLine",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $mweekdate[0]["year"] .  ',' . $mweekdate[0]["mon"] . ',' . $mweekdate[0]["mday"] . '), y: ' . $moodw[0] . '},
			{x: new Date(' . $mweekdate[1]["year"] .  ',' . $mweekdate[1]["mon"] . ',' . $mweekdate[1]["mday"] . '), y: ' . $moodw[1] . '},
			{x: new Date(' . $mweekdate[2]["year"] .  ',' . $mweekdate[2]["mon"] . ',' . $mweekdate[2]["mday"] . '), y: ' . $moodw[2] . '},
			{x: new Date(' . $mweekdate[3]["year"] .  ',' . $mweekdate[3]["mon"] . ',' . $mweekdate[3]["mday"] . '), y: ' . $moodw[3] . '},
			{x: new Date(' . $mweekdate[4]["year"] .  ',' . $mweekdate[4]["mon"] . ',' . $mweekdate[4]["mday"] . '), y: ' . $moodw[4] . '},
			{x: new Date(' . $mweekdate[5]["year"] .  ',' . $mweekdate[5]["mon"] . ',' . $mweekdate[5]["mday"] . '), y: ' . $moodw[5] . '},
			{x: new Date(' . $mweekdate[6]["year"] .  ',' . $mweekdate[6]["mon"] . ',' . $mweekdate[6]["mday"] . '), y: ' . $moodw[6] . '}			
			'
			?>
		]
	}]
});

var myear= new CanvasJS.Chart("myear", {
	colorSet: "uglyColors",
	animationEnabled: true,
	title:{
		text: "Your Mood This Year"
	},
	axisX: [{
		valueFormatString: "DD MMM"
		},
		{
		title: "Date"
	}],
	axisY:[{
		includeZero: false
		},
		{
		title: "Mood"
	}],
	data: [{
		type: "spline",
		connectNullData: true,
		dataPoints: [
			<?php
			echo '
			{x: new Date(' . $myeardate[0]["year"] .  ',' . $myeardate[0]["mon"] . ',' . $myeardate[0]["mday"] . '), y: ' . $moody[0] . '},
			{x: new Date(' . $myeardate[1]["year"] .  ',' . $myeardate[1]["mon"] . ',' . $myeardate[1]["mday"] . '), y: ' . $moody[1] . '},
			{x: new Date(' . $myeardate[2]["year"] .  ',' . $myeardate[2]["mon"] . ',' . $myeardate[2]["mday"] . '), y: ' . $moody[2] . '},
			{x: new Date(' . $myeardate[3]["year"] .  ',' . $myeardate[3]["mon"] . ',' . $myeardate[3]["mday"] . '), y: ' . $moody[3] . '},
			{x: new Date(' . $myeardate[4]["year"] .  ',' . $myeardate[4]["mon"] . ',' . $myeardate[4]["mday"] . '), y: ' . $moody[4] . '},
			{x: new Date(' . $myeardate[5]["year"] .  ',' . $myeardate[5]["mon"] . ',' . $myeardate[5]["mday"] . '), y: ' . $moody[5] . '},
			{x: new Date(' . $myeardate[6]["year"] .  ',' . $myeardate[6]["mon"] . ',' . $myeardate[6]["mday"] . '), y: ' . $moody[6] . '},
			{x: new Date(' . $myeardate[7]["year"] .  ',' . $myeardate[7]["mon"] . ',' . $myeardate[7]["mday"] . '), y: ' . $moody[7] . '},
			{x: new Date(' . $myeardate[8]["year"] .  ',' . $myeardate[8]["mon"] . ',' . $myeardate[8]["mday"] . '), y: ' . $moody[8] . '},
			{x: new Date(' . $myeardate[9]["year"] .  ',' . $myeardate[9]["mon"] . ',' . $myeardate[9]["mday"] . '), y: ' . $moody[9] . '},
			{x: new Date(' . $myeardate[10]["year"] .  ',' . $myeardate[10]["mon"] . ',' . $myeardate[10]["mday"] . '), y: ' . $moody[10] . '},
			{x: new Date(' . $myeardate[11]["year"] .  ',' . $myeardate[11]["mon"] . ',' . $myeardate[11]["mday"] . '), y: ' . $moody[11] . '},
			'
			?>
		]
	}]
});
mweek.render();
myear.render();
}

</script>
</head>
<body>

    <div class="main">
        <div class="header" id="myHeader">

            <h1><?php echo("{$_SESSION['UserName']}");?></h1>
        </div>
        <div class="tab">
            <button id="myPage" class="tablinks" onclick="myPageFunction()">My Page</button>
            <button id="accountSettings" onclick="accountSettingsFunction()">Account Settings</button>
            <div class="dropdown">

			    <!-- trigger button -->
			    <button style = "font-family:verdana; font-size:17">Add Data</button>

			    <!-- dropdown menu -->
			    <ul class="dropdown-menu">
			<li><a href="addalldata.php">Add All Data</a></li>
                	<li><a href="addsleepdata.php">Sleep Data</a></li>
                        <li><a href="Nutrition.php">Nutrition Data</a></li>
                        <li><a href="Exerisce.php">Exercise Data</a></li>
                        <li><a href="Emotional.php">Emotional Data</a></li>
                        <li><a href="Medical.php">Medical Data</a></li>


			    </ul>

			</div>
            <button class="tablinks" onclick="location.href='ReportExercise.php'" style ="padding-left:125px">Exercise</button>
	    <button id="MedicalReport" onclick="location.href='ReportMedical.php'">Medical</button>
	    <button id="MoodReport" onclick="location.href='ReportMood.php'">Mood</button>
	    <button id="NutritionReport" onclick="location.href='ReportNutrition.php'">Nutrition</button>
	    <button id="SleepReport" onclick="location.href='ReportSleep.php'">Sleep</button>
            <button id="logoutButton" onclick="myOtherFunction()">Log Out</button>
        </div>
        <div style="    text-align: center;">
            
        </div>

        
    </div>

<div style="background-color:white;margin-top:100px;margin-bottom:80px;margin-left:10%;margin-right:10%;"><br>
<h2 class="center">Your Mood This Week</h2>
<div style="text-align: center; font-size:20px">To see number results please put your cursor on the dots on the chart.</div>
<div style="text-align: center; font-size:20px">To determine how healthy your mood has been according to the mood this week graph: <br> 10-13 means that we believe you are a very happy person, 5-9.9 means that we believe you are a happy person,<br> 5-6 means that we believe you are average but should try to improve your happiness, and <br>3-4.9 means we believe you may be depressed or at risk of falling into depression.<br> Anything below a 3 we believe means you are depressed and possibly severly so. We recomend seeking professional help.</div>
<div class="center" id="mweek" style="height: 300px; width: 60%;"></div><br>
<br><br></div>
<div style="background-color:white;margin-top:100px;margin-bottom:60px;margin-left:10%;margin-right:10%;"><br>
<h2 class="center">Your Mood This Year</h2><br>
<div class="center" id="myear" style="height: 300px; width: 60%;"></div><br><br><br>
</div>
<br><br><br><br><br>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>


