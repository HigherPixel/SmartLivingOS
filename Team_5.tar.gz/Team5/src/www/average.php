<?php
function average($array)
{
	$ii = 0;
	$sum = 0.0;
	$n = count($array);
	while($ii < $n)
	{
		$sum = $array[$ii] + $sum;
		$ii = $ii + 1;
	}
	return $sum/$n;
}

$ar = array(2,3,4,53,2,53,23,53,2,45,2);
echo average($ar);
?>
