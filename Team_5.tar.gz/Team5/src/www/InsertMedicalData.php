<?php  
ob_start();
session_start();
 include "Medical.php";
 require_once('config.php');
 $AllergyType = count($_POST["AllergyType"]);  
 $AllergyStatus = count($_POST["AllergyStatus"]);
 $AllergyDate = count($_POST["AllergyDate"]);
 $AccountNum = $SESSION['AccountNum'];
 echo $AccountNum;
mysqli_close($db);
  ?> 
