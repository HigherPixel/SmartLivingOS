<?php
   session_start();

   require_once('FitbitClient.class.php');
   
   
   $fclient = new FitbitClient();
   $fclient->setParameters($_SESSION['parameters']);
   print_r($fclient->getUserProfile());
   echo '<br />';
   print_r($fclient->getHeartRateIntraday());
?>