<?php
$user = 'traxsmar_root';
$pass = 'xboxps4cokealexaplate';
$db = 'traxsmar_Healthdb';

$db = new mysqli('localhost', $user, $pass, $db);

if ($db->connect_error)
{
	die("Failed to connect to MySQL" . $db->connect_error);
}

?>
