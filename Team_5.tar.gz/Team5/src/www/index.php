
<!DOCTYPE html>

<html>


<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
<style>
        #myButton {

            width: 100px;

        }

        #loginButton {

            width: 100px;

        }

        body {
            background-color: #808080;
        }
    </style>
</style>
<body>
<h1 style="text-align: center; font-size: 70px;">Smart Living OS</h1>

<div style="    text-align: center;">
    <img id="Base" style="vertical-align: middle;" src="Untitled.png" />

<form class="form-signin" action="index.php" method="POST">      
<div style="text-align: center; padding-bottom: 50px; padding-top: 50px; width: 50%; margin: auto;">
            <h2 style="text-align: center; font-size: 45px;"  class="form-signin-heading">Login or Create an Account Today!</h2>
            <div class="form-group">
            <input type="text" class="form-control" name="userName" placeholder="username" required="" autofocus="" name="userName" />
            </div>
            <br>
            <div class="form-group">
            <input type="password" class="form-control" name="password" placeholder="Password" required="" name="password"/>      
            </div>
            <label class="checkbox">
              <input type="checkbox" value="remember-me" id="rememberMe" name="rememberMe"> Remember me
            </label>
            <div style="text-align: center;">
                <input type="submit" value="Login Account" name="login"/>
                <input type="button" value="Create Account" onclick="redir();" />
            </div>

           
    </div>
</form>
<script type="text/javascript">
  function redir() {
    window.location = "CA.php";
  }
</script>

<?php
ob_start();
session_start();
require_once('config.php');
if(isset($_POST['login']))
{
    @$username = $_POST['userName'];
    @$password = $_POST['password'];

    $query = "select * from User where UserName='$username'";
    $query_run = mysqli_query($db,$query);
    if($query_run)
    {
    	if(mysqli_num_rows($query_run)>0) //dont log in if user has an account
    	{
        	$row = mysqli_fetch_array($query_run,MYSQLI_ASSOC);
		//Samuel. Changed it so that we check the password here
		$realPassword = $row['Password'];
		if(password_verify($password, $realPassword))
		{
        		$_SESSION['UserName'] = $username;
        		$_SESSION['Password'] = $password;
        		$sql = "SELECT AccountNum FROM user";
        		$_SESSION['AccountNum'] = $row["AccountNum"];
			$AccountNum = $_SESSION['AccountNum'];
			$sql2 = "SELECT max(DayID) FROM Day WHERE AccountNum = '$AccountNum';";
			//simle select statement with max function
			$result_set2 = mysqli_query($db,$sql2);
			
			$createNewDay = false;
			if(!$result_set2)//If no date results, create a new day
			{
				$createNewDay = true;
			}
			else //query for the DayDate of the max(Day)
			{
				$rowB = mysqli_fetch_array($result_set2,MYSQLI_ASSOC);
				$dayID = $rowB['max(DayID)'];
				$dateQuery = mysqli_query($db,"select DayDate from Day where DayID='$dayID';");
				if(!$dateQuery)
				{
					die("could not get date");
				}
				$rowC = mysqli_fetch_array($dateQuery,MYSQLI_ASSOC);
				$dayDate = $rowC["DayDate"];
				$todayStr = Date("Y-m-d");
				echo $dayDate . " " . $todayStr;
				//If the max(Day).DayDate is smaller than the current date, create a new day
				if(!(0 == strcmp($dayDate,$todayStr)))
				{
					$createNewDay = true;
				}
				//If the max(Day).DayDate is the same as the current date, use the old day
				else
				{
					$createNewDay = false;
				}
			}
			if($createNewDay)
			{
				$today = Date("Y-m-d");
				$account = $_SESSION['AccountNum'];
				$result = mysqli_query($db, "insert into Day (DayID, AccountNum, DayDate) values (null, '$account', '$today')");
				$DayIDResult = mysqli_query($db, "select DayID from Day where DayDate='$today'");
				if(!$DayIDResult)
				{
					die("Falure");
				}
				$rowD = mysqli_fetch_array($DayIDResult, MYSQLI_ASSOC);
				$_SESSION['DayID'] = $rowD['DayID'];
			}
			else
			{
				$_SESSION['DayID'] = $dayID;
			}
      			header( "Location: Profilepage.php");
		}
		else
		{
			echo "<script type='text/javascript'>alert('Incorrect username or password. Try again.');</script>";
		}
        }
    }
}
mysqli_close($db);
?>



</body>
</html>
