<?php
 // create curl resource 
        $ch = curl_init(); 

        // set url 
        curl_setopt($ch, CURLOPT_URL, "https://api.nutritionix.com/v1_1/search/cookie?resulsts=0:20&fields=item_name,brand_name,item_id,nf_calories,nf_protein,nf_sugars,nf_saturated_fat&appId=f213fbb8&appKey=ca5ef3fde86d5f0e53f1737ee0d36746"); 

        //return the transfer as a string 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 

        // $output contains the output string 
        $output = curl_exec($ch); 
	echo($output);

        // close curl resource to free up system resources 
        curl_close($ch);      
?>