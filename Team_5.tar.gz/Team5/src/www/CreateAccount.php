<?php
ob_start();
session_start();
include "CA.php";
require_once('config.php');

$fName =$_POST['firstname'];
$lName = $_POST['lastname'];
$userName =$_POST['userName'];
$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
$birthday = $_POST['DOB'];
$address = $_POST['address-line'];
$city = $_POST['city'];
$region= $_POST['region'];
$zip= $_POST['zip'];
$sex= $_POST['Sex'];
$country = $_POST['country'];

$usernameq = "select UserName from User where UserName='$userName';";
$result = mysqli_query($db,$usernameq);
if(!$result)
{
	die("Unable to fetch data");
}
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
if(0 == strcmp($row['UserName'],$userName))
{
	echo "<script type='text/javascript'>alert('That username is allready taken. Please, try another.');</script>";
}
else
{
//Take the $userName and run a query to see if it is the same as another username
//if it is, go back to the create account page and write "Sorry, that username is taken."

$result = mysqli_query($db,"INSERT INTO User(FirstName,LastName,UserName,Password,DOB,AccountNum,CityAddr,StreetAddr,StateAddr,ZipAddr,Sex,NationalAddr) values ('$fName','$lName','$userName','$password','$birthday ',NULL,'$city','$address','$region','$zip','$sex','$country')");

if($result)
{
    $query = "SELECT AccountNum FROM User WHERE UserName='$userName'";
    $query_run = mysqli_query($db,$query);
    if($query_run)
    {
        if(mysqli_num_rows($query_run)>0)
        {
            $row = mysqli_fetch_array($query_run,MYSQLI_ASSOC);
                    
            $sql = "SELECT AccountNum FROM user";
            $_SESSION['AccountNum'] = $row["AccountNum"];
	    $Account = $_SESSION['AccountNum'];
	    $day = date("Y-m-d");
            $resulrt = mysqli_query($db,"INSERT INTO Day (DayID,AccountNum,DayDate) values (NULL,'$Account','$day')");
            if($resulrt)
            {
                header( "Location: index.php");

            }
            else
            {
                echo("Error description: " . mysqli_error($db));

            }
        }
    }
}
else
{
    echo("Error description: " . mysqli_error($db));
}

/*if(isset($_POST['createAccount']))
{
    
}*/
}
mysqli_close($db);
?>
