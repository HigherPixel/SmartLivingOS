<?php
function dbtophptime($dbtime)
{
	$newTime = substr_replace($dbtime,':',2,0);
	$date = '2000-00-00';
	$sec = ':00';
	$TimeString = $date . $newTime . $sec;
	return strtotime($TimeString);
}

$timeArray = dbtophptime('0013');
$timeArray = getDate($timeArray);
echo($timeArray['hours'] . ":" . $timeArray['minutes']);
?>
