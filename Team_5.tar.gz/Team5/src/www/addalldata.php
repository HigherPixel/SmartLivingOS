<?php
ob_start();
session_start();
?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<title>Add Data</title>
<style>
    * {
        box-sizing: border-box;
    }
    body {
        background-color: #808080;
    }
    #regForm {
        background-color: #ffffff;
        margin: 100px auto;
        font-family: Raleway;
        padding: 40px;
        width: 70%;
        min-width: 300px;
    }
    h1 {
        text-align: center;
    }
    input {
        padding: 10px;
        width: 100%;
        font-size: 17px;
        font-family: Raleway;
        border: 1px solid #aaaaaa;
    }
    /* Mark input boxes that gets an error on validation: */
    input.invalid {
        background-color: #ffdddd;
    }
    /* Hide all steps by default: */
    .tab {
        display: none;
    }
    button {
        background-color: #4CAF50;
        color: #ffffff;
        border: none;
        padding: 10px 20px;
        font-size: 17px;
        font-family: Raleway;
        cursor: pointer;
    }
    button:hover {
        opacity: 0.8;
    }
    #prevBtn {
        background-color: #bbbbbb;
    }
    /* Make circles that indicate the steps of the form: */
    .step {
        height: 15px;
        width: 15px;
        margin: 0 2px;
        background-color: #bbbbbb;
        border: none;
        border-radius: 50%;
        display: inline-block;
        opacity: 0.5;
    }
    .step.active {
        opacity: 1;
    }
    .slidecontainer {
        width: 100%;
    }
    .slider {
        -webkit-appearance: none;
        width: 100%;
        height: 25px;
        background: #d3d3d3;
        outline: none;
        opacity: 0.7;
        -webkit-transition: .2s;
        transition: opacity .2s;
    }
    .slider:hover {
        opacity: 1;
    }
    .slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 25px;
        height: 25px;
        background: #4CAF50;
        cursor: pointer;
    }
    .slider::-moz-range-thumb {
        width: 25px;
        height: 25px;
        background: #4CAF50;
        cursor: pointer;
    }
    /* Mark the steps that are finished and valid: */
    .step.finish {
        background-color: #4CAF50;
    }
</style>

<body>

    <form id="regForm" action="InsertAllData.php" method="post">
        <h1>Add Data</h1>
        <!-- One "tab" for each step in the form: -->
        <div class="tab">
            <h2>Your Sleep Information</h2>
<script>function updateTextInput(val) {
          document.getElementById('textInput').value=val; 
        }
function updateTextInput1(val) {
          document.getElementById('textInput1').value=val; 
        }
function updateTextInput2(val) {
          document.getElementById('textInput2').value=val; 
        }</script>
           
                <label for="HR">How many hours did you sleep?(Max of 12 hours)</label>
<input type="range" name="Duration" step="0.5" min="0" max="12"onchange="updateTextInput(this.value);" />
<input type="text" id="textInput" value="" readonly>
                <label for="HR">On a scale from 0 to 10, how well did you sleep last night?</label>
<input type="range" name="Quality" placeholder="" step="1" min="0" max="10" onchange="updateTextInput1(this.value);" />
<input type="text" id="textInput1" value="" readonly>       

                <label for="HR">How much time did you stay in bed without sleeping?(In hours. Max of 18)</label>
<input type="range" placeholder="" name="TimeInBed" step="0.25" min="0" max="18"onchange="updateTextInput2(this.value);" />
<input type="text" id="textInput2" value="" readonly>
            
        </div>
        <div class="tab">
            <h2>Your Emotional Information</h2>
	<h2><b>In the past day, have you felt any of these following feelings?</b></h2>

                        <div class = "form-group">
        Anxiety:
            <select name="Anxiety">
                <option id="" selected></option> // Pre-selected
                <option value="1">True</option>
                <option value="0">False</option>
            </select>
        </div>
        <div class = "form-group">
        Anger:
            <select name="Anger">
                <option id="" selected></option> // Pre-selected
                <option value="1">True</option>
                <option value="0">False</option>

            </select>

        </div>
        
        <div class = "form-group">
        Sadness:
        <select name="Sadness">
            <option id="" selected></option> // Pre-selected
            <option value="1">True</option>
            <option value="0">False</option>

        </select>
        </div>
        <div class = "form-group">
        Numbness:
        <select name="Numbness">
        <option id="" selected></option> // Pre-selected
        <option value="1">True</option>
        <option value="0">False</option>

        </select>

        </div>
        <div class = "form-group">
        Rumination or excessive preoccupation:
        <select name="Rumination">
        <option id="" selected></option> // Pre-selected
        <option value="1">True</option>
        <option value="0">False</option>

        </select>

        </div>
        <div class = "form-group">
        Loss of Appetite:
        <select name="LossOfAppitite">
        <option id="" selected></option> // Pre-selected
        <option value="1">True</option>
        <option value="0">False</option>

        </select>

        </div>	
        <div class = "form-group"> 	

        Excessive Appetite:
        <select name="ExcessiveAppitite">
        <option id="" selected></option> // Pre-selected
        <option value="1">True</option>
        <option value="0">False</option>

        </select>

        </div>
        <div class = "form-group">

        Trouble sleeping:
        <select name="TroubleSleeping">
        <option id="" selected></option> // Pre-selected
        <option value="1">True</option>
        <option value="0">False</option>

        </select>

        </div>
        <div class = "form-group">
        Low Self-Esteem:
        <select name="LowSelfEsteem">
        <option id="" selected></option> // Pre-selected
        <option value="1">True</option>
        <option value="0">False</option>

        </select>

        </div>
        <div class = "form-group">
        Mania (Excessive enthusiasm or energy):
        <select name="Mania">
        <option id="" selected></option> // Pre-selected
        <option value="1">True</option>
        <option value="0">False</option>

        </select>

        </div>
        <div class = "form-group">
        Mood swings:
        <select name="MoodSwings">
        <option id="" selected></option> // Pre-selected
        <option value="1">True</option>
        <option value="0">False</option>

        </select>	

        </div>
        <div class = "form-group">

        Lack of motivation:
        <select name="Unmotivated">
        <option id="" selected></option> // Pre-selected
        <option value="1">True</option>
        <option value="0">False</option>

        </select>

        </div>
        <div class = "form-group">

        Tiredness or drowsiness:
        <select name="Tiredness" >
        <option id="" selected></option> // Pre-selected
        <option value="1">True</option>
        <option value="0">False</option>

        </select>        

            </div>

	
            </div>
            <div class="tab">
                <div>
                    <h2>Your Medical Information</h2>
                    <h1>Alleries</h1>

<div id="dynamic_field1">  
      
          <input type="text" id="AllergyType" name="AllergyType[]" placeholder="What is your allergy?" class="form-control name_list" />
          <input type="text" id="AllergyStatus" name="AllergyStatus[]" placeholder="How does it affect you?" class="form-control name_list" />
          <input type="date" id="AllergyDate" name="AllergyDate[]" placeholder="When did you first notice?" class="form-control name_list" /> 
          <button type="button" name="addAllergies" id="addAllergies" class="btn btn-success">Add More</button>  
     
     
</div>  
    

<h1>Recent Hospital Visit</h1>

<div id="dynamic_field2">  
 
     <input type="text" id="VisitType" name="VisitType[]" placeholder="VisitType?" class="form-control name_list" />
     <input type="text" id="Reason" name="Reason[]" placeholder="Reason?" class="form-control name_list" />
     <input type="text" id="clinitian" name="clinitian[]" placeholder="clinitian?" class="form-control name_list" />
     <input type="text" id="Specialty" name="Specialty[]" placeholder="Specialty?" class="form-control name_list" />
     <input type="text" id="Facility" name="Facility[]" placeholder="Facility?" class="form-control name_list" />
     <input type="date" id="EncounterDate" name="EncounterDate[]" placeholder="EncounterDate?" class="form-control name_list" /> 
     <button type="button" name="addHospitalVisit" id="addHospitalVisit" class="btn btn-success">Add More</button>  
 
 
</div>  

<h1>Diagnosis History</h1>

<div id="dynamic_field3">  

<input type="text" id="DiagnosisType" name="DiagnosisType[]" placeholder="DiagnosisType?" class="form-control name_list" />
<input type="text" id="DiagnosisStatus" name="DiagnosisStatus[]" placeholder="DiagnosisStatus?" class="form-control name_list" />
<input type="date" id="DiagnosisDate" name="DiagnosisDate[]" placeholder="DiagnosisDate?" class="form-control name_list" /> 
<button type="button" name="addDiagnosis" id="addDiagnosis" class="btn btn-success">Add More</button>  


</div>  

<h1>Medication History</h1>

<div id="dynamic_field4">  
<input type="text" id="MedicationName" name="MedicationName[]" placeholder="MedicationName?" class="form-control name_list" />
<input type="text" id="Perscription" name="Perscription[]" placeholder="Perscription?" class="form-control name_list" />
<input type="date" id="DatePerscribed" name="DatePerscribed[]" placeholder="DatePerscribed?" class="form-control name_list" />
<input type="date" id="LastFilled" name="LastFilled[]" placeholder="LastFilled?" class="form-control name_list" /> 
<button type="button" name="addMedications" id="addMedications" class="btn btn-success">Add More</button>  


</div>  

<h1>Immunization History</h1>

<div id="dynamic_field5">  

<input type="text" id="NumberRecieved" name="NumberRecieved[]" placeholder="NumberRecieved?" class="form-control name_list" />
<input type="text" id="ImmunizationType" name="ImmunizationType[]" placeholder="ImmunizationType?" class="form-control name_list" />
<input type="date" id="ImmunizationDate" name="ImmunizationDate[]" placeholder="ImmunizationDate?" class="form-control name_list" /> 
<button type="button" name="addImmunizations" id="addImmunizations" class="btn btn-success">Add More</button>  


</div>  

<h1>Blood Pressure History</h1>

<div id="dynamic_field6">  

<input type="number" id="Diastolic" name="Diastolic[]" placeholder="DiagnosisType?" class="form-control name_list" />
<input type="number" id="Systolic" name="Systolic[]" placeholder="DiagnosisStatus?" class="form-control name_list" />
<input type="date" id="BPMeasurementDate" name="BPMeasurementDate[]" placeholder="DiagnosisDate?" class="form-control name_list" /> 
<button type="button" name="addBloodPressure" id="addBloodPressure" class="btn btn-success">Add More</button>  


</div>  

<h1>Blood Sugar History</h1>

<div id="dynamic_field7">  
<input type="datetime-local" id="BSMeasurementDate" name="BSMeasurementDate[]" placeholder="BSMeasurementDate?" class="form-control name_list" />
<input type="number" id="BloodSugarMeasure" name="BloodSugarMeasure[]" placeholder="BloodSugarMeasure?" class="form-control name_list" />
<button type="button" name="addBloodSugar" id="addBloodSugar" class="btn btn-success">Add More</button>  


</div>  

<h1>Cholesterol History</h1>

<div id="dynamic_field8">  

<input type="datetime-local" id="CholMeasurementDate" name="CholMeasurementDate[]" placeholder="CholMeasurementDate?" class="form-control name_list" />
<input type="number" id="CholMeasure" name="CholMeasure[]" placeholder="CholMeasure?" class="form-control name_list" />
<button type="button" name="addCholesterol" id="addCholesterol" class="btn btn-success">Add More</button>  


</div>  


                </div>
            </div>

            <div class="tab">
                <div>

                    <h2>Your Nutrition Information</h2>


                    <div id="food">
                            <span>
                                Food Eaten
                                <input type="text" name="FoodName[]" required/>
                                
                        </div>

                    <div>
                        <input type="button" id="addFood" name="addFood" value="Add More" />
                    </div>
		    <h2>ExerciseInformation</h2>
                    <br>
                    <div class="form-group col-lg-12">
                        <label for="HR">Distance Ran (in miles)</label>
                        <input type="text" class="form-control" id="HR" placeholder="">
                    </div>
                    <div class="form-group col-lg-12">
                        <label for="HR">Distance Walked (in miles)</label>
                        <input type="text" class="form-control" id="HR" placeholder="">
                    </div>
                    <div class="form-group col-lg-12">
                        <label for="HR">Steps Taken</label>
                        <input type="text" class="form-control" id="HR" placeholder="">
                    </div>
                    <div class="form-group col-lg-12">
                        <label for="HR">Stairs Climbed</label>
                        <input type="text" class="form-control" id="HR" placeholder="">
                    </div>
                    <br>
                    
                  <select name="one" onchange="if (this.value=='other'){this.form['other'].style.visibility='visible';this.form['Weight'].style.visibility='hidden';this.form['Sets'].style.visibility='hidden';this.form['Reps'].style.visibility='hidden';this.form['ExerciseName'].style.visibility='visible';}else {this.form['other'].style.visibility='hidden';this.form['Sets'].style.visibility='visible';this.form['Reps'].style.visibility='visible';this.form['ExerciseName'].style.visibility='visible';this.form['Weight'].style.visibility='visible';};">
<option value="2">Select Exercise Type</option>
<option value="1">Weight Training</option>
<option value="other">Cardio</option>
</select>
<div>
		    <input type="textbox" name="ExerciseName" style="visibility:hidden;" placeholder="ExerciseName">
                    <input type="textbox" name="Reps" id="Reps" style="visibility:hidden;" placeholder="Reps" value="0">
                    <input type="textbox" name="Sets" id="Sets" style="visibility:hidden;" placeholder="Sets" value="0">
		    <input type="textbox" name="Weight" id="Weight" style="visibility:hidden;" placeholder="Weight" value="0">
                    <input type="textbox" name="other" style="visibility:hidden;" placeholder="Duration" value="0">
    </div>


                    
                </div>
            </div>

            <!-- Circles which indicates the steps of the form: -->
            <div style="text-align:center;margin-top:40px;">
                <span class="step"></span>
                <span class="step"></span>
                <span class="step"></span>
				<span class="step"></span>
            </div>
            <div style="overflow:auto;">
                <div style="float:right;">
                    <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                    <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                </div>
                <div style="float:left;">
                    <button type="button" id="myPage" onclick="myPageFunction()">Cancel Submission</button>


                </div>
            </div>


</form>
    <script>
        function myPageFunction() {
            
            location.href = "Profilepage.php";
        }
        function add_fields() {
            var d = document.getElementById("food");
            d.innerHTML += "<br /><span>Food Eaten: <input type='text' 'value='' /></span>";
        }
        function add_field() {
            var d = document.getElementById("liquid");
            d.innerHTML += "<br /><span>Liquid Drank: <input type='text' 'value='' /></span>";
        }
     </script>

    <script>
        var currentTab = 0; // Current tab is set to be the first tab (0)
        showTab(currentTab); // Display the crurrent tab
        function showTab(n) {
            // This function will display the specified tab of the form...
            var x = document.getElementsByClassName("tab");
            x[n].style.display = "block";
            //... and fix the Previous/Next buttons:
            if (n == 0) {
                document.getElementById("prevBtn").style.display = "none";
                document.getElementById("prevBtn").innerHTML = "Back To My Page";
            } else {
                document.getElementById("prevBtn").style.display = "inline";
                document.getElementById("prevBtn").innerHTML = "Previous Step";
            }
            if (n == (x.length - 1)) {
                document.getElementById("nextBtn").innerHTML = "Submit Data";
 
            } else {
                document.getElementById("nextBtn").innerHTML = "Next Step";
            }
            //... and run a function that will display the correct step indicator:
            fixStepIndicator(n)
        }
        function nextPrev(n) {
            // This function will figure out which tab to display
            var x = document.getElementsByClassName("tab");
            // Exit the function if any field in the current tab is invalid:
            if (n == 1 && !validateForm()) return false;
            // Hide the current tab:
            x[currentTab].style.display = "none";
            // Increase or decrease the current tab by 1:
            currentTab = currentTab + n;
            // if you have reached the end of the form...
            if (currentTab >= x.length) {
                // ... the form gets submitted:
                document.getElementById("regForm").submit();
                return false;
                self.location = "Profilepage.php";
            }
            // Otherwise, display the correct tab:
            showTab(currentTab);
        }
        function validateForm() {
            // This function deals with validation of the form fields
            var x, y, i, valid = true;
            x = document.getElementsByClassName("tab");
            y = x[currentTab].getElementsByTagName("input");
            // A loop that checks every input field in the current tab:
            for (i = 0; i < y.length; i++) {
                // If a field is empty...
                if (y[i].value == "") {
                    // add an "invalid" class to the field:
                    y[i].className += " invalid";
                    // and set the current valid status to false
                    valid = false;
                }
            }
            // If the valid status is true, mark the step as finished and valid:
            if (valid) {
                document.getElementsByClassName("step")[currentTab].className += " finish";
            }
            return valid; // return the valid status
        }
        function fixStepIndicator(n) {
            // This function removes the "active" class of all steps...
            var i, x = document.getElementsByClassName("step");
            for (i = 0; i < x.length; i++) {
                x[i].className = x[i].className.replace(" active", "");
            }
            //... and adds the "active" class on the current step:
            x[n].className += " active";
        }
    </script>
	<script>
	var slider = document.getElementById("myRange");
	var output = document.getElementById("slideout");
	output.innerHTML = slider.value;
	slider.oninput = function() {
	  output.innerHTML = this.value;
	}
	</script>
	<script>  
 $(document).ready(function(e){  $("#addAllergies").click(function(e)
 { 


var html = '<div><input type="text" id="ChildAllergyType" name="AllergyType[]" placeholder="What is your allergy?" class="form-control name_list" /><input type="text" id="ChildAllergyStatus" name="AllergyStatus[]" placeholder="How does it affect you?" class="form-control name_list" /><input type="date" id="ChildAllergyDate" name="AllergyDate[]" placeholder="When did you first notice?" class="form-control name_list" /><button type="button" name="addAllergies" id="Remove" class="btn btn-fail">X</button></div>';
     $("#addAllergies").click(function(e)
     {
                     $("#dynamic_field1").append(html);
         

     });
 });

$("#dynamic_field1").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});
$(document).ready(function(e){
    var hospital = '<div><input type="text" id="VisitType" name="VisitType[]" placeholder="VisitType?" class="form-control name_list" /><input type="text" id="Reason" name="Reason[]" placeholder="Reason?" class="form-control name_list" /><input type="text" id="clinitian" name="clinitian[]" placeholder="clinitian?" class="form-control name_list" /><input type="text" id="Specialty" name="Specialty[]" placeholder="Specialty?" class="form-control name_list" /><input type="text" id="Facility" name="Facility[]" placeholder="Facility?" class="form-control name_list" /><input type="date" id="EncounterDate" name="EncounterDate[]" placeholder="EncounterDate?" class="form-control name_list" /><button type="button" name="addAllergies" id="Remove" class="btn btn-fail">X</button><div> ';
$("#addHospitalVisit").click(function(e)
     {
                     $("#dynamic_field2").append(hospital);
         

     });
 

$("#dynamic_field2").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});
$(document).ready(function(e){
    var diagnosis = '<div><input type="text" id="DiagnosisType" name="DiagnosisType[]" placeholder="DiagnosisType?" class="form-control name_list" /><input type="text" id="DiagnosisStatus" name="DiagnosisStatus[]" placeholder="DiagnosisStatus?" class="form-control name_list" /><input type="date" id="DiagnosisDate" name="DiagnosisDate[]" placeholder="DiagnosisDate?" class="form-control name_list" /> <button type="button" name="addDiagnosis" id="Remove" class="btn btn-fail">X</button></div>';
$("#addDiagnosis").click(function(e)
     {
                     $("#dynamic_field3").append(diagnosis);
         

     
 });

$("#dynamic_field3").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});

$(document).ready(function(e){
    var medications = '<div><input type="text" id="MedicationName" name="MedicationName[]" placeholder="MedicationName?" class="form-control name_list" /><input type="text" id="Perscription" name="Perscription[]" placeholder="Perscription?" class="form-control name_list" /><input type="date" id="DatePerscribed" name="DatePerscribed[]" placeholder="DatePerscribed?" class="form-control name_list" /><input type="date" id="LastFilled" name="LastFilled[]" placeholder="LastFilled?" class="form-control name_list" /> <button type="button" name="addDiagnosis" id="Remove" class="btn btn-fail">X</button></div> ';
$("#addMedications").click(function(e)
     {
                     $("#dynamic_field4").append(medications);
         

     
 });

$("#dynamic_field4").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});

$(document).ready(function(e){
    var immunizations = '<div><input type="text" id="NumberRecieved" name="NumberRecieved[]" placeholder="NumberRecieved?" class="form-control name_list" /><input type="text" id="ImmunizationType" name="ImmunizationType[]" placeholder="ImmunizationType?" class="form-control name_list" /><input type="date" id="ImmunizationDate" name="ImmunizationDate[]" placeholder="ImmunizationDate?" class="form-control name_list" /> <button type="button" name="addImmunizations" id="Remove" class="btn btn-fail">X</button></div>';
$("#addImmunizations").click(function(e)
     {
                     $("#dynamic_field5").append(immunizations);
         

     
 });

$("#dynamic_field5").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});
$(document).ready(function(e){
    var BloodPressure = '<div><input type="number" id="Diastolic" name="Diastolic[]" placeholder="DiagnosisType?" class="form-control name_list" /><input type="number" id="Systolic" name="Systolic[]" placeholder="DiagnosisStatus?" class="form-control name_list" /><input type="date" id="BPMeasurementDate" name="BPMeasurementDate[]" placeholder="DiagnosisDate?" class="form-control name_list" />  <button type="button" name="addDiagnosis" id="Remove" class="btn btn-fail">X</button></div>';
$("#addBloodPressure").click(function(e)
     {
                     $("#dynamic_field6").append(BloodPressure);
         

     
 });

$("#dynamic_field6").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});

$(document).ready(function(e){
    var food = '<div id="food"><span>Food Eaten<input type="text" name="FoodName[]" required/></div><div>';
    $("#addFood").click(function(e)
     {
                     $("#food ").append(food );
         

     
 });

$("#food").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});


$(document).ready(function(e){
    var BloodSugar = '<div><input type="datetime-local" id="BSMeasurementDate" name="BSMeasurementDate[]" placeholder="BSMeasurementDate?" class="form-control name_list" /><input type="number" id="BloodSugarMeasure" name="BloodSugarMeasure[]" placeholder="BloodSugarMeasure?" class="form-control name_list" /><button type="button" name="addDiagnosis" id="Remove" class="btn btn-fail">X</button></div> ';
$("#addBloodSugar").click(function(e)
     {
                     $("#dynamic_field7").append(BloodSugar);
         

     
 });

$("#dynamic_field7").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});

$(document).ready(function(e){
    var Cholesterol = '<div><input type="datetime-local" id="CholMeasurementDate" name="CholMeasurementDate[]" placeholder="CholMeasurementDate?" class="form-control name_list" /><input type="number" id="CholMeasure" name="CholMeasure[]" placeholder="CholMeasure?" class="form-control name_list" /> <button type="button" name="addImmunizations" id="Remove" class="btn btn-fail">X</button></div>';
$("#addCholesterol").click(function(e)
     {
                     $("#dynamic_field8").append(Cholesterol);
         

     
 });

$("#dynamic_field8").on('click','#Remove',function(e){

    $(this).parent('div').remove();

    });


});






 
 </script>


</body>

</html>