<?php
ob_start();
session_start();
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>User Page</title>
    <script type="text/javascript">
        $(document).ready(function () {
            $("button").click(function () {
                $("p").hide();
            });
        });
        function myOtherFunction() {

location.href = "Login.php";

}

function accountSettingsFunction() {

location.href = "AccountSettings.html";

}

function myPageFunction() {

location.href = "Profilepage.php";
}

    </script>

    <style>
        #EmotionForm {
        background-color: #ffffff;
        margin: 100px auto;
        font-family: Raleway;
        padding: 40px;
        width: 90%;
        min-width: 300px;
        height: 1500px;
    }

        body {
            background-color: #ee7600;
        }

        /* Style the tab */

        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */

        .tab button {
            background-color: inherit;
            float: left;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }
		.dropdown {
		    position: absolute;

		    /** Make it fit tightly around it's children */
		    display: inline-block;
		}

		.dropdown .dropdown-menu {
		    position: absolute;

		    /**
		     * Set the top of the dropdown menu to be positioned 100%
		     * from the top of the container, and aligned to the left.
		     */
		    top: 100%;
		    left: 0;

		    /** Allow no empty space between this and .dropdown */
			display: none;
		    margin: 0;

		    /****************
		     ** NEW STYLES **
		     ****************/

		    list-style: none; /** Remove list bullets */
		    width: 100%; /** Set the width to 100% of it's parent */
		    padding: 0;
			
		}
		.dropdown:hover .dropdown-menu {

		    /** Show dropdown menu */
		    display: block;
		}
		

        /* Change background color of buttons on hover */

        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */

        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */

        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }

        .header {
            padding: 10px 16px;
            background: #555;
            color: #f1f1f1;
            z-index: 3;
        }

        .content {
            padding: 16px;
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
        }

        .sticky+.content {
            padding-top: 102px;
        }

        #Base {
            top: 100px;
            left: 10px;
            z-index: 1;
        }

        #ProfilePic {
            position: absolute;
            top: 300px;
            left: 850px;
            z-index: 2;
        }

        .sidenav {
            height: 100%;
            width: 200px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #555;
            overflow-x: hidden;
            padding-top: 20px;
            border: 3px solid white;
        }

        .sidenav a {
            padding: 6px 8px 6px 16px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
        }

        .sidenav a:hover {
            color: #f1f1f1;
        }

        .main {
            margin-left: 200px;
            /* Same as the width of the sidenav */
            font-size: 28px;
            /* Increased text to enable scrolling */
            padding: 0px 0px;
        }
    </style>
</head>

<body>

    <div class="sidenav">
        <p style="color: white; font-size: 18px; text-align: center;"><?php echo("{$_SESSION['UserName']}");?></p>
        <img style="width: 100%;" src="download.png" />
        <p style="color: white;">Stat 1</p>
        <p style="color: white;">Stat 2</p>
        <p style="color: white;">Stat 3</p>
    </div>

    <div class="main">
        <div class="header" id="myHeader">
            <h1><?php echo("{$_SESSION['UserName']}");?></h1>
        </div>

        <div class="tab">
            <button id="myPage" class="tablinks" onclick="myPageFunction()">My Page</button>
            <button id="accountSettings" onclick="accountSettingsFunction()">Account Settings</button>
			<div class="dropdown">

			    <!-- trigger button -->
			    <button style = "font-family:verdana; font-size:17">Add Data</button>

			    <!-- dropdown menu -->
			    <ul class="dropdown-menu">
                <li><a href="addsleepdata.php">Sleep Data</a></li>
                        <li><a href="Nutrionation.php">Nutrution Data</a></li>
                        <li><a href="Exerisce.php">Exersice Data</a></li>
                        <li><a href="Emotional.php">Emotional Data</a></li>
                        <li><a href="">Medical Data</a></li>

			    </ul>

			</div>
            <button class="tablinks" href="CreateAccount.html"style ="padding-left:125px">Generate Report</button>
            <button id="logoutButton" onclick="myOtherFunction()">Log Out</button>
        </div>
        <div >

            
            <form id="EmotionForm" action="" method="">
                <h1>Add Emotional Data</h1>
                <h2>In the past month, how often has each statement been true?<br />0 for not at all, 1 for sometimes, 2 for half or more, and 3 for all the time.</h2>

                <div class="form-group col-lg-12">
                    <label for="HR">Little interest of pleasure in actions.</label>
                    <input type="number" class="form-control" id="HR" min="0" max="3">
                </div>
                <div class="form-group col-lg-12">
                    <label for="HR">Feeling down, depressed or hopeless.</label>
                    <input type="number" class="form-control" id="HR" min="0" max="3">
                </div>
                <div class="form-group col-lg-12">
                    <label for="HR">Trouble falling asleep, staying asleep, or sleeping too much.</label>
                    <input type="number" class="form-control" id="HR" min="0" max="3">
                </div>
                <div class="form-group col-lg-12">
                    <label for="HR">Feeling tired or having little energy.</label>
                    <input type="number" class="form-control" id="HR" min="0" max="3">
                </div>
                <div class="form-group col-lg-12">
                    <label for="HR">Poor appetite or overeating.</label>
                    <input type="number" class="form-control" id="HR" min="0" max="3">
                </div>
                <div class="form-group col-lg-12">
                    <label for="HR">Feeling bad about yourself - or that you're a failure or have let yourself or your loved ones down.</label>
                    <input type="number" class="form-control" id="HR" min="0" max="3">
                </div>
                <div class="form-group col-lg-12">
                    <label for="HR">Trouble concentrating on things, such as reading the newspaper or watching television.</label>
                    <input type="number" class="form-control" id="HR" min="0" max="3">
                </div>
                <div class="form-group col-lg-12">
                    <label for="HR">Moving or speaking so slowly that others could have noticed, or being so restless and fidgety you move more than usual.</label>
                    <input type="number" class="form-control" id="HR" min="0" max="3">
                </div>
                <div class="form-group col-lg-12">
                    <label for="HR">Thoughts of hurting yourself or that it would be better to be dead.</label>
                    <input type="number" class="form-control" id="HR" min="0" max="3">
                </div>
                <div class="form-group col-lg-12">
                    <label for="HR">Any of the above have made it difficult for you to perform day-to-day activities or get along with others.</label>
                    <input type="number" class="form-control" id="HR" min="0" max="3">
                </div>

                <div style="overflow:auto;">
                    <div style="float:right;">
                        <button type="button" id="nextBtn" onclick="nextPrev(1)">Confirm</button>
                    </div>
                    <div style="float:left;">
                        <button type="button" id="myPage" onclick="myPageFunction()">Cancel Submission</button>
                    </div>
                </div>
            </form>
            
        </div>


</body>

</html>