<?php
include "Exerisce.php";
$user = 'root';
$pass = '';
$db = 'healthdb';

$exerisce = $_POST['ExerisceName'];
$reps = $_POST['Reps'];
$sets = $_POST['Sets'];
$duration = $_POST['other'];
$dayID = $_SESSION['AccountNum'];



$db = new mysqli('localhost', $user, $pass, $db) or die ("Unable to connect");
$resulrt = mysqli_query($db,"INSERT INTO daye (DayID,AccountNum) values (NULL,'$dayID')");
    if($resulrt)
    {
        $result = mysqli_query($db,"INSERT INTO exercise (ExerciseID,DayID,ActivityName,Duration,Repititions,Sets) values (NULL,$dayID,$exerisce,$duration,$reps,$sets)");
        if($result)
        {
        header( "Location: Exerisce.php");
        }
        else
        {
            echo("Error description: " . mysqli_error($db));
        }
    }
    else
        {
            echo("Error description: " . mysqli_error($db));
        }

?>
