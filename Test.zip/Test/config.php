<?php
$user = 'root';
$pass = '';
$db = 'testf';
$db = new mysqli('localhost', $user, $pass, $db) or die ("Unable to connect");
session_start();
?>
