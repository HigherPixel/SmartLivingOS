<?php
$user = 'root';
$pass = '';
$db = 'healthdb';
$db = new mysqli('localhost', $user, $pass, $db) or die ("Unable to connect");
session_start();
?>
