<?php
include "index.php";
$user = 'root';
$pass = '';
$db = 'testf';

$fName =$_POST['firstname'];
$lName = $_POST['lastname'];
$userName =$_POST['userName'];
$password = $_POST['password'];
$birthday = $_POST['DOB'];

echo "Hello,".$fName;

$db = new mysqli('localhost', $user, $pass, $db) or die ("Unable to connect");
$result = mysqli_query($db,"INSERT INTO users(firstname,lastname,username,passcode,DOB) values ('$fName','$lName','$userName','$password','$birthday')");

header( "Location: Login.php");
/*if(isset($_POST['createAccount']))
{
    
}*/
?>
