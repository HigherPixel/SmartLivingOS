<?php
ob_start();
session_start();
include "index.php";
$user = 'root';
$pass = '';
$db = 'healthdb';

$fName =$_POST['firstname'];
$lName = $_POST['lastname'];
$userName =$_POST['userName'];
$password = $_POST['password'];
$birthday = $_POST['DOB'];
$address = $_POST['address-line'];
$city = $_POST['city'];
$region= $_POST['region'];
$zip= $_POST['zip'];
$sex= $_POST['Sex'];
$country = $_POST['country'];

$db = new mysqli('localhost', $user, $pass, $db) or die ("Unable to connect");
$result = mysqli_query($db,"INSERT INTO user(FirstName,LastName,UserName,Password,DOB,AccountNum,CityAddr,StreetAddr,StateAddr,ZipAddr,Sex,NationalAddr) values ('$fName','$lName','$userName','$password','$birthday',NULL,'$city','$address','$region','$zip','$sex','$country')");

if($result)
{
    $resulrt = mysqli_query($db,"INSERT INTO daye (DayID,AccountNum) values (NULL,'1')");
    if($resulrt)
    {
        header( "Location: Login.php");
    }
    else
{
    echo("Error description: " . mysqli_error($db));
}
}
else
{
    echo("Error description: " . mysqli_error($db));
}

/*if(isset($_POST['createAccount']))
{
    
}*/
?>
