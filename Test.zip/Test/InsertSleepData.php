<?php
include "addsleepdata.php";
$user = 'root';
$pass = '';
$db = 'healthdb';

$duration =$_POST['Duration'];
$quality = $_POST['Quality'];
$TimeInBed =$_POST['TimeInBed'];
$TimeOutOfBed = $_POST['TimeOutOfBed'];

$db = new mysqli('localhost', $user, $pass, $db) or die ("Unable to connect");
$result = mysqli_query($db,"INSERT INTO sleep(DayID,Duration,Quality,TimeInBed,TimeOutOfBed) values ('6','$duration','$quality','$TimeInBed','$TimeOutOfBed')");
if($result)
{
header( "Location: DisplaySleepData.php");
}
else
{
    echo("Error description: " . mysqli_error($db));
}
/*if(isset($_POST['createAccount']))
{
    
}*/
?>
