<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
* {
  box-sizing: border-box;
}

body {
  background-color:  #ee7600;
}

#regForm {
  background-color: #ffffff;
  margin: 100px auto;
  font-family: Raleway;
  padding: 40px;
  width: 70%;
  min-width: 300px;
}

h1 {
  text-align: center;  
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
}

button {
  background-color: #4CAF50;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}
</style>
<body>

<form id="regForm" action="CreateAccount.php" method="post">
  <h1>Smart Living OS Registration</h1>
  <!-- One "tab" for each step in the form: -->
  <div class="tab">
    <div class="form-group">
    <p><input placeholder="First Name" type="text" name="firstname"></p>
    <p><input placeholder="Last Name" type="text" name="lastname"></p>
    <p><input type="date" name="DOB"></p>
    </div>
    <div class="form-group">
    <p><input placeholder="Username" type="text" name="userName" ></p>
    <p><input placeholder="Email" type="text"  name="email" ></p>
    <p><input placeholder="Confirm Email" type="text" name="confirmEmail" ></p>
    <p><input placeholder="Password" type="text"  name="password" required ></p>
    <p><input placeholder="Confirm Password" type="text"   name="confirmPassword" required ></p>
    </div>

  </div>
  <div style="overflow:auto;">
    <div style="float:right;">

      <button id="nextBtn" name="createAccount" onclick="nextPrev(1)">Next</button>
    </div>
  </div>
  <div style="overflow:auto;">
    <div style="float:left;">

      <input type="button" value="Back to login" onclick="redir();" />
    </div>
  </div>
  <!-- Circles which indicates the steps of the form: -->
</form>

<script type="text/javascript">
  function redir() {
    window.location = "index.php";
  }
</script>


</body>
</html>