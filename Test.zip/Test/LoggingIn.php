<?php
include "Login.php";
$user = 'root';
$pass = '';
$db = 'testf';


$db = new mysqli('localhost', $user, $pass, $db) or die ("Unable to connect");
session_start();
   
if(isset($_POST['login'])) {
   // username and password sent from form 
   
   $myusername = $_POST['userName'];
   $mypassword = $_POST['password']; 
   
   $sql = "SELECT * FROM testf WHERE username = '$myusername' and password = '$mypassword'";
   $result = mysqli_query($db,$sql);
   if($query_run)
				{
    if(mysqli_num_rows($result)>0)
    {
        $_SESSION['userName'] = $myusername;
        header('location:Profilepage.php');
    }
}
?>
