<?php
    require 'config.php';
?>
<!DOCTYPE html>

<html>


<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
<style>
        #myButton {

            width: 100px;

        }

        #loginButton {

            width: 100px;

        }

        body {
            background-color: #ee7600;
        }
    </style>
</style>
<body>
<h1 style="text-align: center; font-size: 70px;">Smart Living OS</h1>

<div style="    text-align: center;">
    <img id="Base" style="vertical-align: middle;" src="Untitled.png" />

<form class="form-signin" action="Login.php" method="POST">      
<div style="text-align: center; padding-bottom: 50px; padding-top: 50px; width: 50%; margin: auto;">
            <h2 style="text-align: center; font-size: 45px;"  class="form-signin-heading">Login or Create an Account Today!</h2>
            <div class="form-group">
            <input type="text" class="form-control" name="userName" placeholder="username" required="" autofocus="" name="userName" />
            </div>
            <br>
            <div class="form-group">
            <input type="password" class="form-control" name="password" placeholder="Password" required="" name="password"/>      
            </div>
            <label class="checkbox">
              <input type="checkbox" value="remember-me" id="rememberMe" name="rememberMe"> Remember me
            </label>
            <div style="text-align: center;">
                <input type="submit" value="Login Account" name="login"/>
                <input type="button" value="Create Account" onclick="redir();" />
            </div>

           
    </div>
</form>
<script type="text/javascript">
  function redir() {
    window.location = "index.php";
  }
</script>

<?php

if(isset($_POST['login']))
{
    @$username = $_POST['userName'];
    @$password = $_POST['password'];

    $query = "select * from users where username='$username' and passcode='$password' ";
    $query_run = mysqli_query($db,$query);
    if($query_run)
				{
    if(mysqli_num_rows($query_run)>0)
    {
        $row = mysqli_fetch_array($query_run,MYSQLI_ASSOC);
					
        $_SESSION['username'] = $username;
        $_SESSION['password'] = $password;
        
        header( "Location: Profilepage.php");
        }
    }
    else{
        echo "My first PHP script!";
    
}
}
?>



</body>
</html>
